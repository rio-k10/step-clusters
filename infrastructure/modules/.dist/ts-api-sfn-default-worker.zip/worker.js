"use strict";
var t = Object.defineProperty;
var s = Object.getOwnPropertyDescriptor;
var l = Object.getOwnPropertyNames;
var c = Object.prototype.hasOwnProperty;
var k = (o, e) => {
    for (var r in e) t(o, r, { get: e[r], enumerable: !0 });
  },
  a = (o, e, r, i) => {
    if ((e && typeof e == "object") || typeof e == "function")
      for (let n of l(e))
        !c.call(o, n) &&
          n !== r &&
          t(o, n, {
            get: () => e[n],
            enumerable: !(i = s(e, n)) || i.enumerable,
          });
    return o;
  };
var d = (o) => a(t({}, "__esModule", { value: !0 }), o);
var h = {};
k(h, { handler: () => g });
module.exports = d(h);
var g = async (o) => (
  console.log("Worker invoked with:", JSON.stringify(o)),
  { ok: !0, note: "Worker finished console log." }
);
0 && (module.exports = { handler });
//# sourceMappingURL=worker.js.map
