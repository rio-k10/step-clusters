"use strict";
var FA = Object.create;
var Vo = Object.defineProperty;
var LA = Object.getOwnPropertyDescriptor;
var $A = Object.getOwnPropertyNames;
var UA = Object.getPrototypeOf,
  HA = Object.prototype.hasOwnProperty;
var b = (e, t) => () => (e && (t = e((e = 0))), t);
var P = (e, t) => () => (t || e((t = { exports: {} }).exports, t), t.exports),
  st = (e, t) => {
    for (var r in t) Vo(e, r, { get: t[r], enumerable: !0 });
  },
  rh = (e, t, r, n) => {
    if ((t && typeof t == "object") || typeof t == "function")
      for (let s of $A(t))
        !HA.call(e, s) &&
          s !== r &&
          Vo(e, s, {
            get: () => t[s],
            enumerable: !(n = LA(t, s)) || n.enumerable,
          });
    return e;
  };
var v = (e, t, r) => (
    (r = e != null ? FA(UA(e)) : {}),
    rh(
      t || !e || !e.__esModule
        ? Vo(r, "default", { value: e, enumerable: !0 })
        : r,
      e,
    )
  ),
  ce = (e) => rh(Vo({}, "__esModule", { value: !0 }), e);
var rr = P((pe) => {
  "use strict";
  pe.HttpAuthLocation = void 0;
  (function (e) {
    ((e.HEADER = "header"), (e.QUERY = "query"));
  })(pe.HttpAuthLocation || (pe.HttpAuthLocation = {}));
  pe.HttpApiKeyAuthLocation = void 0;
  (function (e) {
    ((e.HEADER = "header"), (e.QUERY = "query"));
  })(pe.HttpApiKeyAuthLocation || (pe.HttpApiKeyAuthLocation = {}));
  pe.EndpointURLScheme = void 0;
  (function (e) {
    ((e.HTTP = "http"), (e.HTTPS = "https"));
  })(pe.EndpointURLScheme || (pe.EndpointURLScheme = {}));
  pe.AlgorithmId = void 0;
  (function (e) {
    ((e.MD5 = "md5"),
      (e.CRC32 = "crc32"),
      (e.CRC32C = "crc32c"),
      (e.SHA1 = "sha1"),
      (e.SHA256 = "sha256"));
  })(pe.AlgorithmId || (pe.AlgorithmId = {}));
  var zA = (e) => {
      let t = [];
      return (
        e.sha256 !== void 0 &&
          t.push({
            algorithmId: () => pe.AlgorithmId.SHA256,
            checksumConstructor: () => e.sha256,
          }),
        e.md5 != null &&
          t.push({
            algorithmId: () => pe.AlgorithmId.MD5,
            checksumConstructor: () => e.md5,
          }),
        {
          addChecksumAlgorithm(r) {
            t.push(r);
          },
          checksumAlgorithms() {
            return t;
          },
        }
      );
    },
    jA = (e) => {
      let t = {};
      return (
        e.checksumAlgorithms().forEach((r) => {
          t[r.algorithmId()] = r.checksumConstructor();
        }),
        t
      );
    },
    BA = (e) => zA(e),
    qA = (e) => jA(e);
  pe.FieldPosition = void 0;
  (function (e) {
    ((e[(e.HEADER = 0)] = "HEADER"), (e[(e.TRAILER = 1)] = "TRAILER"));
  })(pe.FieldPosition || (pe.FieldPosition = {}));
  var VA = "__smithy_context";
  pe.IniSectionType = void 0;
  (function (e) {
    ((e.PROFILE = "profile"),
      (e.SSO_SESSION = "sso-session"),
      (e.SERVICES = "services"));
  })(pe.IniSectionType || (pe.IniSectionType = {}));
  pe.RequestHandlerProtocol = void 0;
  (function (e) {
    ((e.HTTP_0_9 = "http/0.9"),
      (e.HTTP_1_0 = "http/1.0"),
      (e.TDS_8_0 = "tds/8.0"));
  })(pe.RequestHandlerProtocol || (pe.RequestHandlerProtocol = {}));
  pe.SMITHY_CONTEXT_KEY = VA;
  pe.getDefaultClientConfiguration = BA;
  pe.resolveDefaultRuntimeConfig = qA;
});
var me = P((nr) => {
  "use strict";
  var GA = rr(),
    WA = (e) => ({
      setHttpHandler(t) {
        e.httpHandler = t;
      },
      httpHandler() {
        return e.httpHandler;
      },
      updateHttpClientConfig(t, r) {
        e.httpHandler?.updateHttpClientConfig(t, r);
      },
      httpHandlerConfigs() {
        return e.httpHandler.httpHandlerConfigs();
      },
    }),
    KA = (e) => ({ httpHandler: e.httpHandler() }),
    rl = class {
      name;
      kind;
      values;
      constructor({
        name: t,
        kind: r = GA.FieldPosition.HEADER,
        values: n = [],
      }) {
        ((this.name = t), (this.kind = r), (this.values = n));
      }
      add(t) {
        this.values.push(t);
      }
      set(t) {
        this.values = t;
      }
      remove(t) {
        this.values = this.values.filter((r) => r !== t);
      }
      toString() {
        return this.values
          .map((t) => (t.includes(",") || t.includes(" ") ? `"${t}"` : t))
          .join(", ");
      }
      get() {
        return this.values;
      }
    },
    nl = class {
      entries = {};
      encoding;
      constructor({ fields: t = [], encoding: r = "utf-8" }) {
        (t.forEach(this.setField.bind(this)), (this.encoding = r));
      }
      setField(t) {
        this.entries[t.name.toLowerCase()] = t;
      }
      getField(t) {
        return this.entries[t.toLowerCase()];
      }
      removeField(t) {
        delete this.entries[t.toLowerCase()];
      }
      getByType(t) {
        return Object.values(this.entries).filter((r) => r.kind === t);
      }
    },
    sl = class e {
      method;
      protocol;
      hostname;
      port;
      path;
      query;
      headers;
      username;
      password;
      fragment;
      body;
      constructor(t) {
        ((this.method = t.method || "GET"),
          (this.hostname = t.hostname || "localhost"),
          (this.port = t.port),
          (this.query = t.query || {}),
          (this.headers = t.headers || {}),
          (this.body = t.body),
          (this.protocol = t.protocol
            ? t.protocol.slice(-1) !== ":"
              ? `${t.protocol}:`
              : t.protocol
            : "https:"),
          (this.path = t.path
            ? t.path.charAt(0) !== "/"
              ? `/${t.path}`
              : t.path
            : "/"),
          (this.username = t.username),
          (this.password = t.password),
          (this.fragment = t.fragment));
      }
      static clone(t) {
        let r = new e({ ...t, headers: { ...t.headers } });
        return (r.query && (r.query = JA(r.query)), r);
      }
      static isInstance(t) {
        if (!t) return !1;
        let r = t;
        return (
          "method" in r &&
          "protocol" in r &&
          "hostname" in r &&
          "path" in r &&
          typeof r.query == "object" &&
          typeof r.headers == "object"
        );
      }
      clone() {
        return e.clone(this);
      }
    };
  function JA(e) {
    return Object.keys(e).reduce((t, r) => {
      let n = e[r];
      return { ...t, [r]: Array.isArray(n) ? [...n] : n };
    }, {});
  }
  var ol = class {
    statusCode;
    reason;
    headers;
    body;
    constructor(t) {
      ((this.statusCode = t.statusCode),
        (this.reason = t.reason),
        (this.headers = t.headers || {}),
        (this.body = t.body));
    }
    static isInstance(t) {
      if (!t) return !1;
      let r = t;
      return typeof r.statusCode == "number" && typeof r.headers == "object";
    }
  };
  function YA(e) {
    return /^[a-z0-9][a-z0-9\.\-]*[a-z0-9]$/.test(e);
  }
  nr.Field = rl;
  nr.Fields = nl;
  nr.HttpRequest = sl;
  nr.HttpResponse = ol;
  nr.getHttpHandlerExtensionConfiguration = WA;
  nr.isValidHostname = YA;
  nr.resolveHttpHandlerRuntimeConfig = KA;
});
var cs = P((mj, ah) => {
  "use strict";
  var Wo = Object.defineProperty,
    XA = Object.getOwnPropertyDescriptor,
    QA = Object.getOwnPropertyNames,
    ZA = Object.prototype.hasOwnProperty,
    Go = (e, t) => Wo(e, "name", { value: t, configurable: !0 }),
    eR = (e, t) => {
      for (var r in t) Wo(e, r, { get: t[r], enumerable: !0 });
    },
    tR = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of QA(t))
          !ZA.call(e, s) &&
            s !== r &&
            Wo(e, s, {
              get: () => t[s],
              enumerable: !(n = XA(t, s)) || n.enumerable,
            });
      return e;
    },
    rR = (e) => tR(Wo({}, "__esModule", { value: !0 }), e),
    nh = {};
  eR(nh, {
    getHostHeaderPlugin: () => sR,
    hostHeaderMiddleware: () => oh,
    hostHeaderMiddlewareOptions: () => ih,
    resolveHostHeaderConfig: () => sh,
  });
  ah.exports = rR(nh);
  var nR = me();
  function sh(e) {
    return e;
  }
  Go(sh, "resolveHostHeaderConfig");
  var oh = Go(
      (e) => (t) => async (r) => {
        if (!nR.HttpRequest.isInstance(r.request)) return t(r);
        let { request: n } = r,
          { handlerProtocol: s = "" } = e.requestHandler.metadata || {};
        if (s.indexOf("h2") >= 0 && !n.headers[":authority"])
          (delete n.headers.host,
            (n.headers[":authority"] =
              n.hostname + (n.port ? ":" + n.port : "")));
        else if (!n.headers.host) {
          let o = n.hostname;
          (n.port != null && (o += `:${n.port}`), (n.headers.host = o));
        }
        return t(r);
      },
      "hostHeaderMiddleware",
    ),
    ih = {
      name: "hostHeaderMiddleware",
      step: "build",
      priority: "low",
      tags: ["HOST"],
      override: !0,
    },
    sR = Go(
      (e) => ({
        applyToStack: Go((t) => {
          t.add(oh(e), ih);
        }, "applyToStack"),
      }),
      "getHostHeaderPlugin",
    );
});
var ds = P((hj, uh) => {
  "use strict";
  var Ko = Object.defineProperty,
    oR = Object.getOwnPropertyDescriptor,
    iR = Object.getOwnPropertyNames,
    aR = Object.prototype.hasOwnProperty,
    il = (e, t) => Ko(e, "name", { value: t, configurable: !0 }),
    cR = (e, t) => {
      for (var r in t) Ko(e, r, { get: t[r], enumerable: !0 });
    },
    dR = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of iR(t))
          !aR.call(e, s) &&
            s !== r &&
            Ko(e, s, {
              get: () => t[s],
              enumerable: !(n = oR(t, s)) || n.enumerable,
            });
      return e;
    },
    lR = (e) => dR(Ko({}, "__esModule", { value: !0 }), e),
    ch = {};
  cR(ch, {
    getLoggerPlugin: () => uR,
    loggerMiddleware: () => dh,
    loggerMiddlewareOptions: () => lh,
  });
  uh.exports = lR(ch);
  var dh = il(
      () => (e, t) => async (r) => {
        try {
          let n = await e(r),
            {
              clientName: s,
              commandName: o,
              logger: i,
              dynamoDbDocumentClientOptions: a = {},
            } = t,
            {
              overrideInputFilterSensitiveLog: d,
              overrideOutputFilterSensitiveLog: l,
            } = a,
            p = d ?? t.inputFilterSensitiveLog,
            m = l ?? t.outputFilterSensitiveLog,
            { $metadata: g, ...h } = n.output;
          return (
            i?.info?.({
              clientName: s,
              commandName: o,
              input: p(r.input),
              output: m(h),
              metadata: g,
            }),
            n
          );
        } catch (n) {
          let {
              clientName: s,
              commandName: o,
              logger: i,
              dynamoDbDocumentClientOptions: a = {},
            } = t,
            { overrideInputFilterSensitiveLog: d } = a,
            l = d ?? t.inputFilterSensitiveLog;
          throw (
            i?.error?.({
              clientName: s,
              commandName: o,
              input: l(r.input),
              error: n,
              metadata: n.$metadata,
            }),
            n
          );
        }
      },
      "loggerMiddleware",
    ),
    lh = {
      name: "loggerMiddleware",
      tags: ["LOGGER"],
      step: "initialize",
      override: !0,
    },
    uR = il(
      (e) => ({
        applyToStack: il((t) => {
          t.add(dh(), lh);
        }, "applyToStack"),
      }),
      "getLoggerPlugin",
    );
});
var fh = P((Yo) => {
  "use strict";
  Object.defineProperty(Yo, "__esModule", { value: !0 });
  Yo.InvokeStore = void 0;
  var fR = require("async_hooks"),
    al =
      process.env.AWS_LAMBDA_NODEJS_NO_GLOBAL_AWSLAMBDA === "1" ||
      process.env.AWS_LAMBDA_NODEJS_NO_GLOBAL_AWSLAMBDA === "true";
  al || (globalThis.awslambda = globalThis.awslambda || {});
  var pR = {
      REQUEST_ID: Symbol("_AWS_LAMBDA_REQUEST_ID"),
      X_RAY_TRACE_ID: Symbol("_AWS_LAMBDA_X_RAY_TRACE_ID"),
    },
    cl = class {
      static storage = new fR.AsyncLocalStorage();
      static PROTECTED_KEYS = pR;
      static run(t, r) {
        return this.storage.run({ ...t }, r);
      }
      static getContext() {
        return this.storage.getStore();
      }
      static get(t) {
        return this.storage.getStore()?.[t];
      }
      static set(t, r) {
        if (this.isProtectedKey(t))
          throw new Error("Cannot modify protected Lambda context field");
        let n = this.storage.getStore();
        n && (n[t] = r);
      }
      static getRequestId() {
        return this.get(this.PROTECTED_KEYS.REQUEST_ID) ?? "-";
      }
      static getXRayTraceId() {
        return this.get(this.PROTECTED_KEYS.X_RAY_TRACE_ID);
      }
      static hasContext() {
        return this.storage.getStore() !== void 0;
      }
      static isProtectedKey(t) {
        return (
          t === this.PROTECTED_KEYS.REQUEST_ID ||
          t === this.PROTECTED_KEYS.X_RAY_TRACE_ID
        );
      }
    },
    Jo;
  !al && globalThis.awslambda?.InvokeStore
    ? (Jo = globalThis.awslambda.InvokeStore)
    : ((Jo = cl),
      !al && globalThis.awslambda && (globalThis.awslambda.InvokeStore = Jo));
  Yo.InvokeStore = Jo;
});
var ll = P((Xo) => {
  "use strict";
  Object.defineProperty(Xo, "__esModule", { value: !0 });
  Xo.recursionDetectionMiddleware = void 0;
  var mR = fh(),
    hR = me(),
    dl = "X-Amzn-Trace-Id",
    gR = "AWS_LAMBDA_FUNCTION_NAME",
    SR = "_X_AMZN_TRACE_ID",
    yR = () => (e) => async (t) => {
      let { request: r } = t;
      if (!hR.HttpRequest.isInstance(r)) return e(t);
      let n =
        Object.keys(r.headers ?? {}).find(
          (l) => l.toLowerCase() === dl.toLowerCase(),
        ) ?? dl;
      if (r.headers.hasOwnProperty(n)) return e(t);
      let s = process.env[gR],
        o = process.env[SR],
        a = mR.InvokeStore.getXRayTraceId() ?? o,
        d = (l) => typeof l == "string" && l.length > 0;
      return (d(s) && d(a) && (r.headers[dl] = a), e({ ...t, request: r }));
    };
  Xo.recursionDetectionMiddleware = yR;
});
var ls = P((yj, pl) => {
  "use strict";
  var Qo = Object.defineProperty,
    ER = Object.getOwnPropertyDescriptor,
    _R = Object.getOwnPropertyNames,
    wR = Object.prototype.hasOwnProperty,
    ph = (e, t) => Qo(e, "name", { value: t, configurable: !0 }),
    bR = (e, t) => {
      for (var r in t) Qo(e, r, { get: t[r], enumerable: !0 });
    },
    ul = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of _R(t))
          !wR.call(e, s) &&
            s !== r &&
            Qo(e, s, {
              get: () => t[s],
              enumerable: !(n = ER(t, s)) || n.enumerable,
            });
      return e;
    },
    xR = (e, t, r) => (ul(e, t, "default"), r && ul(r, t, "default")),
    vR = (e) => ul(Qo({}, "__esModule", { value: !0 }), e),
    fl = {};
  bR(fl, { getRecursionDetectionPlugin: () => IR });
  pl.exports = vR(fl);
  var TR = {
      step: "build",
      tags: ["RECURSION_DETECTION"],
      name: "recursionDetectionMiddleware",
      override: !0,
      priority: "low",
    },
    CR = ll(),
    IR = ph(
      (e) => ({
        applyToStack: ph((t) => {
          t.add((0, CR.recursionDetectionMiddleware)(), TR);
        }, "applyToStack"),
      }),
      "getRecursionDetectionPlugin",
    );
  xR(fl, ll(), pl.exports);
});
var ml,
  AR,
  mh = b(() => {
    ((ml = v(rr())),
      (AR = (e) =>
        e[ml.SMITHY_CONTEXT_KEY] || (e[ml.SMITHY_CONTEXT_KEY] = {})));
  });
var Ge = P((hl) => {
  "use strict";
  var hh = rr(),
    RR = (e) => e[hh.SMITHY_CONTEXT_KEY] || (e[hh.SMITHY_CONTEXT_KEY] = {}),
    NR = (e) => {
      if (typeof e == "function") return e;
      let t = Promise.resolve(e);
      return () => t;
    };
  hl.getSmithyContext = RR;
  hl.normalizeProvider = NR;
});
var gh,
  Sh = b(() => {
    gh = (e, t) => {
      if (!t || t.length === 0) return e;
      let r = [];
      for (let n of t)
        for (let s of e) s.schemeId.split("#")[1] === n && r.push(s);
      for (let n of e)
        r.find(({ schemeId: s }) => s === n.schemeId) || r.push(n);
      return r;
    };
  });
function PR(e) {
  let t = new Map();
  for (let r of e) t.set(r.schemeId, r);
  return t;
}
var yh,
  us,
  Zo = b(() => {
    yh = v(Ge());
    Sh();
    us = (e, t) => (r, n) => async (s) => {
      let o = e.httpAuthSchemeProvider(
          await t.httpAuthSchemeParametersProvider(e, n, s.input),
        ),
        i = e.authSchemePreference ? await e.authSchemePreference() : [],
        a = gh(o, i),
        d = PR(e.httpAuthSchemes),
        l = (0, yh.getSmithyContext)(n),
        p = [];
      for (let m of a) {
        let g = d.get(m.schemeId);
        if (!g) {
          p.push(
            `HttpAuthScheme \`${m.schemeId}\` was not enabled for this service.`,
          );
          continue;
        }
        let h = g.identityProvider(await t.identityProviderConfigProvider(e));
        if (!h) {
          p.push(
            `HttpAuthScheme \`${m.schemeId}\` did not have an IdentityProvider configured.`,
          );
          continue;
        }
        let { identityProperties: E = {}, signingProperties: C = {} } =
          m.propertiesExtractor?.(e, n) || {};
        ((m.identityProperties = Object.assign(m.identityProperties || {}, E)),
          (m.signingProperties = Object.assign(m.signingProperties || {}, C)),
          (l.selectedHttpAuthScheme = {
            httpAuthOption: m,
            identity: await h(m.identityProperties),
            signer: g.signer,
          }));
        break;
      }
      if (!l.selectedHttpAuthScheme)
        throw new Error(
          p.join(`
`),
        );
      return r(s);
    };
  });
var Eh,
  fs,
  _h = b(() => {
    Zo();
    ((Eh = {
      step: "serialize",
      tags: ["HTTP_AUTH_SCHEME"],
      name: "httpAuthSchemeMiddleware",
      override: !0,
      relation: "before",
      toMiddleware: "endpointV2Middleware",
    }),
      (fs = (
        e,
        {
          httpAuthSchemeParametersProvider: t,
          identityProviderConfigProvider: r,
        },
      ) => ({
        applyToStack: (n) => {
          n.addRelativeTo(
            us(e, {
              httpAuthSchemeParametersProvider: t,
              identityProviderConfigProvider: r,
            }),
            Eh,
          );
        },
      })));
  });
var sr = P((hn) => {
  "use strict";
  var OR = me(),
    wh = (e, t) => (r, n) => async (s) => {
      let { response: o } = await r(s);
      try {
        let i = await t(o, e);
        return { response: o, output: i };
      } catch (i) {
        if (
          (Object.defineProperty(i, "$response", { value: o }),
          !("$metadata" in i))
        ) {
          let a =
            "Deserialization error: to see the raw response, inspect the hidden field {error}.$response on this object.";
          try {
            i.message +=
              `
  ` + a;
          } catch {
            !n.logger || n.logger?.constructor?.name === "NoOpLogger"
              ? console.warn(a)
              : n.logger?.warn?.(a);
          }
          typeof i.$responseBodyText < "u" &&
            i.$response &&
            (i.$response.body = i.$responseBodyText);
          try {
            if (OR.HttpResponse.isInstance(o)) {
              let { headers: d = {} } = o,
                l = Object.entries(d);
              i.$metadata = {
                httpStatusCode: o.statusCode,
                requestId: gl(/^x-[\w-]+-request-?id$/, l),
                extendedRequestId: gl(/^x-[\w-]+-id-2$/, l),
                cfId: gl(/^x-[\w-]+-cf-id$/, l),
              };
            }
          } catch {}
        }
        throw i;
      }
    },
    gl = (e, t) => (t.find(([r]) => r.match(e)) || [void 0, void 0])[1],
    bh = (e, t) => (r, n) => async (s) => {
      let o = e,
        i =
          n.endpointV2?.url && o.urlParser
            ? async () => o.urlParser(n.endpointV2.url)
            : o.endpoint;
      if (!i) throw new Error("No valid endpoint provider available.");
      let a = await t(s.input, { ...e, endpoint: i });
      return r({ ...s, request: a });
    },
    xh = {
      name: "deserializerMiddleware",
      step: "deserialize",
      tags: ["DESERIALIZER"],
      override: !0,
    },
    vh = {
      name: "serializerMiddleware",
      step: "serialize",
      tags: ["SERIALIZER"],
      override: !0,
    };
  function DR(e, t, r) {
    return {
      applyToStack: (n) => {
        (n.add(wh(e, r), xh), n.add(bh(e, t), vh));
      },
    };
  }
  hn.deserializerMiddleware = wh;
  hn.deserializerMiddlewareOption = xh;
  hn.getSerdePlugin = DR;
  hn.serializerMiddleware = bh;
  hn.serializerMiddlewareOption = vh;
});
var Th,
  Ch,
  MR,
  Ih = b(() => {
    Th = v(sr());
    Zo();
    ((Ch = {
      step: "serialize",
      tags: ["HTTP_AUTH_SCHEME"],
      name: "httpAuthSchemeMiddleware",
      override: !0,
      relation: "before",
      toMiddleware: Th.serializerMiddlewareOption.name,
    }),
      (MR = (
        e,
        {
          httpAuthSchemeParametersProvider: t,
          identityProviderConfigProvider: r,
        },
      ) => ({
        applyToStack: (n) => {
          n.addRelativeTo(
            us(e, {
              httpAuthSchemeParametersProvider: t,
              identityProviderConfigProvider: r,
            }),
            Ch,
          );
        },
      })));
  });
var Ah = b(() => {
  Zo();
  _h();
  Ih();
});
var Rh,
  Nh,
  kR,
  FR,
  Sl,
  yl = b(() => {
    ((Rh = v(me())),
      (Nh = v(Ge())),
      (kR = (e) => (t) => {
        throw t;
      }),
      (FR = (e, t) => {}),
      (Sl = (e) => (t, r) => async (n) => {
        if (!Rh.HttpRequest.isInstance(n.request)) return t(n);
        let o = (0, Nh.getSmithyContext)(r).selectedHttpAuthScheme;
        if (!o)
          throw new Error(
            "No HttpAuthScheme was selected: unable to sign request",
          );
        let {
            httpAuthOption: { signingProperties: i = {} },
            identity: a,
            signer: d,
          } = o,
          l = await t({ ...n, request: await d.sign(n.request, a, i) }).catch(
            (d.errorHandler || kR)(i),
          );
        return ((d.successHandler || FR)(l.response, i), l);
      }));
  });
var Ph,
  ps,
  Oh = b(() => {
    yl();
    ((Ph = {
      step: "finalizeRequest",
      tags: ["HTTP_SIGNING"],
      name: "httpSigningMiddleware",
      aliases: ["apiKeyMiddleware", "tokenMiddleware", "awsAuthMiddleware"],
      override: !0,
      relation: "after",
      toMiddleware: "retryMiddleware",
    }),
      (ps = (e) => ({
        applyToStack: (t) => {
          t.addRelativeTo(Sl(e), Ph);
        },
      })));
  });
var Dh = b(() => {
  yl();
  Oh();
});
var or,
  Mh = b(() => {
    or = (e) => {
      if (typeof e == "function") return e;
      let t = Promise.resolve(e);
      return () => t;
    };
  });
function kh(e, t, r, n, s) {
  return async function* (i, a, ...d) {
    let l = a,
      p = i.startingToken ?? l[r],
      m = !0,
      g;
    for (; m; ) {
      if (((l[r] = p), s && (l[s] = l[s] ?? i.pageSize), i.client instanceof e))
        g = await LR(t, i.client, a, i.withCommand, ...d);
      else throw new Error(`Invalid client, expected instance of ${e.name}`);
      yield g;
      let h = p;
      ((p = $R(g, n)), (m = !!(p && (!i.stopOnSameToken || p !== h))));
    }
    return void 0;
  };
}
var LR,
  $R,
  Fh = b(() => {
    LR = async (e, t, r, n = (o) => o, ...s) => {
      let o = new e(r);
      return ((o = n(o) ?? o), await t.send(o, ...s));
    };
    $R = (e, t) => {
      let r = e,
        n = t.split(".");
      for (let s of n) {
        if (!r || typeof r != "object") return;
        r = r[s];
      }
      return r;
    };
  });
var El = P((Lh) => {
  "use strict";
  var UR = (e) =>
    (typeof ArrayBuffer == "function" && e instanceof ArrayBuffer) ||
    Object.prototype.toString.call(e) === "[object ArrayBuffer]";
  Lh.isArrayBuffer = UR;
});
var gn = P((wl) => {
  "use strict";
  var HR = El(),
    _l = require("buffer"),
    zR = (e, t = 0, r = e.byteLength - t) => {
      if (!HR.isArrayBuffer(e))
        throw new TypeError(
          `The "input" argument must be ArrayBuffer. Received type ${typeof e} (${e})`,
        );
      return _l.Buffer.from(e, t, r);
    },
    jR = (e, t) => {
      if (typeof e != "string")
        throw new TypeError(
          `The "input" argument must be of type string. Received type ${typeof e} (${e})`,
        );
      return t ? _l.Buffer.from(e, t) : _l.Buffer.from(e);
    };
  wl.fromArrayBuffer = zR;
  wl.fromString = jR;
});
var $h = P((ei) => {
  "use strict";
  Object.defineProperty(ei, "__esModule", { value: !0 });
  ei.fromBase64 = void 0;
  var BR = gn(),
    qR = /^[A-Za-z0-9+/]*={0,2}$/,
    VR = (e) => {
      if ((e.length * 3) % 4 !== 0)
        throw new TypeError("Incorrect padding on base64 string.");
      if (!qR.exec(e)) throw new TypeError("Invalid base64 string.");
      let t = (0, BR.fromString)(e, "base64");
      return new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
    };
  ei.fromBase64 = VR;
});
var Oe = P((ti) => {
  "use strict";
  var Uh = gn(),
    Hh = (e) => {
      let t = Uh.fromString(e, "utf8");
      return new Uint8Array(
        t.buffer,
        t.byteOffset,
        t.byteLength / Uint8Array.BYTES_PER_ELEMENT,
      );
    },
    GR = (e) =>
      typeof e == "string"
        ? Hh(e)
        : ArrayBuffer.isView(e)
          ? new Uint8Array(
              e.buffer,
              e.byteOffset,
              e.byteLength / Uint8Array.BYTES_PER_ELEMENT,
            )
          : new Uint8Array(e),
    WR = (e) => {
      if (typeof e == "string") return e;
      if (
        typeof e != "object" ||
        typeof e.byteOffset != "number" ||
        typeof e.byteLength != "number"
      )
        throw new Error(
          "@smithy/util-utf8: toUtf8 encoder function only accepts string | Uint8Array.",
        );
      return Uh.fromArrayBuffer(e.buffer, e.byteOffset, e.byteLength).toString(
        "utf8",
      );
    };
  ti.fromUtf8 = Hh;
  ti.toUint8Array = GR;
  ti.toUtf8 = WR;
});
var zh = P((ri) => {
  "use strict";
  Object.defineProperty(ri, "__esModule", { value: !0 });
  ri.toBase64 = void 0;
  var KR = gn(),
    JR = Oe(),
    YR = (e) => {
      let t;
      if (
        (typeof e == "string" ? (t = (0, JR.fromUtf8)(e)) : (t = e),
        typeof t != "object" ||
          typeof t.byteOffset != "number" ||
          typeof t.byteLength != "number")
      )
        throw new Error(
          "@smithy/util-base64: toBase64 encoder function only accepts string | Uint8Array.",
        );
      return (0, KR.fromArrayBuffer)(
        t.buffer,
        t.byteOffset,
        t.byteLength,
      ).toString("base64");
    };
  ri.toBase64 = YR;
});
var De = P((ms) => {
  "use strict";
  var jh = $h(),
    Bh = zh();
  Object.keys(jh).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(ms, e) &&
      Object.defineProperty(ms, e, {
        enumerable: !0,
        get: function () {
          return jh[e];
        },
      });
  });
  Object.keys(Bh).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(ms, e) &&
      Object.defineProperty(ms, e, {
        enumerable: !0,
        get: function () {
          return Bh[e];
        },
      });
  });
});
var xl = P((ni) => {
  "use strict";
  Object.defineProperty(ni, "__esModule", { value: !0 });
  ni.ChecksumStream = void 0;
  var XR = De(),
    QR = require("stream"),
    bl = class extends QR.Duplex {
      expectedChecksum;
      checksumSourceLocation;
      checksum;
      source;
      base64Encoder;
      constructor({
        expectedChecksum: t,
        checksum: r,
        source: n,
        checksumSourceLocation: s,
        base64Encoder: o,
      }) {
        if ((super(), typeof n.pipe == "function")) this.source = n;
        else
          throw new Error(
            `@smithy/util-stream: unsupported source type ${n?.constructor?.name ?? n} in ChecksumStream.`,
          );
        ((this.base64Encoder = o ?? XR.toBase64),
          (this.expectedChecksum = t),
          (this.checksum = r),
          (this.checksumSourceLocation = s),
          this.source.pipe(this));
      }
      _read(t) {}
      _write(t, r, n) {
        try {
          (this.checksum.update(t), this.push(t));
        } catch (s) {
          return n(s);
        }
        return n();
      }
      async _final(t) {
        try {
          let r = await this.checksum.digest(),
            n = this.base64Encoder(r);
          if (this.expectedChecksum !== n)
            return t(
              new Error(
                `Checksum mismatch: expected "${this.expectedChecksum}" but received "${n}" in response header "${this.checksumSourceLocation}".`,
              ),
            );
        } catch (r) {
          return t(r);
        }
        return (this.push(null), t());
      }
    };
  ni.ChecksumStream = bl;
});
var ir = P((Sn) => {
  "use strict";
  Object.defineProperty(Sn, "__esModule", { value: !0 });
  Sn.isBlob = Sn.isReadableStream = void 0;
  var ZR = (e) =>
    typeof ReadableStream == "function" &&
    (e?.constructor?.name === ReadableStream.name ||
      e instanceof ReadableStream);
  Sn.isReadableStream = ZR;
  var eN = (e) =>
    typeof Blob == "function" &&
    (e?.constructor?.name === Blob.name || e instanceof Blob);
  Sn.isBlob = eN;
});
var qh = P((si) => {
  "use strict";
  Object.defineProperty(si, "__esModule", { value: !0 });
  si.ChecksumStream = void 0;
  var tN =
      typeof ReadableStream == "function" ? ReadableStream : function () {},
    vl = class extends tN {};
  si.ChecksumStream = vl;
});
var Vh = P((oi) => {
  "use strict";
  Object.defineProperty(oi, "__esModule", { value: !0 });
  oi.createChecksumStream = void 0;
  var rN = De(),
    nN = ir(),
    sN = qh(),
    oN = ({
      expectedChecksum: e,
      checksum: t,
      source: r,
      checksumSourceLocation: n,
      base64Encoder: s,
    }) => {
      if (!(0, nN.isReadableStream)(r))
        throw new Error(
          `@smithy/util-stream: unsupported source type ${r?.constructor?.name ?? r} in ChecksumStream.`,
        );
      let o = s ?? rN.toBase64;
      if (typeof TransformStream != "function")
        throw new Error(
          "@smithy/util-stream: unable to instantiate ChecksumStream because API unavailable: ReadableStream/TransformStream.",
        );
      let i = new TransformStream({
        start() {},
        async transform(d, l) {
          (t.update(d), l.enqueue(d));
        },
        async flush(d) {
          let l = await t.digest(),
            p = o(l);
          if (e !== p) {
            let m = new Error(
              `Checksum mismatch: expected "${e}" but received "${p}" in response header "${n}".`,
            );
            d.error(m);
          } else d.terminate();
        },
      });
      r.pipeThrough(i);
      let a = i.readable;
      return (Object.setPrototypeOf(a, sN.ChecksumStream.prototype), a);
    };
  oi.createChecksumStream = oN;
});
var Gh = P((Tl) => {
  "use strict";
  Object.defineProperty(Tl, "__esModule", { value: !0 });
  Tl.createChecksumStream = dN;
  var iN = ir(),
    aN = xl(),
    cN = Vh();
  function dN(e) {
    return typeof ReadableStream == "function" &&
      (0, iN.isReadableStream)(e.source)
      ? (0, cN.createChecksumStream)(e)
      : new aN.ChecksumStream(e);
  }
});
var Il = P((ii) => {
  "use strict";
  Object.defineProperty(ii, "__esModule", { value: !0 });
  ii.ByteArrayCollector = void 0;
  var Cl = class {
    allocByteArray;
    byteLength = 0;
    byteArrays = [];
    constructor(t) {
      this.allocByteArray = t;
    }
    push(t) {
      (this.byteArrays.push(t), (this.byteLength += t.byteLength));
    }
    flush() {
      if (this.byteArrays.length === 1) {
        let n = this.byteArrays[0];
        return (this.reset(), n);
      }
      let t = this.allocByteArray(this.byteLength),
        r = 0;
      for (let n = 0; n < this.byteArrays.length; ++n) {
        let s = this.byteArrays[n];
        (t.set(s, r), (r += s.byteLength));
      }
      return (this.reset(), t);
    }
    reset() {
      ((this.byteArrays = []), (this.byteLength = 0));
    }
  };
  ii.ByteArrayCollector = Cl;
});
var Yh = P((Dt) => {
  "use strict";
  Object.defineProperty(Dt, "__esModule", { value: !0 });
  Dt.createBufferedReadable = void 0;
  Dt.createBufferedReadableStream = Wh;
  Dt.merge = Kh;
  Dt.flush = ai;
  Dt.sizeOf = yn;
  Dt.modeOf = Jh;
  var lN = Il();
  function Wh(e, t, r) {
    let n = e.getReader(),
      s = !1,
      o = 0,
      i = ["", new lN.ByteArrayCollector((l) => new Uint8Array(l))],
      a = -1,
      d = async (l) => {
        let { value: p, done: m } = await n.read(),
          g = p;
        if (m) {
          if (a !== -1) {
            let h = ai(i, a);
            yn(h) > 0 && l.enqueue(h);
          }
          l.close();
        } else {
          let h = Jh(g, !1);
          if ((a !== h && (a >= 0 && l.enqueue(ai(i, a)), (a = h)), a === -1)) {
            l.enqueue(g);
            return;
          }
          let E = yn(g);
          o += E;
          let C = yn(i[a]);
          if (E >= t && C === 0) l.enqueue(g);
          else {
            let I = Kh(i, a, g);
            (!s &&
              o > t * 2 &&
              ((s = !0),
              r?.warn(
                `@smithy/util-stream - stream chunk size ${E} is below threshold of ${t}, automatically buffering.`,
              )),
              I >= t ? l.enqueue(ai(i, a)) : await d(l));
          }
        }
      };
    return new ReadableStream({ pull: d });
  }
  Dt.createBufferedReadable = Wh;
  function Kh(e, t, r) {
    switch (t) {
      case 0:
        return ((e[0] += r), yn(e[0]));
      case 1:
      case 2:
        return (e[t].push(r), yn(e[t]));
    }
  }
  function ai(e, t) {
    switch (t) {
      case 0:
        let r = e[0];
        return ((e[0] = ""), r);
      case 1:
      case 2:
        return e[t].flush();
    }
    throw new Error(
      `@smithy/util-stream - invalid index ${t} given to flush()`,
    );
  }
  function yn(e) {
    return e?.byteLength ?? e?.length ?? 0;
  }
  function Jh(e, t = !0) {
    return t && typeof Buffer < "u" && e instanceof Buffer
      ? 2
      : e instanceof Uint8Array
        ? 1
        : typeof e == "string"
          ? 0
          : -1;
  }
});
var Qh = P((Al) => {
  "use strict";
  Object.defineProperty(Al, "__esModule", { value: !0 });
  Al.createBufferedReadable = pN;
  var uN = require("node:stream"),
    Xh = Il(),
    Mt = Yh(),
    fN = ir();
  function pN(e, t, r) {
    if ((0, fN.isReadableStream)(e))
      return (0, Mt.createBufferedReadableStream)(e, t, r);
    let n = new uN.Readable({ read() {} }),
      s = !1,
      o = 0,
      i = [
        "",
        new Xh.ByteArrayCollector((d) => new Uint8Array(d)),
        new Xh.ByteArrayCollector((d) => Buffer.from(new Uint8Array(d))),
      ],
      a = -1;
    return (
      e.on("data", (d) => {
        let l = (0, Mt.modeOf)(d, !0);
        if (
          (a !== l && (a >= 0 && n.push((0, Mt.flush)(i, a)), (a = l)),
          a === -1)
        ) {
          n.push(d);
          return;
        }
        let p = (0, Mt.sizeOf)(d);
        o += p;
        let m = (0, Mt.sizeOf)(i[a]);
        if (p >= t && m === 0) n.push(d);
        else {
          let g = (0, Mt.merge)(i, a, d);
          (!s &&
            o > t * 2 &&
            ((s = !0),
            r?.warn(
              `@smithy/util-stream - stream chunk size ${p} is below threshold of ${t}, automatically buffering.`,
            )),
            g >= t && n.push((0, Mt.flush)(i, a)));
        }
      }),
      e.on("end", () => {
        if (a !== -1) {
          let d = (0, Mt.flush)(i, a);
          (0, Mt.sizeOf)(d) > 0 && n.push(d);
        }
        n.push(null);
      }),
      n
    );
  }
});
var Zh = P((ci) => {
  "use strict";
  Object.defineProperty(ci, "__esModule", { value: !0 });
  ci.getAwsChunkedEncodingStream = void 0;
  var mN = require("stream"),
    hN = (e, t) => {
      let {
          base64Encoder: r,
          bodyLengthChecker: n,
          checksumAlgorithmFn: s,
          checksumLocationName: o,
          streamHasher: i,
        } = t,
        a = r !== void 0 && s !== void 0 && o !== void 0 && i !== void 0,
        d = a ? i(s, e) : void 0,
        l = new mN.Readable({ read: () => {} });
      return (
        e.on("data", (p) => {
          let m = n(p) || 0;
          (l.push(`${m.toString(16)}\r
`),
            l.push(p),
            l.push(`\r
`));
        }),
        e.on("end", async () => {
          if (
            (l.push(`0\r
`),
            a)
          ) {
            let p = r(await d);
            (l.push(`${o}:${p}\r
`),
              l.push(`\r
`));
          }
          l.push(null);
        }),
        l
      );
    };
  ci.getAwsChunkedEncodingStream = hN;
});
var eg = P((Rl) => {
  "use strict";
  Object.defineProperty(Rl, "__esModule", { value: !0 });
  Rl.headStream = gN;
  async function gN(e, t) {
    let r = 0,
      n = [],
      s = e.getReader(),
      o = !1;
    for (; !o; ) {
      let { done: d, value: l } = await s.read();
      if ((l && (n.push(l), (r += l?.byteLength ?? 0)), r >= t)) break;
      o = d;
    }
    s.releaseLock();
    let i = new Uint8Array(Math.min(t, r)),
      a = 0;
    for (let d of n) {
      if (d.byteLength > i.byteLength - a) {
        i.set(d.subarray(0, i.byteLength - a), a);
        break;
      } else i.set(d, a);
      a += d.length;
    }
    return i;
  }
});
var tg = P((di) => {
  "use strict";
  Object.defineProperty(di, "__esModule", { value: !0 });
  di.headStream = void 0;
  var SN = require("stream"),
    yN = eg(),
    EN = ir(),
    _N = (e, t) =>
      (0, EN.isReadableStream)(e)
        ? (0, yN.headStream)(e, t)
        : new Promise((r, n) => {
            let s = new Nl();
            ((s.limit = t),
              e.pipe(s),
              e.on("error", (o) => {
                (s.end(), n(o));
              }),
              s.on("error", n),
              s.on("finish", function () {
                let o = new Uint8Array(Buffer.concat(this.buffers));
                r(o);
              }));
          });
  di.headStream = _N;
  var Nl = class extends SN.Writable {
    buffers = [];
    limit = 1 / 0;
    bytesBuffered = 0;
    _write(t, r, n) {
      if (
        (this.buffers.push(t),
        (this.bytesBuffered += t.byteLength ?? 0),
        this.bytesBuffered >= this.limit)
      ) {
        let s = this.bytesBuffered - this.limit,
          o = this.buffers[this.buffers.length - 1];
        ((this.buffers[this.buffers.length - 1] = o.subarray(
          0,
          o.byteLength - s,
        )),
          this.emit("finish"));
      }
      n();
    }
  };
});
var Ol = P((Pl) => {
  "use strict";
  var rg = (e) => encodeURIComponent(e).replace(/[!'()*]/g, wN),
    wN = (e) => `%${e.charCodeAt(0).toString(16).toUpperCase()}`,
    bN = (e) => e.split("/").map(rg).join("/");
  Pl.escapeUri = rg;
  Pl.escapeUriPath = bN;
});
var Ml = P((ng) => {
  "use strict";
  var Dl = Ol();
  function xN(e) {
    let t = [];
    for (let r of Object.keys(e).sort()) {
      let n = e[r];
      if (((r = Dl.escapeUri(r)), Array.isArray(n)))
        for (let s = 0, o = n.length; s < o; s++)
          t.push(`${r}=${Dl.escapeUri(n[s])}`);
      else {
        let s = r;
        ((n || typeof n == "string") && (s += `=${Dl.escapeUri(n)}`),
          t.push(s));
      }
    }
    return t.join("&");
  }
  ng.buildQueryString = xN;
});
var zr = P((hs) => {
  "use strict";
  var ag = me(),
    cg = Ml(),
    kl = require("http"),
    Fl = require("https"),
    dg = require("stream"),
    Ll = require("http2"),
    vN = ["ECONNRESET", "EPIPE", "ETIMEDOUT"],
    lg = (e) => {
      let t = {};
      for (let r of Object.keys(e)) {
        let n = e[r];
        t[r] = Array.isArray(n) ? n.join(",") : n;
      }
      return t;
    },
    We = {
      setTimeout: (e, t) => setTimeout(e, t),
      clearTimeout: (e) => clearTimeout(e),
    },
    sg = 1e3,
    TN = (e, t, r = 0) => {
      if (!r) return -1;
      let n = (s) => {
        let o = We.setTimeout(() => {
            (e.destroy(),
              t(
                Object.assign(
                  new Error(
                    `Socket timed out without establishing a connection within ${r} ms`,
                  ),
                  { name: "TimeoutError" },
                ),
              ));
          }, r - s),
          i = (a) => {
            a?.connecting
              ? a.on("connect", () => {
                  We.clearTimeout(o);
                })
              : We.clearTimeout(o);
          };
        e.socket ? i(e.socket) : e.on("socket", i);
      };
      return r < 2e3 ? (n(0), 0) : We.setTimeout(n.bind(null, sg), sg);
    },
    CN = 3e3,
    IN = (e, { keepAlive: t, keepAliveMsecs: r }, n = CN) => {
      if (t !== !0) return -1;
      let s = () => {
        e.socket
          ? e.socket.setKeepAlive(t, r || 0)
          : e.on("socket", (o) => {
              o.setKeepAlive(t, r || 0);
            });
      };
      return n === 0 ? (s(), 0) : We.setTimeout(s, n);
    },
    og = 3e3,
    AN = (e, t, r = fg) => {
      let n = (s) => {
        let o = r - s,
          i = () => {
            (e.destroy(),
              t(
                Object.assign(new Error(`Connection timed out after ${r} ms`), {
                  name: "TimeoutError",
                }),
              ));
          };
        e.socket
          ? (e.socket.setTimeout(o, i),
            e.on("close", () => e.socket?.removeListener("timeout", i)))
          : e.setTimeout(o, i);
      };
      return 0 < r && r < 6e3
        ? (n(0), 0)
        : We.setTimeout(n.bind(null, r === 0 ? 0 : og), og);
    },
    ig = 6e3;
  async function ug(e, t, r = ig) {
    let n = t.headers ?? {},
      s = n.Expect || n.expect,
      o = -1,
      i = !0;
    (s === "100-continue" &&
      (i = await Promise.race([
        new Promise((a) => {
          o = Number(We.setTimeout(() => a(!0), Math.max(ig, r)));
        }),
        new Promise((a) => {
          (e.on("continue", () => {
            (We.clearTimeout(o), a(!0));
          }),
            e.on("response", () => {
              (We.clearTimeout(o), a(!1));
            }),
            e.on("error", () => {
              (We.clearTimeout(o), a(!1));
            }));
        }),
      ])),
      i && RN(e, t.body));
  }
  function RN(e, t) {
    if (t instanceof dg.Readable) {
      t.pipe(e);
      return;
    }
    if (t) {
      if (Buffer.isBuffer(t) || typeof t == "string") {
        e.end(t);
        return;
      }
      let r = t;
      if (
        typeof r == "object" &&
        r.buffer &&
        typeof r.byteOffset == "number" &&
        typeof r.byteLength == "number"
      ) {
        e.end(Buffer.from(r.buffer, r.byteOffset, r.byteLength));
        return;
      }
      e.end(Buffer.from(t));
      return;
    }
    e.end();
  }
  var fg = 0,
    $l = class e {
      config;
      configProvider;
      socketWarningTimestamp = 0;
      metadata = { handlerProtocol: "http/1.1" };
      static create(t) {
        return typeof t?.handle == "function" ? t : new e(t);
      }
      static checkSocketUsage(t, r, n = console) {
        let { sockets: s, requests: o, maxSockets: i } = t;
        if (typeof i != "number" || i === 1 / 0 || Date.now() - 15e3 < r)
          return r;
        if (s && o)
          for (let d in s) {
            let l = s[d]?.length ?? 0,
              p = o[d]?.length ?? 0;
            if (l >= i && p >= 2 * i)
              return (
                n?.warn?.(`@smithy/node-http-handler:WARN - socket usage at capacity=${l} and ${p} additional requests are enqueued.
See https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/node-configuring-maxsockets.html
or increase socketAcquisitionWarningTimeout=(millis) in the NodeHttpHandler config.`),
                Date.now()
              );
          }
        return r;
      }
      constructor(t) {
        this.configProvider = new Promise((r, n) => {
          typeof t == "function"
            ? t()
                .then((s) => {
                  r(this.resolveDefaultConfig(s));
                })
                .catch(n)
            : r(this.resolveDefaultConfig(t));
        });
      }
      resolveDefaultConfig(t) {
        let {
            requestTimeout: r,
            connectionTimeout: n,
            socketTimeout: s,
            socketAcquisitionWarningTimeout: o,
            httpAgent: i,
            httpsAgent: a,
          } = t || {},
          d = !0,
          l = 50;
        return {
          connectionTimeout: n,
          requestTimeout: r ?? s,
          socketAcquisitionWarningTimeout: o,
          httpAgent:
            i instanceof kl.Agent || typeof i?.destroy == "function"
              ? i
              : new kl.Agent({ keepAlive: d, maxSockets: l, ...i }),
          httpsAgent:
            a instanceof Fl.Agent || typeof a?.destroy == "function"
              ? a
              : new Fl.Agent({ keepAlive: d, maxSockets: l, ...a }),
          logger: console,
        };
      }
      destroy() {
        (this.config?.httpAgent?.destroy(), this.config?.httpsAgent?.destroy());
      }
      async handle(t, { abortSignal: r, requestTimeout: n } = {}) {
        return (
          this.config || (this.config = await this.configProvider),
          new Promise((s, o) => {
            let i,
              a = [],
              d = async (H) => {
                (await i, a.forEach(We.clearTimeout), s(H));
              },
              l = async (H) => {
                (await i, a.forEach(We.clearTimeout), o(H));
              };
            if (!this.config)
              throw new Error(
                "Node HTTP request handler config is not resolved",
              );
            if (r?.aborted) {
              let H = new Error("Request aborted");
              ((H.name = "AbortError"), l(H));
              return;
            }
            let p = t.protocol === "https:",
              m = p ? this.config.httpsAgent : this.config.httpAgent;
            a.push(
              We.setTimeout(
                () => {
                  this.socketWarningTimestamp = e.checkSocketUsage(
                    m,
                    this.socketWarningTimestamp,
                    this.config.logger,
                  );
                },
                this.config.socketAcquisitionWarningTimeout ??
                  (this.config.requestTimeout ?? 2e3) +
                    (this.config.connectionTimeout ?? 1e3),
              ),
            );
            let g = cg.buildQueryString(t.query || {}),
              h;
            if (t.username != null || t.password != null) {
              let H = t.username ?? "",
                se = t.password ?? "";
              h = `${H}:${se}`;
            }
            let E = t.path;
            (g && (E += `?${g}`), t.fragment && (E += `#${t.fragment}`));
            let C = t.hostname ?? "";
            C[0] === "[" && C.endsWith("]")
              ? (C = t.hostname.slice(1, -1))
              : (C = t.hostname);
            let I = {
                headers: t.headers,
                host: C,
                method: t.method,
                path: E,
                port: t.port,
                agent: m,
                auth: h,
              },
              O = (p ? Fl.request : kl.request)(I, (H) => {
                let se = new ag.HttpResponse({
                  statusCode: H.statusCode || -1,
                  reason: H.statusMessage,
                  headers: lg(H.headers),
                  body: H,
                });
                d({ response: se });
              });
            if (
              (O.on("error", (H) => {
                vN.includes(H.code)
                  ? l(Object.assign(H, { name: "TimeoutError" }))
                  : l(H);
              }),
              r)
            ) {
              let H = () => {
                O.destroy();
                let se = new Error("Request aborted");
                ((se.name = "AbortError"), l(se));
              };
              if (typeof r.addEventListener == "function") {
                let se = r;
                (se.addEventListener("abort", H, { once: !0 }),
                  O.once("close", () => se.removeEventListener("abort", H)));
              } else r.onabort = H;
            }
            let $ = n ?? this.config.requestTimeout;
            (a.push(TN(O, l, this.config.connectionTimeout)),
              a.push(AN(O, l, $)));
            let j = I.agent;
            (typeof j == "object" &&
              "keepAlive" in j &&
              a.push(
                IN(O, {
                  keepAlive: j.keepAlive,
                  keepAliveMsecs: j.keepAliveMsecs,
                }),
              ),
              (i = ug(O, t, $).catch(
                (H) => (a.forEach(We.clearTimeout), o(H)),
              )));
          })
        );
      }
      updateHttpClientConfig(t, r) {
        ((this.config = void 0),
          (this.configProvider = this.configProvider.then((n) => ({
            ...n,
            [t]: r,
          }))));
      }
      httpHandlerConfigs() {
        return this.config ?? {};
      }
    },
    Ul = class {
      sessions = [];
      constructor(t) {
        this.sessions = t ?? [];
      }
      poll() {
        if (this.sessions.length > 0) return this.sessions.shift();
      }
      offerLast(t) {
        this.sessions.push(t);
      }
      contains(t) {
        return this.sessions.includes(t);
      }
      remove(t) {
        this.sessions = this.sessions.filter((r) => r !== t);
      }
      [Symbol.iterator]() {
        return this.sessions[Symbol.iterator]();
      }
      destroy(t) {
        for (let r of this.sessions) r === t && (r.destroyed || r.destroy());
      }
    },
    Hl = class {
      constructor(t) {
        if (
          ((this.config = t),
          this.config.maxConcurrency && this.config.maxConcurrency <= 0)
        )
          throw new RangeError("maxConcurrency must be greater than zero.");
      }
      config;
      sessionCache = new Map();
      lease(t, r) {
        let n = this.getUrlString(t),
          s = this.sessionCache.get(n);
        if (s) {
          let d = s.poll();
          if (d && !this.config.disableConcurrency) return d;
        }
        let o = Ll.connect(n);
        (this.config.maxConcurrency &&
          o.settings(
            { maxConcurrentStreams: this.config.maxConcurrency },
            (d) => {
              if (d)
                throw new Error(
                  "Fail to set maxConcurrentStreams to " +
                    this.config.maxConcurrency +
                    "when creating new session for " +
                    t.destination.toString(),
                );
            },
          ),
          o.unref());
        let i = () => {
          (o.destroy(), this.deleteSession(n, o));
        };
        (o.on("goaway", i),
          o.on("error", i),
          o.on("frameError", i),
          o.on("close", () => this.deleteSession(n, o)),
          r.requestTimeout && o.setTimeout(r.requestTimeout, i));
        let a = this.sessionCache.get(n) || new Ul();
        return (a.offerLast(o), this.sessionCache.set(n, a), o);
      }
      deleteSession(t, r) {
        let n = this.sessionCache.get(t);
        n && n.contains(r) && (n.remove(r), this.sessionCache.set(t, n));
      }
      release(t, r) {
        let n = this.getUrlString(t);
        this.sessionCache.get(n)?.offerLast(r);
      }
      destroy() {
        for (let [t, r] of this.sessionCache) {
          for (let n of r) (n.destroyed || n.destroy(), r.remove(n));
          this.sessionCache.delete(t);
        }
      }
      setMaxConcurrentStreams(t) {
        if (t && t <= 0)
          throw new RangeError(
            "maxConcurrentStreams must be greater than zero.",
          );
        this.config.maxConcurrency = t;
      }
      setDisableConcurrentStreams(t) {
        this.config.disableConcurrency = t;
      }
      getUrlString(t) {
        return t.destination.toString();
      }
    },
    zl = class e {
      config;
      configProvider;
      metadata = { handlerProtocol: "h2" };
      connectionManager = new Hl({});
      static create(t) {
        return typeof t?.handle == "function" ? t : new e(t);
      }
      constructor(t) {
        this.configProvider = new Promise((r, n) => {
          typeof t == "function"
            ? t()
                .then((s) => {
                  r(s || {});
                })
                .catch(n)
            : r(t || {});
        });
      }
      destroy() {
        this.connectionManager.destroy();
      }
      async handle(t, { abortSignal: r, requestTimeout: n } = {}) {
        this.config ||
          ((this.config = await this.configProvider),
          this.connectionManager.setDisableConcurrentStreams(
            this.config.disableConcurrentStreams || !1,
          ),
          this.config.maxConcurrentStreams &&
            this.connectionManager.setMaxConcurrentStreams(
              this.config.maxConcurrentStreams,
            ));
        let { requestTimeout: s, disableConcurrentStreams: o } = this.config,
          i = n ?? s;
        return new Promise((a, d) => {
          let l = !1,
            p,
            m = async (ue) => {
              (await p, a(ue));
            },
            g = async (ue) => {
              (await p, d(ue));
            };
          if (r?.aborted) {
            l = !0;
            let ue = new Error("Request aborted");
            ((ue.name = "AbortError"), g(ue));
            return;
          }
          let { hostname: h, method: E, port: C, protocol: I, query: R } = t,
            O = "";
          if (t.username != null || t.password != null) {
            let ue = t.username ?? "",
              ve = t.password ?? "";
            O = `${ue}:${ve}@`;
          }
          let $ = `${I}//${O}${h}${C ? `:${C}` : ""}`,
            j = { destination: new URL($) },
            H = this.connectionManager.lease(j, {
              requestTimeout: this.config?.sessionTimeout,
              disableConcurrentStreams: o || !1,
            }),
            se = (ue) => {
              (o && this.destroySession(H), (l = !0), g(ue));
            },
            Le = cg.buildQueryString(R || {}),
            Ve = t.path;
          (Le && (Ve += `?${Le}`), t.fragment && (Ve += `#${t.fragment}`));
          let ge = H.request({
            ...t.headers,
            [Ll.constants.HTTP2_HEADER_PATH]: Ve,
            [Ll.constants.HTTP2_HEADER_METHOD]: E,
          });
          if (
            (H.ref(),
            ge.on("response", (ue) => {
              let ve = new ag.HttpResponse({
                statusCode: ue[":status"] || -1,
                headers: lg(ue),
                body: ge,
              });
              ((l = !0),
                m({ response: ve }),
                o && (H.close(), this.connectionManager.deleteSession($, H)));
            }),
            i &&
              ge.setTimeout(i, () => {
                ge.close();
                let ue = new Error(
                  `Stream timed out because of no activity for ${i} ms`,
                );
                ((ue.name = "TimeoutError"), se(ue));
              }),
            r)
          ) {
            let ue = () => {
              ge.close();
              let ve = new Error("Request aborted");
              ((ve.name = "AbortError"), se(ve));
            };
            if (typeof r.addEventListener == "function") {
              let ve = r;
              (ve.addEventListener("abort", ue, { once: !0 }),
                ge.once("close", () => ve.removeEventListener("abort", ue)));
            } else r.onabort = ue;
          }
          (ge.on("frameError", (ue, ve, mn) => {
            se(
              new Error(
                `Frame type id ${ue} in stream id ${mn} has failed with code ${ve}.`,
              ),
            );
          }),
            ge.on("error", se),
            ge.on("aborted", () => {
              se(
                new Error(
                  `HTTP/2 stream is abnormally aborted in mid-communication with result code ${ge.rstCode}.`,
                ),
              );
            }),
            ge.on("close", () => {
              (H.unref(),
                o && H.destroy(),
                l ||
                  se(
                    new Error(
                      "Unexpected error: http2 request did not get a response",
                    ),
                  ));
            }),
            (p = ug(ge, t, i)));
        });
      }
      updateHttpClientConfig(t, r) {
        ((this.config = void 0),
          (this.configProvider = this.configProvider.then((n) => ({
            ...n,
            [t]: r,
          }))));
      }
      httpHandlerConfigs() {
        return this.config ?? {};
      }
      destroySession(t) {
        t.destroyed || t.destroy();
      }
    },
    jl = class extends dg.Writable {
      bufferedBytes = [];
      _write(t, r, n) {
        (this.bufferedBytes.push(t), n());
      }
    },
    NN = (e) =>
      PN(e)
        ? ON(e)
        : new Promise((t, r) => {
            let n = new jl();
            (e.pipe(n),
              e.on("error", (s) => {
                (n.end(), r(s));
              }),
              n.on("error", r),
              n.on("finish", function () {
                let s = new Uint8Array(Buffer.concat(this.bufferedBytes));
                t(s);
              }));
          }),
    PN = (e) =>
      typeof ReadableStream == "function" && e instanceof ReadableStream;
  async function ON(e) {
    let t = [],
      r = e.getReader(),
      n = !1,
      s = 0;
    for (; !n; ) {
      let { done: a, value: d } = await r.read();
      (d && (t.push(d), (s += d.length)), (n = a));
    }
    let o = new Uint8Array(s),
      i = 0;
    for (let a of t) (o.set(a, i), (i += a.length));
    return o;
  }
  hs.DEFAULT_REQUEST_TIMEOUT = fg;
  hs.NodeHttp2Handler = zl;
  hs.NodeHttpHandler = $l;
  hs.streamCollector = NN;
});
var hg = P((ui) => {
  "use strict";
  var pg = me(),
    DN = Ml(),
    MN = De();
  function mg(e, t) {
    return new Request(e, t);
  }
  function kN(e = 0) {
    return new Promise((t, r) => {
      e &&
        setTimeout(() => {
          let n = new Error(`Request did not complete within ${e} ms`);
          ((n.name = "TimeoutError"), r(n));
        }, e);
    });
  }
  var li = { supported: void 0 },
    Bl = class e {
      config;
      configProvider;
      static create(t) {
        return typeof t?.handle == "function" ? t : new e(t);
      }
      constructor(t) {
        (typeof t == "function"
          ? (this.configProvider = t().then((r) => r || {}))
          : ((this.config = t ?? {}),
            (this.configProvider = Promise.resolve(this.config))),
          li.supported === void 0 &&
            (li.supported =
              typeof Request < "u" && "keepalive" in mg("https://[::1]")));
      }
      destroy() {}
      async handle(t, { abortSignal: r, requestTimeout: n } = {}) {
        this.config || (this.config = await this.configProvider);
        let s = n ?? this.config.requestTimeout,
          o = this.config.keepAlive === !0,
          i = this.config.credentials;
        if (r?.aborted) {
          let O = new Error("Request aborted");
          return ((O.name = "AbortError"), Promise.reject(O));
        }
        let a = t.path,
          d = DN.buildQueryString(t.query || {});
        (d && (a += `?${d}`), t.fragment && (a += `#${t.fragment}`));
        let l = "";
        if (t.username != null || t.password != null) {
          let O = t.username ?? "",
            $ = t.password ?? "";
          l = `${O}:${$}@`;
        }
        let { port: p, method: m } = t,
          g = `${t.protocol}//${l}${t.hostname}${p ? `:${p}` : ""}${a}`,
          h = m === "GET" || m === "HEAD" ? void 0 : t.body,
          E = {
            body: h,
            headers: new Headers(t.headers),
            method: m,
            credentials: i,
          };
        (this.config?.cache && (E.cache = this.config.cache),
          h && (E.duplex = "half"),
          typeof AbortController < "u" && (E.signal = r),
          li.supported && (E.keepalive = o),
          typeof this.config.requestInit == "function" &&
            Object.assign(E, this.config.requestInit(t)));
        let C = () => {},
          I = mg(g, E),
          R = [
            fetch(I).then((O) => {
              let $ = O.headers,
                j = {};
              for (let se of $.entries()) j[se[0]] = se[1];
              return O.body != null
                ? {
                    response: new pg.HttpResponse({
                      headers: j,
                      reason: O.statusText,
                      statusCode: O.status,
                      body: O.body,
                    }),
                  }
                : O.blob().then((se) => ({
                    response: new pg.HttpResponse({
                      headers: j,
                      reason: O.statusText,
                      statusCode: O.status,
                      body: se,
                    }),
                  }));
            }),
            kN(s),
          ];
        return (
          r &&
            R.push(
              new Promise((O, $) => {
                let j = () => {
                  let H = new Error("Request aborted");
                  ((H.name = "AbortError"), $(H));
                };
                if (typeof r.addEventListener == "function") {
                  let H = r;
                  (H.addEventListener("abort", j, { once: !0 }),
                    (C = () => H.removeEventListener("abort", j)));
                } else r.onabort = j;
              }),
            ),
          Promise.race(R).finally(C)
        );
      }
      updateHttpClientConfig(t, r) {
        ((this.config = void 0),
          (this.configProvider = this.configProvider.then(
            (n) => ((n[t] = r), n),
          )));
      }
      httpHandlerConfigs() {
        return this.config ?? {};
      }
    },
    FN = async (e) =>
      (typeof Blob == "function" && e instanceof Blob) ||
      e.constructor?.name === "Blob"
        ? Blob.prototype.arrayBuffer !== void 0
          ? new Uint8Array(await e.arrayBuffer())
          : LN(e)
        : $N(e);
  async function LN(e) {
    let t = await UN(e),
      r = MN.fromBase64(t);
    return new Uint8Array(r);
  }
  async function $N(e) {
    let t = [],
      r = e.getReader(),
      n = !1,
      s = 0;
    for (; !n; ) {
      let { done: a, value: d } = await r.read();
      (d && (t.push(d), (s += d.length)), (n = a));
    }
    let o = new Uint8Array(s),
      i = 0;
    for (let a of t) (o.set(a, i), (i += a.length));
    return o;
  }
  function UN(e) {
    return new Promise((t, r) => {
      let n = new FileReader();
      ((n.onloadend = () => {
        if (n.readyState !== 2) return r(new Error("Reader aborted too early"));
        let s = n.result ?? "",
          o = s.indexOf(","),
          i = o > -1 ? o + 1 : s.length;
        t(s.substring(i));
      }),
        (n.onabort = () => r(new Error("Read aborted"))),
        (n.onerror = () => r(n.error)),
        n.readAsDataURL(e));
    });
  }
  ui.FetchHttpHandler = Bl;
  ui.keepAliveSupport = li;
  ui.streamCollector = FN;
});
var Gl = P((Vl) => {
  "use strict";
  var gg = {},
    ql = {};
  for (let e = 0; e < 256; e++) {
    let t = e.toString(16).toLowerCase();
    (t.length === 1 && (t = `0${t}`), (gg[e] = t), (ql[t] = e));
  }
  function HN(e) {
    if (e.length % 2 !== 0)
      throw new Error("Hex encoded strings must have an even number length");
    let t = new Uint8Array(e.length / 2);
    for (let r = 0; r < e.length; r += 2) {
      let n = e.slice(r, r + 2).toLowerCase();
      if (n in ql) t[r / 2] = ql[n];
      else
        throw new Error(
          `Cannot decode unrecognized sequence ${n} as hexadecimal`,
        );
    }
    return t;
  }
  function zN(e) {
    let t = "";
    for (let r = 0; r < e.byteLength; r++) t += gg[e[r]];
    return t;
  }
  Vl.fromHex = HN;
  Vl.toHex = zN;
});
var _g = P((fi) => {
  "use strict";
  Object.defineProperty(fi, "__esModule", { value: !0 });
  fi.sdkStreamMixin = void 0;
  var jN = hg(),
    BN = De(),
    qN = Gl(),
    VN = Oe(),
    Sg = ir(),
    yg = "The stream has already been transformed.",
    GN = (e) => {
      if (!Eg(e) && !(0, Sg.isReadableStream)(e)) {
        let s = e?.__proto__?.constructor?.name || e;
        throw new Error(
          `Unexpected stream implementation, expect Blob or ReadableStream, got ${s}`,
        );
      }
      let t = !1,
        r = async () => {
          if (t) throw new Error(yg);
          return ((t = !0), await (0, jN.streamCollector)(e));
        },
        n = (s) => {
          if (typeof s.stream != "function")
            throw new Error(`Cannot transform payload Blob to web stream. Please make sure the Blob.stream() is polyfilled.
If you are using React Native, this API is not yet supported, see: https://react-native.canny.io/feature-requests/p/fetch-streaming-body`);
          return s.stream();
        };
      return Object.assign(e, {
        transformToByteArray: r,
        transformToString: async (s) => {
          let o = await r();
          if (s === "base64") return (0, BN.toBase64)(o);
          if (s === "hex") return (0, qN.toHex)(o);
          if (s === void 0 || s === "utf8" || s === "utf-8")
            return (0, VN.toUtf8)(o);
          if (typeof TextDecoder == "function")
            return new TextDecoder(s).decode(o);
          throw new Error(
            "TextDecoder is not available, please make sure polyfill is provided.",
          );
        },
        transformToWebStream: () => {
          if (t) throw new Error(yg);
          if (((t = !0), Eg(e))) return n(e);
          if ((0, Sg.isReadableStream)(e)) return e;
          throw new Error(`Cannot transform payload to web stream, got ${e}`);
        },
      });
    };
  fi.sdkStreamMixin = GN;
  var Eg = (e) => typeof Blob == "function" && e instanceof Blob;
});
var bg = P((pi) => {
  "use strict";
  Object.defineProperty(pi, "__esModule", { value: !0 });
  pi.sdkStreamMixin = void 0;
  var WN = zr(),
    KN = gn(),
    Wl = require("stream"),
    JN = _g(),
    wg = "The stream has already been transformed.",
    YN = (e) => {
      if (!(e instanceof Wl.Readable))
        try {
          return (0, JN.sdkStreamMixin)(e);
        } catch {
          let s = e?.__proto__?.constructor?.name || e;
          throw new Error(
            `Unexpected stream implementation, expect Stream.Readable instance, got ${s}`,
          );
        }
      let t = !1,
        r = async () => {
          if (t) throw new Error(wg);
          return ((t = !0), await (0, WN.streamCollector)(e));
        };
      return Object.assign(e, {
        transformToByteArray: r,
        transformToString: async (n) => {
          let s = await r();
          return n === void 0 || Buffer.isEncoding(n)
            ? (0, KN.fromArrayBuffer)(
                s.buffer,
                s.byteOffset,
                s.byteLength,
              ).toString(n)
            : new TextDecoder(n).decode(s);
        },
        transformToWebStream: () => {
          if (t) throw new Error(wg);
          if (e.readableFlowing !== null)
            throw new Error("The stream has been consumed by other callbacks.");
          if (typeof Wl.Readable.toWeb != "function")
            throw new Error(
              "Readable.toWeb() is not supported. Please ensure a polyfill is available.",
            );
          return ((t = !0), Wl.Readable.toWeb(e));
        },
      });
    };
  pi.sdkStreamMixin = YN;
});
var xg = P((Kl) => {
  "use strict";
  Object.defineProperty(Kl, "__esModule", { value: !0 });
  Kl.splitStream = XN;
  async function XN(e) {
    return (typeof e.stream == "function" && (e = e.stream()), e.tee());
  }
});
var Cg = P((Jl) => {
  "use strict";
  Object.defineProperty(Jl, "__esModule", { value: !0 });
  Jl.splitStream = ZN;
  var vg = require("stream"),
    QN = xg(),
    Tg = ir();
  async function ZN(e) {
    if ((0, Tg.isReadableStream)(e) || (0, Tg.isBlob)(e))
      return (0, QN.splitStream)(e);
    let t = new vg.PassThrough(),
      r = new vg.PassThrough();
    return (e.pipe(t), e.pipe(r), [t, r]);
  }
});
var mi = P((Re) => {
  "use strict";
  var kg = De(),
    Fg = Oe(),
    Ig = xl(),
    Ag = Gh(),
    Rg = Qh(),
    Ng = Zh(),
    Pg = tg(),
    Og = bg(),
    Dg = Cg(),
    Mg = ir();
  function eP(e, t = "utf-8") {
    return t === "base64" ? kg.toBase64(e) : Fg.toUtf8(e);
  }
  function tP(e, t) {
    return t === "base64"
      ? gs.mutate(kg.fromBase64(e))
      : gs.mutate(Fg.fromUtf8(e));
  }
  var gs = class e extends Uint8Array {
    static fromString(t, r = "utf-8") {
      if (typeof t == "string") return tP(t, r);
      throw new Error(
        `Unsupported conversion from ${typeof t} to Uint8ArrayBlobAdapter.`,
      );
    }
    static mutate(t) {
      return (Object.setPrototypeOf(t, e.prototype), t);
    }
    transformToString(t = "utf-8") {
      return eP(this, t);
    }
  };
  Re.Uint8ArrayBlobAdapter = gs;
  Object.keys(Ig).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Ig[e];
        },
      });
  });
  Object.keys(Ag).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Ag[e];
        },
      });
  });
  Object.keys(Rg).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Rg[e];
        },
      });
  });
  Object.keys(Ng).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Ng[e];
        },
      });
  });
  Object.keys(Pg).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Pg[e];
        },
      });
  });
  Object.keys(Og).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Og[e];
        },
      });
  });
  Object.keys(Dg).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Dg[e];
        },
      });
  });
  Object.keys(Mg).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Re, e) &&
      Object.defineProperty(Re, e, {
        enumerable: !0,
        get: function () {
          return Mg[e];
        },
      });
  });
});
var hi,
  ht,
  gi = b(() => {
    ((hi = v(mi())),
      (ht = async (e = new Uint8Array(), t) => {
        if (e instanceof Uint8Array) return hi.Uint8ArrayBlobAdapter.mutate(e);
        if (!e) return hi.Uint8ArrayBlobAdapter.mutate(new Uint8Array());
        let r = t.streamCollector(e);
        return hi.Uint8ArrayBlobAdapter.mutate(await r);
      }));
  });
function wt(e) {
  return encodeURIComponent(e).replace(/[!'()*]/g, function (t) {
    return "%" + t.charCodeAt(0).toString(16).toUpperCase();
  });
}
var Si = b(() => {});
var ot,
  Yl = b(() => {
    ot = (e) => (typeof e == "function" ? e() : e);
  });
var Lg,
  $g,
  Ug,
  Xl,
  Hg = b(() => {
    ((Lg = v(me())),
      ($g = v(Ge())),
      (Ug = (e) => (t, r) => async (n) => {
        let { response: s } = await t(n),
          { operationSchema: o } = (0, $g.getSmithyContext)(r);
        try {
          let i = await e.protocol.deserializeResponse(o, { ...e, ...r }, s);
          return { response: s, output: i };
        } catch (i) {
          if (
            (Object.defineProperty(i, "$response", { value: s }),
            !("$metadata" in i))
          ) {
            let a =
              "Deserialization error: to see the raw response, inspect the hidden field {error}.$response on this object.";
            try {
              i.message +=
                `
  ` + a;
            } catch {
              !r.logger || r.logger?.constructor?.name === "NoOpLogger"
                ? console.warn(a)
                : r.logger?.warn?.(a);
            }
            typeof i.$responseBodyText < "u" &&
              i.$response &&
              (i.$response.body = i.$responseBodyText);
            try {
              if (Lg.HttpResponse.isInstance(s)) {
                let { headers: d = {} } = s,
                  l = Object.entries(d);
                i.$metadata = {
                  httpStatusCode: s.statusCode,
                  requestId: Xl(/^x-[\w-]+-request-?id$/, l),
                  extendedRequestId: Xl(/^x-[\w-]+-id-2$/, l),
                  cfId: Xl(/^x-[\w-]+-cf-id$/, l),
                };
              }
            } catch {}
          }
          throw i;
        }
      }),
      (Xl = (e, t) => (t.find(([r]) => r.match(e)) || [void 0, void 0])[1]));
  });
var zg,
  jg,
  Bg = b(() => {
    ((zg = v(Ge())),
      (jg = (e) => (t, r) => async (n) => {
        let { operationSchema: s } = (0, zg.getSmithyContext)(r),
          o =
            r.endpointV2?.url && e.urlParser
              ? async () => e.urlParser(r.endpointV2.url)
              : e.endpoint,
          i = await e.protocol.serializeRequest(s, n.input, {
            ...e,
            ...r,
            endpoint: o,
          });
        return t({ ...n, request: i });
      }));
  });
function rP(e) {
  return {
    applyToStack: (t) => {
      (t.add(jg(e), Vg), t.add(Ug(e), qg), e.protocol.setSerdeContext(e));
    },
  };
}
var qg,
  Vg,
  Gg = b(() => {
    Hg();
    Bg();
    ((qg = {
      name: "deserializerMiddleware",
      step: "deserialize",
      tags: ["DESERIALIZER"],
      override: !0,
    }),
      (Vg = {
        name: "serializerMiddleware",
        step: "serialize",
        tags: ["SERIALIZER"],
        override: !0,
      }));
  });
var Te,
  Ql = b(() => {
    Te = class e {
      namespace;
      schemas;
      exceptions;
      static registries = new Map();
      constructor(t, r = new Map(), n = new Map()) {
        ((this.namespace = t), (this.schemas = r), (this.exceptions = n));
      }
      static for(t) {
        return (
          e.registries.has(t) || e.registries.set(t, new e(t)),
          e.registries.get(t)
        );
      }
      register(t, r) {
        let n = this.normalizeShapeId(t);
        this.schemas.set(n, r);
      }
      getSchema(t) {
        let r = this.normalizeShapeId(t);
        if (!this.schemas.has(r))
          throw new Error(`@smithy/core/schema - schema not found for ${r}`);
        return this.schemas.get(r);
      }
      registerError(t, r) {
        this.exceptions.set(t, r);
      }
      getErrorCtor(t) {
        return this.exceptions.get(t);
      }
      getBaseException() {
        for (let [t, r] of this.schemas.entries())
          if (
            t.startsWith("smithy.ts.sdk.synthetic.") &&
            t.endsWith("ServiceException")
          )
            return r;
      }
      find(t) {
        return [...this.schemas.values()].find(t);
      }
      clear() {
        (this.schemas.clear(), this.exceptions.clear());
      }
      normalizeShapeId(t) {
        return t.includes("#") ? t : this.namespace + "#" + t;
      }
      getNamespace(t) {
        return this.normalizeShapeId(t).split("#")[0];
      }
    };
  });
var ye,
  kt = b(() => {
    Ql();
    ye = class {
      name;
      namespace;
      traits;
      static assign(t, r) {
        let n = Object.assign(t, r);
        return (Te.for(n.namespace).register(n.name, n), n);
      }
      static [Symbol.hasInstance](t) {
        let r = this.prototype.isPrototypeOf(t);
        return !r && typeof t == "object" && t !== null
          ? t.symbol === this.symbol
          : r;
      }
      getName() {
        return this.namespace + "#" + this.name;
      }
    };
  });
var En,
  nP,
  Zl = b(() => {
    kt();
    ((En = class e extends ye {
      static symbol = Symbol.for("@smithy/lis");
      name;
      traits;
      valueSchema;
      symbol = e.symbol;
    }),
      (nP = (e, t, r, n) =>
        ye.assign(new En(), {
          name: t,
          namespace: e,
          traits: r,
          valueSchema: n,
        })));
  });
var _n,
  sP,
  eu = b(() => {
    kt();
    ((_n = class e extends ye {
      static symbol = Symbol.for("@smithy/map");
      name;
      traits;
      keySchema;
      valueSchema;
      symbol = e.symbol;
    }),
      (sP = (e, t, r, n, s) =>
        ye.assign(new _n(), {
          name: t,
          namespace: e,
          traits: r,
          keySchema: n,
          valueSchema: s,
        })));
  });
var yi,
  oP,
  Wg = b(() => {
    kt();
    ((yi = class e extends ye {
      static symbol = Symbol.for("@smithy/ope");
      name;
      traits;
      input;
      output;
      symbol = e.symbol;
    }),
      (oP = (e, t, r, n, s) =>
        ye.assign(new yi(), {
          name: t,
          namespace: e,
          traits: r,
          input: n,
          output: s,
        })));
  });
var ar,
  iP,
  Ei = b(() => {
    kt();
    ((ar = class e extends ye {
      static symbol = Symbol.for("@smithy/str");
      name;
      traits;
      memberNames;
      memberList;
      symbol = e.symbol;
    }),
      (iP = (e, t, r, n, s) =>
        ye.assign(new ar(), {
          name: t,
          namespace: e,
          traits: r,
          memberNames: n,
          memberList: s,
        })));
  });
var _i,
  aP,
  Kg = b(() => {
    kt();
    Ei();
    ((_i = class e extends ar {
      static symbol = Symbol.for("@smithy/err");
      ctor;
      symbol = e.symbol;
    }),
      (aP = (e, t, r, n, s, o) =>
        ye.assign(new _i(), {
          name: t,
          namespace: e,
          traits: r,
          memberNames: n,
          memberList: s,
          ctor: null,
        })));
  });
function cr(e) {
  if (typeof e == "object") return e;
  e = e | 0;
  let t = {},
    r = 0;
  for (let n of [
    "httpLabel",
    "idempotent",
    "idempotencyToken",
    "sensitive",
    "httpPayload",
    "httpResponseCode",
    "httpQueryParams",
  ])
    ((e >> r++) & 1) === 1 && (t[n] = 1);
  return t;
}
var tu = b(() => {});
function Ss(e, t) {
  if (e instanceof L)
    return Object.assign(e, { memberName: t, _isMemberSchema: !0 });
  let r = L;
  return new r(e, t);
}
var L,
  Jg = b(() => {
    Yl();
    Zl();
    eu();
    kt();
    Ei();
    tu();
    L = class e {
      ref;
      memberName;
      static symbol = Symbol.for("@smithy/nor");
      symbol = e.symbol;
      name;
      schema;
      _isMemberSchema;
      traits;
      memberTraits;
      normalizedTraits;
      constructor(t, r) {
        ((this.ref = t), (this.memberName = r));
        let n = [],
          s = t,
          o = t;
        for (this._isMemberSchema = !1; Array.isArray(s); )
          (n.push(s[1]), (s = s[0]), (o = ot(s)), (this._isMemberSchema = !0));
        if (n.length > 0) {
          this.memberTraits = {};
          for (let i = n.length - 1; i >= 0; --i) {
            let a = n[i];
            Object.assign(this.memberTraits, cr(a));
          }
        } else this.memberTraits = 0;
        if (o instanceof e) {
          let i = this.memberTraits;
          (Object.assign(this, o),
            (this.memberTraits = Object.assign(
              {},
              i,
              o.getMemberTraits(),
              this.getMemberTraits(),
            )),
            (this.normalizedTraits = void 0),
            (this.memberName = r ?? o.memberName));
          return;
        }
        if (
          ((this.schema = ot(o)),
          this.schema && typeof this.schema == "object"
            ? (this.traits = this.schema?.traits ?? {})
            : (this.traits = 0),
          (this.name =
            (this.schema instanceof ye ? this.schema.getName?.() : void 0) ??
            this.memberName ??
            String(o)),
          this._isMemberSchema && !r)
        )
          throw new Error(
            `@smithy/core/schema - NormalizedSchema member init ${this.getName(!0)} missing member name.`,
          );
      }
      static [Symbol.hasInstance](t) {
        return ye[Symbol.hasInstance].bind(this)(t);
      }
      static of(t) {
        let r = ot(t);
        if (r instanceof e) return r;
        if (Array.isArray(r)) {
          let [n, s] = r;
          if (n instanceof e)
            return (Object.assign(n.getMergedTraits(), cr(s)), n);
          throw new Error(
            `@smithy/core/schema - may not init unwrapped member schema=${JSON.stringify(t, null, 2)}.`,
          );
        }
        return new e(r);
      }
      getSchema() {
        return ot(this.schema?.schemaRef ?? this.schema);
      }
      getName(t = !1) {
        let { name: r } = this;
        return !t && r && r.includes("#") ? r.split("#")[1] : r || void 0;
      }
      getMemberName() {
        return this.memberName;
      }
      isMemberSchema() {
        return this._isMemberSchema;
      }
      isListSchema() {
        let t = this.getSchema();
        return typeof t == "number" ? t >= 64 && t < 128 : t instanceof En;
      }
      isMapSchema() {
        let t = this.getSchema();
        return typeof t == "number" ? t >= 128 && t <= 255 : t instanceof _n;
      }
      isStructSchema() {
        let t = this.getSchema();
        return (
          (t !== null && typeof t == "object" && "members" in t) ||
          t instanceof ar
        );
      }
      isBlobSchema() {
        let t = this.getSchema();
        return t === 21 || t === 42;
      }
      isTimestampSchema() {
        let t = this.getSchema();
        return typeof t == "number" && t >= 4 && t <= 7;
      }
      isUnitSchema() {
        return this.getSchema() === "unit";
      }
      isDocumentSchema() {
        return this.getSchema() === 15;
      }
      isStringSchema() {
        return this.getSchema() === 0;
      }
      isBooleanSchema() {
        return this.getSchema() === 2;
      }
      isNumericSchema() {
        return this.getSchema() === 1;
      }
      isBigIntegerSchema() {
        return this.getSchema() === 17;
      }
      isBigDecimalSchema() {
        return this.getSchema() === 19;
      }
      isStreaming() {
        let { streaming: t } = this.getMergedTraits();
        return !!t || this.getSchema() === 42;
      }
      isIdempotencyToken() {
        let t = (o) => (o & 4) === 4 || !!o?.idempotencyToken,
          { normalizedTraits: r, traits: n, memberTraits: s } = this;
        return t(r) || t(n) || t(s);
      }
      getMergedTraits() {
        return (
          this.normalizedTraits ??
          (this.normalizedTraits = {
            ...this.getOwnTraits(),
            ...this.getMemberTraits(),
          })
        );
      }
      getMemberTraits() {
        return cr(this.memberTraits);
      }
      getOwnTraits() {
        return cr(this.traits);
      }
      getKeySchema() {
        let [t, r] = [this.isDocumentSchema(), this.isMapSchema()];
        if (!t && !r)
          throw new Error(
            `@smithy/core/schema - cannot get key for non-map: ${this.getName(!0)}`,
          );
        let n = this.getSchema(),
          s = t ? 15 : (n?.keySchema ?? 0);
        return Ss([s, 0], "key");
      }
      getValueSchema() {
        let t = this.getSchema(),
          [r, n, s] = [
            this.isDocumentSchema(),
            this.isMapSchema(),
            this.isListSchema(),
          ],
          o =
            typeof t == "number"
              ? 63 & t
              : t && typeof t == "object" && (n || s)
                ? t.valueSchema
                : r
                  ? 15
                  : void 0;
        if (o != null) return Ss([o, 0], n ? "value" : "member");
        throw new Error(
          `@smithy/core/schema - ${this.getName(!0)} has no value member.`,
        );
      }
      getMemberSchema(t) {
        let r = this.getSchema();
        if (this.isStructSchema() && r.memberNames.includes(t)) {
          let n = r.memberNames.indexOf(t),
            s = r.memberList[n];
          return Ss(Array.isArray(s) ? s : [s, 0], t);
        }
        if (this.isDocumentSchema()) return Ss([15, 0], t);
        throw new Error(
          `@smithy/core/schema - ${this.getName(!0)} has no no member=${t}.`,
        );
      }
      getMemberSchemas() {
        let t = {};
        try {
          for (let [r, n] of this.structIterator()) t[r] = n;
        } catch {}
        return t;
      }
      getEventStreamMember() {
        if (this.isStructSchema()) {
          for (let [t, r] of this.structIterator())
            if (r.isStreaming() && r.isStructSchema()) return t;
        }
        return "";
      }
      *structIterator() {
        if (this.isUnitSchema()) return;
        if (!this.isStructSchema())
          throw new Error(
            "@smithy/core/schema - cannot iterate non-struct schema.",
          );
        let t = this.getSchema();
        for (let r = 0; r < t.memberNames.length; ++r)
          yield [t.memberNames[r], Ss([t.memberList[r], 0], t.memberNames[r])];
      }
    };
  });
var wi,
  cP,
  Yg = b(() => {
    kt();
    ((wi = class e extends ye {
      static symbol = Symbol.for("@smithy/sim");
      name;
      schemaRef;
      traits;
      symbol = e.symbol;
    }),
      (cP = (e, t, r, n) =>
        ye.assign(new wi(), {
          name: t,
          namespace: e,
          traits: n,
          schemaRef: r,
        })));
  });
var dP,
  Xg = b(() => {
    dP = {
      BLOB: 21,
      STREAMING_BLOB: 42,
      BOOLEAN: 2,
      STRING: 0,
      NUMERIC: 1,
      BIG_INTEGER: 17,
      BIG_DECIMAL: 19,
      DOCUMENT: 15,
      TIMESTAMP_DEFAULT: 4,
      TIMESTAMP_DATE_TIME: 5,
      TIMESTAMP_HTTP_DATE: 6,
      TIMESTAMP_EPOCH_SECONDS: 7,
      LIST_MODIFIER: 64,
      MAP_MODIFIER: 128,
    };
  });
var Qg = {};
st(Qg, {
  ErrorSchema: () => _i,
  ListSchema: () => En,
  MapSchema: () => _n,
  NormalizedSchema: () => L,
  OperationSchema: () => yi,
  SCHEMA: () => dP,
  Schema: () => ye,
  SimpleSchema: () => wi,
  StructureSchema: () => ar,
  TypeRegistry: () => Te,
  deref: () => ot,
  deserializerMiddlewareOption: () => qg,
  error: () => aP,
  getSchemaSerdePlugin: () => rP,
  list: () => nP,
  map: () => sP,
  op: () => oP,
  serializerMiddlewareOption: () => Vg,
  sim: () => cP,
  struct: () => iP,
  translateTraits: () => cr,
});
var we = b(() => {
  Yl();
  Gg();
  Zl();
  eu();
  Wg();
  Kg();
  Jg();
  kt();
  Yg();
  Ei();
  Xg();
  tu();
  Ql();
});
var lP,
  Zg = b(() => {
    lP = (e, t, r = (n) => n) => e;
  });
var uP,
  fP,
  ys,
  pP,
  bi,
  Es,
  mP,
  ru,
  nu,
  su,
  ou,
  hP,
  gP,
  eS,
  SP,
  yP,
  vi,
  EP,
  iu,
  _P,
  wn,
  au,
  wP,
  bP,
  xP,
  tS,
  rS,
  vP,
  TP,
  jr,
  cu,
  xi,
  _s,
  du = b(() => {
    ((uP = (e) => {
      switch (e) {
        case "true":
          return !0;
        case "false":
          return !1;
        default:
          throw new Error(`Unable to parse boolean value "${e}"`);
      }
    }),
      (fP = (e) => {
        if (e != null) {
          if (typeof e == "number") {
            if (
              ((e === 0 || e === 1) &&
                _s.warn(xi(`Expected boolean, got ${typeof e}: ${e}`)),
              e === 0)
            )
              return !1;
            if (e === 1) return !0;
          }
          if (typeof e == "string") {
            let t = e.toLowerCase();
            if (
              ((t === "false" || t === "true") &&
                _s.warn(xi(`Expected boolean, got ${typeof e}: ${e}`)),
              t === "false")
            )
              return !1;
            if (t === "true") return !0;
          }
          if (typeof e == "boolean") return e;
          throw new TypeError(`Expected boolean, got ${typeof e}: ${e}`);
        }
      }),
      (ys = (e) => {
        if (e != null) {
          if (typeof e == "string") {
            let t = parseFloat(e);
            if (!Number.isNaN(t))
              return (
                String(t) !== String(e) &&
                  _s.warn(xi(`Expected number but observed string: ${e}`)),
                t
              );
          }
          if (typeof e == "number") return e;
          throw new TypeError(`Expected number, got ${typeof e}: ${e}`);
        }
      }),
      (pP = Math.ceil(34028234663852886e22)),
      (bi = (e) => {
        let t = ys(e);
        if (
          t !== void 0 &&
          !Number.isNaN(t) &&
          t !== 1 / 0 &&
          t !== -1 / 0 &&
          Math.abs(t) > pP
        )
          throw new TypeError(`Expected 32-bit float, got ${e}`);
        return t;
      }),
      (Es = (e) => {
        if (e != null) {
          if (Number.isInteger(e) && !Number.isNaN(e)) return e;
          throw new TypeError(`Expected integer, got ${typeof e}: ${e}`);
        }
      }),
      (mP = Es),
      (ru = (e) => ou(e, 32)),
      (nu = (e) => ou(e, 16)),
      (su = (e) => ou(e, 8)),
      (ou = (e, t) => {
        let r = Es(e);
        if (r !== void 0 && hP(r, t) !== r)
          throw new TypeError(`Expected ${t}-bit integer, got ${e}`);
        return r;
      }),
      (hP = (e, t) => {
        switch (t) {
          case 32:
            return Int32Array.of(e)[0];
          case 16:
            return Int16Array.of(e)[0];
          case 8:
            return Int8Array.of(e)[0];
        }
      }),
      (gP = (e, t) => {
        if (e == null)
          throw t
            ? new TypeError(`Expected a non-null value for ${t}`)
            : new TypeError("Expected a non-null value");
        return e;
      }),
      (eS = (e) => {
        if (e == null) return;
        if (typeof e == "object" && !Array.isArray(e)) return e;
        let t = Array.isArray(e) ? "array" : typeof e;
        throw new TypeError(`Expected object, got ${t}: ${e}`);
      }),
      (SP = (e) => {
        if (e != null) {
          if (typeof e == "string") return e;
          if (["boolean", "number", "bigint"].includes(typeof e))
            return (
              _s.warn(xi(`Expected string, got ${typeof e}: ${e}`)),
              String(e)
            );
          throw new TypeError(`Expected string, got ${typeof e}: ${e}`);
        }
      }),
      (yP = (e) => {
        if (e == null) return;
        let t = eS(e),
          r = Object.entries(t)
            .filter(([, n]) => n != null)
            .map(([n]) => n);
        if (r.length === 0)
          throw new TypeError(
            "Unions must have exactly one non-null member. None were found.",
          );
        if (r.length > 1)
          throw new TypeError(
            `Unions must have exactly one non-null member. Keys ${r} were not null.`,
          );
        return t;
      }),
      (vi = (e) => ys(typeof e == "string" ? wn(e) : e)),
      (EP = vi),
      (iu = (e) => bi(typeof e == "string" ? wn(e) : e)),
      (_P =
        /(-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)|(-?Infinity)|(NaN)/g),
      (wn = (e) => {
        let t = e.match(_P);
        if (t === null || t[0].length !== e.length)
          throw new TypeError("Expected real number, got implicit NaN");
        return parseFloat(e);
      }),
      (au = (e) => (typeof e == "string" ? tS(e) : ys(e))),
      (wP = au),
      (bP = au),
      (xP = (e) => (typeof e == "string" ? tS(e) : bi(e))),
      (tS = (e) => {
        switch (e) {
          case "NaN":
            return NaN;
          case "Infinity":
            return 1 / 0;
          case "-Infinity":
            return -1 / 0;
          default:
            throw new Error(`Unable to parse float value: ${e}`);
        }
      }),
      (rS = (e) => Es(typeof e == "string" ? wn(e) : e)),
      (vP = rS),
      (TP = (e) => ru(typeof e == "string" ? wn(e) : e)),
      (jr = (e) => nu(typeof e == "string" ? wn(e) : e)),
      (cu = (e) => su(typeof e == "string" ? wn(e) : e)),
      (xi = (e) =>
        String(new TypeError(e).stack || e)
          .split(
            `
`,
          )
          .slice(0, 5)
          .filter((t) => !t.includes("stackTraceWarning")).join(`
`)),
      (_s = { warn: console.warn }));
  });
function bs(e) {
  let t = e.getUTCFullYear(),
    r = e.getUTCMonth(),
    n = e.getUTCDay(),
    s = e.getUTCDate(),
    o = e.getUTCHours(),
    i = e.getUTCMinutes(),
    a = e.getUTCSeconds(),
    d = s < 10 ? `0${s}` : `${s}`,
    l = o < 10 ? `0${o}` : `${o}`,
    p = i < 10 ? `0${i}` : `${i}`,
    m = a < 10 ? `0${a}` : `${a}`;
  return `${CP[n]}, ${d} ${uu[r]} ${t} ${l}:${p}:${m} GMT`;
}
var CP,
  uu,
  IP,
  AP,
  RP,
  fu,
  NP,
  PP,
  OP,
  pu,
  mu,
  ws,
  DP,
  MP,
  kP,
  lu,
  FP,
  LP,
  $P,
  bt,
  UP,
  HP,
  bn,
  nS = b(() => {
    du();
    ((CP = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]),
      (uu = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ]));
    ((IP = new RegExp(
      /^(\d{4})-(\d{2})-(\d{2})[tT](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?[zZ]$/,
    )),
      (AP = (e) => {
        if (e == null) return;
        if (typeof e != "string")
          throw new TypeError(
            "RFC-3339 date-times must be expressed as strings",
          );
        let t = IP.exec(e);
        if (!t) throw new TypeError("Invalid RFC-3339 date-time value");
        let [r, n, s, o, i, a, d, l] = t,
          p = jr(bn(n)),
          m = bt(s, "month", 1, 12),
          g = bt(o, "day", 1, 31);
        return ws(p, m, g, {
          hours: i,
          minutes: a,
          seconds: d,
          fractionalMilliseconds: l,
        });
      }),
      (RP = new RegExp(
        /^(\d{4})-(\d{2})-(\d{2})[tT](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(([-+]\d{2}\:\d{2})|[zZ])$/,
      )),
      (fu = (e) => {
        if (e == null) return;
        if (typeof e != "string")
          throw new TypeError(
            "RFC-3339 date-times must be expressed as strings",
          );
        let t = RP.exec(e);
        if (!t) throw new TypeError("Invalid RFC-3339 date-time value");
        let [r, n, s, o, i, a, d, l, p] = t,
          m = jr(bn(n)),
          g = bt(s, "month", 1, 12),
          h = bt(o, "day", 1, 31),
          E = ws(m, g, h, {
            hours: i,
            minutes: a,
            seconds: d,
            fractionalMilliseconds: l,
          });
        return (p.toUpperCase() != "Z" && E.setTime(E.getTime() - HP(p)), E);
      }),
      (NP = new RegExp(
        /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d{2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/,
      )),
      (PP = new RegExp(
        /^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d{2})-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/,
      )),
      (OP = new RegExp(
        /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( [1-9]|\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? (\d{4})$/,
      )),
      (pu = (e) => {
        if (e == null) return;
        if (typeof e != "string")
          throw new TypeError(
            "RFC-7231 date-times must be expressed as strings",
          );
        let t = NP.exec(e);
        if (t) {
          let [r, n, s, o, i, a, d, l] = t;
          return ws(jr(bn(o)), lu(s), bt(n, "day", 1, 31), {
            hours: i,
            minutes: a,
            seconds: d,
            fractionalMilliseconds: l,
          });
        }
        if (((t = PP.exec(e)), t)) {
          let [r, n, s, o, i, a, d, l] = t;
          return kP(
            ws(DP(o), lu(s), bt(n, "day", 1, 31), {
              hours: i,
              minutes: a,
              seconds: d,
              fractionalMilliseconds: l,
            }),
          );
        }
        if (((t = OP.exec(e)), t)) {
          let [r, n, s, o, i, a, d, l] = t;
          return ws(jr(bn(l)), lu(n), bt(s.trimLeft(), "day", 1, 31), {
            hours: o,
            minutes: i,
            seconds: a,
            fractionalMilliseconds: d,
          });
        }
        throw new TypeError("Invalid RFC-7231 date-time value");
      }),
      (mu = (e) => {
        if (e == null) return;
        let t;
        if (typeof e == "number") t = e;
        else if (typeof e == "string") t = vi(e);
        else if (typeof e == "object" && e.tag === 1) t = e.value;
        else
          throw new TypeError(
            "Epoch timestamps must be expressed as floating point numbers or their string representation",
          );
        if (Number.isNaN(t) || t === 1 / 0 || t === -1 / 0)
          throw new TypeError(
            "Epoch timestamps must be valid, non-Infinite, non-NaN numerics",
          );
        return new Date(Math.round(t * 1e3));
      }),
      (ws = (e, t, r, n) => {
        let s = t - 1;
        return (
          LP(e, s, r),
          new Date(
            Date.UTC(
              e,
              s,
              r,
              bt(n.hours, "hour", 0, 23),
              bt(n.minutes, "minute", 0, 59),
              bt(n.seconds, "seconds", 0, 60),
              UP(n.fractionalMilliseconds),
            ),
          )
        );
      }),
      (DP = (e) => {
        let t = new Date().getUTCFullYear(),
          r = Math.floor(t / 100) * 100 + jr(bn(e));
        return r < t ? r + 100 : r;
      }),
      (MP = 50 * 365 * 24 * 60 * 60 * 1e3),
      (kP = (e) =>
        e.getTime() - new Date().getTime() > MP
          ? new Date(
              Date.UTC(
                e.getUTCFullYear() - 100,
                e.getUTCMonth(),
                e.getUTCDate(),
                e.getUTCHours(),
                e.getUTCMinutes(),
                e.getUTCSeconds(),
                e.getUTCMilliseconds(),
              ),
            )
          : e),
      (lu = (e) => {
        let t = uu.indexOf(e);
        if (t < 0) throw new TypeError(`Invalid month: ${e}`);
        return t + 1;
      }),
      (FP = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]),
      (LP = (e, t, r) => {
        let n = FP[t];
        if ((t === 1 && $P(e) && (n = 29), r > n))
          throw new TypeError(`Invalid day for ${uu[t]} in ${e}: ${r}`);
      }),
      ($P = (e) => e % 4 === 0 && (e % 100 !== 0 || e % 400 === 0)),
      (bt = (e, t, r, n) => {
        let s = cu(bn(e));
        if (s < r || s > n)
          throw new TypeError(`${t} must be between ${r} and ${n}, inclusive`);
        return s;
      }),
      (UP = (e) => (e == null ? 0 : iu("0." + e) * 1e3)),
      (HP = (e) => {
        let t = e[0],
          r = 1;
        if (t == "+") r = 1;
        else if (t == "-") r = -1;
        else throw new TypeError(`Offset direction, ${t}, must be "+" or "-"`);
        let n = Number(e.substring(1, 3)),
          s = Number(e.substring(4, 6));
        return r * (n * 60 + s) * 60 * 1e3;
      }),
      (bn = (e) => {
        let t = 0;
        for (; t < e.length - 1 && e.charAt(t) === "0"; ) t++;
        return t === 0 ? e : e.slice(t);
      }));
  });
var xs = {};
st(xs, {
  __addDisposableResource: () => AS,
  __assign: () => Ti,
  __asyncDelegator: () => _S,
  __asyncGenerator: () => ES,
  __asyncValues: () => wS,
  __await: () => xn,
  __awaiter: () => pS,
  __classPrivateFieldGet: () => TS,
  __classPrivateFieldIn: () => IS,
  __classPrivateFieldSet: () => CS,
  __createBinding: () => Ii,
  __decorate: () => iS,
  __disposeResources: () => RS,
  __esDecorate: () => cS,
  __exportStar: () => hS,
  __extends: () => sS,
  __generator: () => mS,
  __importDefault: () => vS,
  __importStar: () => xS,
  __makeTemplateObject: () => bS,
  __metadata: () => fS,
  __param: () => aS,
  __propKey: () => lS,
  __read: () => Su,
  __rest: () => oS,
  __rewriteRelativeImportExtension: () => NS,
  __runInitializers: () => dS,
  __setFunctionName: () => uS,
  __spread: () => gS,
  __spreadArray: () => yS,
  __spreadArrays: () => SS,
  __values: () => Ci,
  default: () => BP,
});
function sS(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError(
      "Class extends value " + String(t) + " is not a constructor or null",
    );
  hu(e, t);
  function r() {
    this.constructor = e;
  }
  e.prototype =
    t === null ? Object.create(t) : ((r.prototype = t.prototype), new r());
}
function oS(e, t) {
  var r = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) &&
      t.indexOf(n) < 0 &&
      (r[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var s = 0, n = Object.getOwnPropertySymbols(e); s < n.length; s++)
      t.indexOf(n[s]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, n[s]) &&
        (r[n[s]] = e[n[s]]);
  return r;
}
function iS(e, t, r, n) {
  var s = arguments.length,
    o =
      s < 3 ? t : n === null ? (n = Object.getOwnPropertyDescriptor(t, r)) : n,
    i;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    o = Reflect.decorate(e, t, r, n);
  else
    for (var a = e.length - 1; a >= 0; a--)
      (i = e[a]) && (o = (s < 3 ? i(o) : s > 3 ? i(t, r, o) : i(t, r)) || o);
  return (s > 3 && o && Object.defineProperty(t, r, o), o);
}
function aS(e, t) {
  return function (r, n) {
    t(r, n, e);
  };
}
function cS(e, t, r, n, s, o) {
  function i(R) {
    if (R !== void 0 && typeof R != "function")
      throw new TypeError("Function expected");
    return R;
  }
  for (
    var a = n.kind,
      d = a === "getter" ? "get" : a === "setter" ? "set" : "value",
      l = !t && e ? (n.static ? e : e.prototype) : null,
      p = t || (l ? Object.getOwnPropertyDescriptor(l, n.name) : {}),
      m,
      g = !1,
      h = r.length - 1;
    h >= 0;
    h--
  ) {
    var E = {};
    for (var C in n) E[C] = C === "access" ? {} : n[C];
    for (var C in n.access) E.access[C] = n.access[C];
    E.addInitializer = function (R) {
      if (g)
        throw new TypeError(
          "Cannot add initializers after decoration has completed",
        );
      o.push(i(R || null));
    };
    var I = (0, r[h])(a === "accessor" ? { get: p.get, set: p.set } : p[d], E);
    if (a === "accessor") {
      if (I === void 0) continue;
      if (I === null || typeof I != "object")
        throw new TypeError("Object expected");
      ((m = i(I.get)) && (p.get = m),
        (m = i(I.set)) && (p.set = m),
        (m = i(I.init)) && s.unshift(m));
    } else (m = i(I)) && (a === "field" ? s.unshift(m) : (p[d] = m));
  }
  (l && Object.defineProperty(l, n.name, p), (g = !0));
}
function dS(e, t, r) {
  for (var n = arguments.length > 2, s = 0; s < t.length; s++)
    r = n ? t[s].call(e, r) : t[s].call(e);
  return n ? r : void 0;
}
function lS(e) {
  return typeof e == "symbol" ? e : "".concat(e);
}
function uS(e, t, r) {
  return (
    typeof t == "symbol" &&
      (t = t.description ? "[".concat(t.description, "]") : ""),
    Object.defineProperty(e, "name", {
      configurable: !0,
      value: r ? "".concat(r, " ", t) : t,
    })
  );
}
function fS(e, t) {
  if (typeof Reflect == "object" && typeof Reflect.metadata == "function")
    return Reflect.metadata(e, t);
}
function pS(e, t, r, n) {
  function s(o) {
    return o instanceof r
      ? o
      : new r(function (i) {
          i(o);
        });
  }
  return new (r || (r = Promise))(function (o, i) {
    function a(p) {
      try {
        l(n.next(p));
      } catch (m) {
        i(m);
      }
    }
    function d(p) {
      try {
        l(n.throw(p));
      } catch (m) {
        i(m);
      }
    }
    function l(p) {
      p.done ? o(p.value) : s(p.value).then(a, d);
    }
    l((n = n.apply(e, t || [])).next());
  });
}
function mS(e, t) {
  var r = {
      label: 0,
      sent: function () {
        if (o[0] & 1) throw o[1];
        return o[1];
      },
      trys: [],
      ops: [],
    },
    n,
    s,
    o,
    i = Object.create(
      (typeof Iterator == "function" ? Iterator : Object).prototype,
    );
  return (
    (i.next = a(0)),
    (i.throw = a(1)),
    (i.return = a(2)),
    typeof Symbol == "function" &&
      (i[Symbol.iterator] = function () {
        return this;
      }),
    i
  );
  function a(l) {
    return function (p) {
      return d([l, p]);
    };
  }
  function d(l) {
    if (n) throw new TypeError("Generator is already executing.");
    for (; i && ((i = 0), l[0] && (r = 0)), r; )
      try {
        if (
          ((n = 1),
          s &&
            (o =
              l[0] & 2
                ? s.return
                : l[0]
                  ? s.throw || ((o = s.return) && o.call(s), 0)
                  : s.next) &&
            !(o = o.call(s, l[1])).done)
        )
          return o;
        switch (((s = 0), o && (l = [l[0] & 2, o.value]), l[0])) {
          case 0:
          case 1:
            o = l;
            break;
          case 4:
            return (r.label++, { value: l[1], done: !1 });
          case 5:
            (r.label++, (s = l[1]), (l = [0]));
            continue;
          case 7:
            ((l = r.ops.pop()), r.trys.pop());
            continue;
          default:
            if (
              ((o = r.trys),
              !(o = o.length > 0 && o[o.length - 1]) &&
                (l[0] === 6 || l[0] === 2))
            ) {
              r = 0;
              continue;
            }
            if (l[0] === 3 && (!o || (l[1] > o[0] && l[1] < o[3]))) {
              r.label = l[1];
              break;
            }
            if (l[0] === 6 && r.label < o[1]) {
              ((r.label = o[1]), (o = l));
              break;
            }
            if (o && r.label < o[2]) {
              ((r.label = o[2]), r.ops.push(l));
              break;
            }
            (o[2] && r.ops.pop(), r.trys.pop());
            continue;
        }
        l = t.call(e, r);
      } catch (p) {
        ((l = [6, p]), (s = 0));
      } finally {
        n = o = 0;
      }
    if (l[0] & 5) throw l[1];
    return { value: l[0] ? l[1] : void 0, done: !0 };
  }
}
function hS(e, t) {
  for (var r in e)
    r !== "default" &&
      !Object.prototype.hasOwnProperty.call(t, r) &&
      Ii(t, e, r);
}
function Ci(e) {
  var t = typeof Symbol == "function" && Symbol.iterator,
    r = t && e[t],
    n = 0;
  if (r) return r.call(e);
  if (e && typeof e.length == "number")
    return {
      next: function () {
        return (
          e && n >= e.length && (e = void 0),
          { value: e && e[n++], done: !e }
        );
      },
    };
  throw new TypeError(
    t ? "Object is not iterable." : "Symbol.iterator is not defined.",
  );
}
function Su(e, t) {
  var r = typeof Symbol == "function" && e[Symbol.iterator];
  if (!r) return e;
  var n = r.call(e),
    s,
    o = [],
    i;
  try {
    for (; (t === void 0 || t-- > 0) && !(s = n.next()).done; ) o.push(s.value);
  } catch (a) {
    i = { error: a };
  } finally {
    try {
      s && !s.done && (r = n.return) && r.call(n);
    } finally {
      if (i) throw i.error;
    }
  }
  return o;
}
function gS() {
  for (var e = [], t = 0; t < arguments.length; t++)
    e = e.concat(Su(arguments[t]));
  return e;
}
function SS() {
  for (var e = 0, t = 0, r = arguments.length; t < r; t++)
    e += arguments[t].length;
  for (var n = Array(e), s = 0, t = 0; t < r; t++)
    for (var o = arguments[t], i = 0, a = o.length; i < a; i++, s++)
      n[s] = o[i];
  return n;
}
function yS(e, t, r) {
  if (r || arguments.length === 2)
    for (var n = 0, s = t.length, o; n < s; n++)
      (o || !(n in t)) &&
        (o || (o = Array.prototype.slice.call(t, 0, n)), (o[n] = t[n]));
  return e.concat(o || Array.prototype.slice.call(t));
}
function xn(e) {
  return this instanceof xn ? ((this.v = e), this) : new xn(e);
}
function ES(e, t, r) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var n = r.apply(e, t || []),
    s,
    o = [];
  return (
    (s = Object.create(
      (typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype,
    )),
    a("next"),
    a("throw"),
    a("return", i),
    (s[Symbol.asyncIterator] = function () {
      return this;
    }),
    s
  );
  function i(h) {
    return function (E) {
      return Promise.resolve(E).then(h, m);
    };
  }
  function a(h, E) {
    n[h] &&
      ((s[h] = function (C) {
        return new Promise(function (I, R) {
          o.push([h, C, I, R]) > 1 || d(h, C);
        });
      }),
      E && (s[h] = E(s[h])));
  }
  function d(h, E) {
    try {
      l(n[h](E));
    } catch (C) {
      g(o[0][3], C);
    }
  }
  function l(h) {
    h.value instanceof xn
      ? Promise.resolve(h.value.v).then(p, m)
      : g(o[0][2], h);
  }
  function p(h) {
    d("next", h);
  }
  function m(h) {
    d("throw", h);
  }
  function g(h, E) {
    (h(E), o.shift(), o.length && d(o[0][0], o[0][1]));
  }
}
function _S(e) {
  var t, r;
  return (
    (t = {}),
    n("next"),
    n("throw", function (s) {
      throw s;
    }),
    n("return"),
    (t[Symbol.iterator] = function () {
      return this;
    }),
    t
  );
  function n(s, o) {
    t[s] = e[s]
      ? function (i) {
          return (r = !r) ? { value: xn(e[s](i)), done: !1 } : o ? o(i) : i;
        }
      : o;
  }
}
function wS(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator],
    r;
  return t
    ? t.call(e)
    : ((e = typeof Ci == "function" ? Ci(e) : e[Symbol.iterator]()),
      (r = {}),
      n("next"),
      n("throw"),
      n("return"),
      (r[Symbol.asyncIterator] = function () {
        return this;
      }),
      r);
  function n(o) {
    r[o] =
      e[o] &&
      function (i) {
        return new Promise(function (a, d) {
          ((i = e[o](i)), s(a, d, i.done, i.value));
        });
      };
  }
  function s(o, i, a, d) {
    Promise.resolve(d).then(function (l) {
      o({ value: l, done: a });
    }, i);
  }
}
function bS(e, t) {
  return (
    Object.defineProperty
      ? Object.defineProperty(e, "raw", { value: t })
      : (e.raw = t),
    e
  );
}
function xS(e) {
  if (e && e.__esModule) return e;
  var t = {};
  if (e != null)
    for (var r = gu(e), n = 0; n < r.length; n++)
      r[n] !== "default" && Ii(t, e, r[n]);
  return (zP(t, e), t);
}
function vS(e) {
  return e && e.__esModule ? e : { default: e };
}
function TS(e, t, r, n) {
  if (r === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError(
      "Cannot read private member from an object whose class did not declare it",
    );
  return r === "m" ? n : r === "a" ? n.call(e) : n ? n.value : t.get(e);
}
function CS(e, t, r, n, s) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError(
      "Cannot write private member to an object whose class did not declare it",
    );
  return (n === "a" ? s.call(e, r) : s ? (s.value = r) : t.set(e, r), r);
}
function IS(e, t) {
  if (t === null || (typeof t != "object" && typeof t != "function"))
    throw new TypeError("Cannot use 'in' operator on non-object");
  return typeof e == "function" ? t === e : e.has(t);
}
function AS(e, t, r) {
  if (t != null) {
    if (typeof t != "object" && typeof t != "function")
      throw new TypeError("Object expected.");
    var n, s;
    if (r) {
      if (!Symbol.asyncDispose)
        throw new TypeError("Symbol.asyncDispose is not defined.");
      n = t[Symbol.asyncDispose];
    }
    if (n === void 0) {
      if (!Symbol.dispose)
        throw new TypeError("Symbol.dispose is not defined.");
      ((n = t[Symbol.dispose]), r && (s = n));
    }
    if (typeof n != "function") throw new TypeError("Object not disposable.");
    (s &&
      (n = function () {
        try {
          s.call(this);
        } catch (o) {
          return Promise.reject(o);
        }
      }),
      e.stack.push({ value: t, dispose: n, async: r }));
  } else r && e.stack.push({ async: !0 });
  return t;
}
function RS(e) {
  function t(o) {
    ((e.error = e.hasError
      ? new jP(o, e.error, "An error was suppressed during disposal.")
      : o),
      (e.hasError = !0));
  }
  var r,
    n = 0;
  function s() {
    for (; (r = e.stack.pop()); )
      try {
        if (!r.async && n === 1)
          return ((n = 0), e.stack.push(r), Promise.resolve().then(s));
        if (r.dispose) {
          var o = r.dispose.call(r.value);
          if (r.async)
            return (
              (n |= 2),
              Promise.resolve(o).then(s, function (i) {
                return (t(i), s());
              })
            );
        } else n |= 1;
      } catch (i) {
        t(i);
      }
    if (n === 1)
      return e.hasError ? Promise.reject(e.error) : Promise.resolve();
    if (e.hasError) throw e.error;
  }
  return s();
}
function NS(e, t) {
  return typeof e == "string" && /^\.\.?\//.test(e)
    ? e.replace(
        /\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i,
        function (r, n, s, o, i) {
          return n
            ? t
              ? ".jsx"
              : ".js"
            : s && (!o || !i)
              ? r
              : s + o + "." + i.toLowerCase() + "js";
        },
      )
    : e;
}
var hu,
  Ti,
  Ii,
  zP,
  gu,
  jP,
  BP,
  vs = b(() => {
    hu = function (e, t) {
      return (
        (hu =
          Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array &&
            function (r, n) {
              r.__proto__ = n;
            }) ||
          function (r, n) {
            for (var s in n)
              Object.prototype.hasOwnProperty.call(n, s) && (r[s] = n[s]);
          }),
        hu(e, t)
      );
    };
    Ti = function () {
      return (
        (Ti =
          Object.assign ||
          function (t) {
            for (var r, n = 1, s = arguments.length; n < s; n++) {
              r = arguments[n];
              for (var o in r)
                Object.prototype.hasOwnProperty.call(r, o) && (t[o] = r[o]);
            }
            return t;
          }),
        Ti.apply(this, arguments)
      );
    };
    Ii = Object.create
      ? function (e, t, r, n) {
          n === void 0 && (n = r);
          var s = Object.getOwnPropertyDescriptor(t, r);
          ((!s ||
            ("get" in s ? !t.__esModule : s.writable || s.configurable)) &&
            (s = {
              enumerable: !0,
              get: function () {
                return t[r];
              },
            }),
            Object.defineProperty(e, n, s));
        }
      : function (e, t, r, n) {
          (n === void 0 && (n = r), (e[n] = t[r]));
        };
    ((zP = Object.create
      ? function (e, t) {
          Object.defineProperty(e, "default", { enumerable: !0, value: t });
        }
      : function (e, t) {
          e.default = t;
        }),
      (gu = function (e) {
        return (
          (gu =
            Object.getOwnPropertyNames ||
            function (t) {
              var r = [];
              for (var n in t)
                Object.prototype.hasOwnProperty.call(t, n) && (r[r.length] = n);
              return r;
            }),
          gu(e)
        );
      }));
    jP =
      typeof SuppressedError == "function"
        ? SuppressedError
        : function (e, t, r) {
            var n = new Error(r);
            return (
              (n.name = "SuppressedError"),
              (n.error = e),
              (n.suppressed = t),
              n
            );
          };
    BP = {
      __extends: sS,
      __assign: Ti,
      __rest: oS,
      __decorate: iS,
      __param: aS,
      __esDecorate: cS,
      __runInitializers: dS,
      __propKey: lS,
      __setFunctionName: uS,
      __metadata: fS,
      __awaiter: pS,
      __generator: mS,
      __createBinding: Ii,
      __exportStar: hS,
      __values: Ci,
      __read: Su,
      __spread: gS,
      __spreadArrays: SS,
      __spreadArray: yS,
      __await: xn,
      __asyncGenerator: ES,
      __asyncDelegator: _S,
      __asyncValues: wS,
      __makeTemplateObject: bS,
      __importStar: xS,
      __importDefault: vS,
      __classPrivateFieldGet: TS,
      __classPrivateFieldSet: CS,
      __classPrivateFieldIn: IS,
      __addDisposableResource: AS,
      __disposeResources: RS,
      __rewriteRelativeImportExtension: NS,
    };
  });
var OS = P((Ai) => {
  "use strict";
  Object.defineProperty(Ai, "__esModule", { value: !0 });
  Ai.randomUUID = void 0;
  var qP = (vs(), ce(xs)),
    PS = qP.__importDefault(require("crypto"));
  Ai.randomUUID = PS.default.randomUUID.bind(PS.default);
});
var Ri = P((MS) => {
  "use strict";
  var DS = OS(),
    $e = Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0")),
    VP = () => {
      if (DS.randomUUID) return DS.randomUUID();
      let e = new Uint8Array(16);
      return (
        crypto.getRandomValues(e),
        (e[6] = (e[6] & 15) | 64),
        (e[8] = (e[8] & 63) | 128),
        $e[e[0]] +
          $e[e[1]] +
          $e[e[2]] +
          $e[e[3]] +
          "-" +
          $e[e[4]] +
          $e[e[5]] +
          "-" +
          $e[e[6]] +
          $e[e[7]] +
          "-" +
          $e[e[8]] +
          $e[e[9]] +
          "-" +
          $e[e[10]] +
          $e[e[11]] +
          $e[e[12]] +
          $e[e[13]] +
          $e[e[14]] +
          $e[e[15]]
      );
    };
  MS.v4 = VP;
});
var xt,
  kS = b(() => {
    xt = v(Ri());
  });
var Be,
  FS = b(() => {
    Be = function (t) {
      return Object.assign(new String(t), {
        deserializeJSON() {
          return JSON.parse(String(t));
        },
        toString() {
          return String(t);
        },
        toJSON() {
          return String(t);
        },
      });
    };
    Be.from = (e) =>
      e && typeof e == "object" && (e instanceof Be || "deserializeJSON" in e)
        ? e
        : typeof e == "string" || Object.getPrototypeOf(e) === String.prototype
          ? Be(String(e))
          : Be(JSON.stringify(e));
    Be.fromObject = Be.from;
  });
function yu(e) {
  return (
    (e.includes(",") || e.includes('"')) && (e = `"${e.replace(/"/g, '\\"')}"`),
    e
  );
}
var LS = b(() => {});
function Ft(e, t, r) {
  let n = Number(e);
  if (n < t || n > r) throw new Error(`Value ${n} out of range [${t}, ${r}]`);
}
var Eu,
  _u,
  wu,
  $S,
  US,
  GP,
  WP,
  KP,
  JP,
  YP,
  Ts,
  bu,
  xu,
  HS = b(() => {
    ((Eu = "(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)(?:[ne|u?r]?s?day)?"),
      (_u = "(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"),
      (wu = "(\\d?\\d):(\\d{2}):(\\d{2})(?:\\.(\\d+))?"),
      ($S = "(\\d?\\d)"),
      (US = "(\\d{4})"),
      (GP = new RegExp(
        /^(\d{4})-(\d\d)-(\d\d)[tT](\d\d):(\d\d):(\d\d)(\.(\d+))?(([-+]\d\d:\d\d)|[zZ])$/,
      )),
      (WP = new RegExp(`^${Eu}, ${$S} ${_u} ${US} ${wu} GMT$`)),
      (KP = new RegExp(`^${Eu}, ${$S}-${_u}-(\\d\\d) ${wu} GMT$`)),
      (JP = new RegExp(`^${Eu} ${_u} ( [1-9]|\\d\\d) ${wu} ${US}$`)),
      (YP = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ]),
      (Ts = (e) => {
        if (e == null) return;
        let t = NaN;
        if (typeof e == "number") t = e;
        else if (typeof e == "string") {
          if (!/^-?\d*\.?\d+$/.test(e))
            throw new TypeError(
              "parseEpochTimestamp - numeric string invalid.",
            );
          t = Number.parseFloat(e);
        } else typeof e == "object" && e.tag === 1 && (t = e.value);
        if (isNaN(t) || Math.abs(t) === 1 / 0)
          throw new TypeError("Epoch timestamps must be valid finite numbers.");
        return new Date(Math.round(t * 1e3));
      }),
      (bu = (e) => {
        if (e == null) return;
        if (typeof e != "string")
          throw new TypeError("RFC3339 timestamps must be strings");
        let t = GP.exec(e);
        if (!t) throw new TypeError(`Invalid RFC3339 timestamp format ${e}`);
        let [, r, n, s, o, i, a, , d, l] = t;
        (Ft(n, 1, 12), Ft(s, 1, 31), Ft(o, 0, 23), Ft(i, 0, 59), Ft(a, 0, 60));
        let p = new Date();
        if (
          (p.setUTCFullYear(Number(r), Number(n) - 1, Number(s)),
          p.setUTCHours(Number(o)),
          p.setUTCMinutes(Number(i)),
          p.setUTCSeconds(Number(a)),
          p.setUTCMilliseconds(
            Number(d) ? Math.round(parseFloat(`0.${d}`) * 1e3) : 0,
          ),
          l.toUpperCase() != "Z")
        ) {
          let [, m, g, h] = /([+-])(\d\d):(\d\d)/.exec(l) || [
              void 0,
              "+",
              0,
              0,
            ],
            E = m === "-" ? 1 : -1;
          p.setTime(
            p.getTime() +
              E * (Number(g) * 60 * 60 * 1e3 + Number(h) * 60 * 1e3),
          );
        }
        return p;
      }),
      (xu = (e) => {
        if (e == null) return;
        if (typeof e != "string")
          throw new TypeError("RFC7231 timestamps must be strings.");
        let t, r, n, s, o, i, a, d;
        if (
          ((d = WP.exec(e))
            ? ([, t, r, n, s, o, i, a] = d)
            : (d = KP.exec(e))
              ? (([, t, r, n, s, o, i, a] = d),
                (n = (Number(n) + 1900).toString()))
              : (d = JP.exec(e)) && ([, r, t, s, o, i, a, n] = d),
          n && i)
        ) {
          let l = new Date();
          return (
            l.setUTCFullYear(Number(n)),
            l.setUTCMonth(YP.indexOf(r)),
            Ft(t, 1, 31),
            l.setUTCDate(Number(t)),
            Ft(s, 0, 23),
            l.setUTCHours(Number(s)),
            Ft(o, 0, 59),
            l.setUTCMinutes(Number(o)),
            Ft(i, 0, 60),
            l.setUTCSeconds(Number(i)),
            l.setUTCMilliseconds(
              a ? Math.round(parseFloat(`0.${a}`) * 1e3) : 0,
            ),
            l
          );
        }
        throw new TypeError(`Invalid RFC7231 date-time value ${e}.`);
      }));
  });
function vu(e, t, r) {
  if (r <= 0 || !Number.isInteger(r))
    throw new Error("Invalid number of delimiters (" + r + ") for splitEvery.");
  let n = e.split(t);
  if (r === 1) return n;
  let s = [],
    o = "";
  for (let i = 0; i < n.length; i++)
    (o === "" ? (o = n[i]) : (o += t + n[i]),
      (i + 1) % r === 0 && (s.push(o), (o = "")));
  return (o !== "" && s.push(o), s);
}
var zS = b(() => {});
var Cs,
  jS = b(() => {
    Cs = (e) => {
      let t = e.length,
        r = [],
        n = !1,
        s,
        o = 0;
      for (let i = 0; i < t; ++i) {
        let a = e[i];
        switch (a) {
          case '"':
            s !== "\\" && (n = !n);
            break;
          case ",":
            n || (r.push(e.slice(o, i)), (o = i + 1));
            break;
          default:
        }
        s = a;
      }
      return (
        r.push(e.slice(o)),
        r.map((i) => {
          i = i.trim();
          let a = i.length;
          return a < 2
            ? i
            : (i[0] === '"' && i[a - 1] === '"' && (i = i.slice(1, a - 1)),
              i.replace(/\\"/g, '"'));
        })
      );
    };
  });
function Tu(e) {
  return new Ee(String(e), "bigDecimal");
}
var BS,
  Ee,
  qS = b(() => {
    ((BS = /^-?\d*(\.\d+)?$/),
      (Ee = class e {
        string;
        type;
        constructor(t, r) {
          if (((this.string = t), (this.type = r), !BS.test(t)))
            throw new Error(
              '@smithy/core/serde - NumericValue must only contain [0-9], at most one decimal point ".", and an optional negation prefix "-".',
            );
        }
        toString() {
          return this.string;
        }
        static [Symbol.hasInstance](t) {
          if (!t || typeof t != "object") return !1;
          let r = t;
          return (
            e.prototype.isPrototypeOf(t) ||
            (r.type === "bigDecimal" && BS.test(r.string))
          );
        }
      }));
  });
var VS = {};
st(VS, {
  LazyJsonString: () => Be,
  NumericValue: () => Ee,
  _parseEpochTimestamp: () => Ts,
  _parseRfc3339DateTimeWithOffset: () => bu,
  _parseRfc7231DateTime: () => xu,
  copyDocumentWithTransform: () => lP,
  dateToUtcString: () => bs,
  expectBoolean: () => fP,
  expectByte: () => su,
  expectFloat32: () => bi,
  expectInt: () => mP,
  expectInt32: () => ru,
  expectLong: () => Es,
  expectNonNull: () => gP,
  expectNumber: () => ys,
  expectObject: () => eS,
  expectShort: () => nu,
  expectString: () => SP,
  expectUnion: () => yP,
  generateIdempotencyToken: () => xt.v4,
  handleFloat: () => wP,
  limitedParseDouble: () => au,
  limitedParseFloat: () => bP,
  limitedParseFloat32: () => xP,
  logger: () => _s,
  nv: () => Tu,
  parseBoolean: () => uP,
  parseEpochTimestamp: () => mu,
  parseRfc3339DateTime: () => AP,
  parseRfc3339DateTimeWithOffset: () => fu,
  parseRfc7231DateTime: () => pu,
  quoteHeader: () => yu,
  splitEvery: () => vu,
  splitHeader: () => Cs,
  strictParseByte: () => cu,
  strictParseDouble: () => vi,
  strictParseFloat: () => EP,
  strictParseFloat32: () => iu,
  strictParseInt: () => vP,
  strictParseInt32: () => TP,
  strictParseLong: () => rS,
  strictParseShort: () => jr,
});
var Ke = b(() => {
  Zg();
  nS();
  kS();
  FS();
  du();
  LS();
  HS();
  zS();
  jS();
  qS();
});
var GS,
  Cu,
  WS = b(() => {
    ((GS = v(Oe())),
      (Cu = class {
        marshaller;
        serializer;
        deserializer;
        serdeContext;
        defaultContentType;
        constructor({
          marshaller: t,
          serializer: r,
          deserializer: n,
          serdeContext: s,
          defaultContentType: o,
        }) {
          ((this.marshaller = t),
            (this.serializer = r),
            (this.deserializer = n),
            (this.serdeContext = s),
            (this.defaultContentType = o));
        }
        async serializeEventStream({
          eventStream: t,
          requestSchema: r,
          initialRequest: n,
        }) {
          let s = this.marshaller,
            o = r.getEventStreamMember(),
            i = r.getMemberSchema(o),
            a = i.getMemberSchemas(),
            d = this.serializer,
            l = this.defaultContentType,
            p = Symbol("initialRequestMarker"),
            m = {
              async *[Symbol.asyncIterator]() {
                if (n) {
                  let g = {
                    ":event-type": { type: "string", value: "initial-request" },
                    ":message-type": { type: "string", value: "event" },
                    ":content-type": { type: "string", value: l },
                  };
                  d.write(r, n);
                  let h = d.flush();
                  yield { [p]: !0, headers: g, body: h };
                }
                for await (let g of t) yield g;
              },
            };
          return s.serialize(m, (g) => {
            if (g[p]) return { headers: g.headers, body: g.body };
            let h = Object.keys(g).find(($) => $ !== "__type") ?? "",
              {
                additionalHeaders: E,
                body: C,
                eventType: I,
                explicitPayloadContentType: R,
              } = this.writeEventBody(h, i, g);
            return {
              headers: {
                ":event-type": { type: "string", value: I },
                ":message-type": { type: "string", value: "event" },
                ":content-type": { type: "string", value: R ?? l },
                ...E,
              },
              body: C,
            };
          });
        }
        async deserializeEventStream({
          response: t,
          responseSchema: r,
          initialResponseContainer: n,
        }) {
          let s = this.marshaller,
            o = r.getEventStreamMember(),
            a = r.getMemberSchema(o).getMemberSchemas(),
            d = Symbol("initialResponseMarker"),
            l = s.deserialize(t.body, async (g) => {
              let h = Object.keys(g).find((E) => E !== "__type") ?? "";
              if (h === "initial-response") {
                let E = await this.deserializer.read(r, g[h].body);
                return (delete E[o], { [d]: !0, ...E });
              } else if (h in a) {
                let E = a[h];
                return { [h]: await this.deserializer.read(E, g[h].body) };
              } else return { $unknown: g };
            }),
            p = l[Symbol.asyncIterator](),
            m = await p.next();
          if (m.done) return l;
          if (m.value?.[d]) {
            if (!r)
              throw new Error(
                "@smithy::core/protocols - initial-response event encountered in event stream but no response schema given.",
              );
            for (let [g, h] of Object.entries(m.value)) n[g] = h;
          }
          return {
            async *[Symbol.asyncIterator]() {
              for (m?.value?.[d] || (yield m.value); ; ) {
                let { done: g, value: h } = await p.next();
                if (g) break;
                yield h;
              }
            },
          };
        }
        writeEventBody(t, r, n) {
          let s = this.serializer,
            o = t,
            i = null,
            a,
            d = r.getSchema().memberNames.includes(t),
            l = {};
          if (d) {
            let g = r.getMemberSchema(t);
            if (g.isStructSchema()) {
              for (let [h, E] of g.structIterator()) {
                let { eventHeader: C, eventPayload: I } = E.getMergedTraits();
                if (I) {
                  i = h;
                  break;
                } else if (C) {
                  let R = n[t][h],
                    O = "binary";
                  (E.isNumericSchema()
                    ? (-2) ** 31 <= R && R <= 2 ** 31 - 1
                      ? (O = "integer")
                      : (O = "long")
                    : E.isTimestampSchema()
                      ? (O = "timestamp")
                      : E.isStringSchema()
                        ? (O = "string")
                        : E.isBooleanSchema() && (O = "boolean"),
                    R != null &&
                      ((l[h] = { type: O, value: R }), delete n[t][h]));
                }
              }
              if (i !== null) {
                let h = g.getMemberSchema(i);
                (h.isBlobSchema()
                  ? (a = "application/octet-stream")
                  : h.isStringSchema() && (a = "text/plain"),
                  s.write(h, n[t][i]));
              } else s.write(g, n[t]);
            } else
              throw new Error(
                "@smithy/core/event-streams - non-struct member not supported in event stream union.",
              );
          } else {
            let [g, h] = n[t];
            ((o = g), s.write(15, h));
          }
          let p = s.flush();
          return {
            body:
              typeof p == "string"
                ? (this.serdeContext?.utf8Decoder ?? GS.fromUtf8)(p)
                : p,
            eventType: o,
            explicitPayloadContentType: a,
            additionalHeaders: l,
          };
        }
      }));
  });
var KS = {};
st(KS, { EventStreamSerde: () => Cu });
var JS = b(() => {
  WS();
});
var Ni,
  Br,
  Pi = b(() => {
    we();
    ((Ni = v(me())),
      (Br = class {
        options;
        serdeContext;
        constructor(t) {
          this.options = t;
        }
        getRequestType() {
          return Ni.HttpRequest;
        }
        getResponseType() {
          return Ni.HttpResponse;
        }
        setSerdeContext(t) {
          ((this.serdeContext = t),
            this.serializer.setSerdeContext(t),
            this.deserializer.setSerdeContext(t),
            this.getPayloadCodec() &&
              this.getPayloadCodec().setSerdeContext(t));
        }
        updateServiceEndpoint(t, r) {
          if ("url" in r) {
            ((t.protocol = r.url.protocol),
              (t.hostname = r.url.hostname),
              (t.port = r.url.port ? Number(r.url.port) : void 0),
              (t.path = r.url.pathname),
              (t.fragment = r.url.hash || void 0),
              (t.username = r.url.username || void 0),
              (t.password = r.url.password || void 0),
              t.query || (t.query = {}));
            for (let [n, s] of r.url.searchParams.entries()) t.query[n] = s;
            return t;
          } else
            return (
              (t.protocol = r.protocol),
              (t.hostname = r.hostname),
              (t.port = r.port ? Number(r.port) : void 0),
              (t.path = r.path),
              (t.query = { ...r.query }),
              t
            );
        }
        setHostPrefix(t, r, n) {
          let s = L.of(r),
            o = L.of(r.input);
          if (s.getMergedTraits().endpoint) {
            let i = s.getMergedTraits().endpoint?.[0];
            if (typeof i == "string") {
              let a = [...o.structIterator()].filter(
                ([, d]) => d.getMergedTraits().hostLabel,
              );
              for (let [d] of a) {
                let l = n[d];
                if (typeof l != "string")
                  throw new Error(
                    `@smithy/core/schema - ${d} in input must be a string as hostLabel.`,
                  );
                i = i.replace(`{${d}}`, l);
              }
              t.hostname = i + t.hostname;
            }
          }
        }
        deserializeMetadata(t) {
          return {
            httpStatusCode: t.statusCode,
            requestId:
              t.headers["x-amzn-requestid"] ??
              t.headers["x-amzn-request-id"] ??
              t.headers["x-amz-request-id"],
            extendedRequestId: t.headers["x-amz-id-2"],
            cfId: t.headers["x-amz-cf-id"],
          };
        }
        async serializeEventStream({
          eventStream: t,
          requestSchema: r,
          initialRequest: n,
        }) {
          return (await this.loadEventStreamCapability()).serializeEventStream({
            eventStream: t,
            requestSchema: r,
            initialRequest: n,
          });
        }
        async deserializeEventStream({
          response: t,
          responseSchema: r,
          initialResponseContainer: n,
        }) {
          return (
            await this.loadEventStreamCapability()
          ).deserializeEventStream({
            response: t,
            responseSchema: r,
            initialResponseContainer: n,
          });
        }
        async loadEventStreamCapability() {
          let { EventStreamSerde: t } = await Promise.resolve().then(
            () => (JS(), KS),
          );
          return new t({
            marshaller: this.getEventStreamMarshaller(),
            serializer: this.serializer,
            deserializer: this.deserializer,
            serdeContext: this.serdeContext,
            defaultContentType: this.getDefaultContentType(),
          });
        }
        getDefaultContentType() {
          throw new Error(
            `@smithy/core/protocols - ${this.constructor.name} getDefaultContentType() implementation missing.`,
          );
        }
        async deserializeHttpMessage(t, r, n, s, o) {
          return [];
        }
        getEventStreamMarshaller() {
          let t = this.serdeContext;
          if (!t.eventStreamMarshaller)
            throw new Error(
              "@smithy/core - HttpProtocol: eventStreamMarshaller missing in serdeContext.",
            );
          return t.eventStreamMarshaller;
        }
      }));
  });
var YS,
  XS,
  qr,
  QS = b(() => {
    we();
    Ke();
    ((YS = v(me())), (XS = v(mi())));
    gi();
    Si();
    Pi();
    qr = class extends Br {
      async serializeRequest(t, r, n) {
        let s = { ...(r ?? {}) },
          o = this.serializer,
          i = {},
          a = {},
          d = await n.endpoint(),
          l = L.of(t?.input),
          p = l.getSchema(),
          m = !1,
          g,
          h = new YS.HttpRequest({
            protocol: "",
            hostname: "",
            port: void 0,
            path: "",
            fragment: void 0,
            query: i,
            headers: a,
            body: void 0,
          });
        if (d) {
          (this.updateServiceEndpoint(h, d), this.setHostPrefix(h, t, s));
          let E = cr(t.traits);
          if (E.http) {
            h.method = E.http[0];
            let [C, I] = E.http[1].split("?");
            h.path == "/" ? (h.path = C) : (h.path += C);
            let R = new URLSearchParams(I ?? "");
            Object.assign(i, Object.fromEntries(R));
          }
        }
        for (let [E, C] of l.structIterator()) {
          let I = C.getMergedTraits() ?? {},
            R = s[E];
          if (R != null)
            if (I.httpPayload)
              (C.isStreaming()
                ? C.isStructSchema()
                  ? s[E] &&
                    (g = await this.serializeEventStream({
                      eventStream: s[E],
                      requestSchema: l,
                    }))
                  : (g = R)
                : (o.write(C, R), (g = o.flush())),
                delete s[E]);
            else if (I.httpLabel) {
              o.write(C, R);
              let O = o.flush();
              (h.path.includes(`{${E}+}`)
                ? (h.path = h.path.replace(
                    `{${E}+}`,
                    O.split("/").map(wt).join("/"),
                  ))
                : h.path.includes(`{${E}}`) &&
                  (h.path = h.path.replace(`{${E}}`, wt(O))),
                delete s[E]);
            } else if (I.httpHeader)
              (o.write(C, R),
                (a[I.httpHeader.toLowerCase()] = String(o.flush())),
                delete s[E]);
            else if (typeof I.httpPrefixHeaders == "string") {
              for (let [O, $] of Object.entries(R)) {
                let j = I.httpPrefixHeaders + O;
                (o.write([C.getValueSchema(), { httpHeader: j }], $),
                  (a[j.toLowerCase()] = o.flush()));
              }
              delete s[E];
            } else
              I.httpQuery || I.httpQueryParams
                ? (this.serializeQuery(C, R, i), delete s[E])
                : (m = !0);
        }
        return (
          m && s && (o.write(p, s), (g = o.flush())),
          (h.headers = a),
          (h.query = i),
          (h.body = g),
          h
        );
      }
      serializeQuery(t, r, n) {
        let s = this.serializer,
          o = t.getMergedTraits();
        if (o.httpQueryParams) {
          for (let [i, a] of Object.entries(r))
            if (!(i in n)) {
              let d = t.getValueSchema();
              (Object.assign(d.getMergedTraits(), {
                ...o,
                httpQuery: i,
                httpQueryParams: void 0,
              }),
                this.serializeQuery(d, a, n));
            }
          return;
        }
        if (t.isListSchema()) {
          let i = !!t.getMergedTraits().sparse,
            a = [];
          for (let d of r) {
            s.write([t.getValueSchema(), o], d);
            let l = s.flush();
            (i || l !== void 0) && a.push(l);
          }
          n[o.httpQuery] = a;
        } else (s.write([t, o], r), (n[o.httpQuery] = s.flush()));
      }
      async deserializeResponse(t, r, n) {
        let s = this.deserializer,
          o = L.of(t.output),
          i = {};
        if (n.statusCode >= 300) {
          let d = await ht(n.body, r);
          throw (
            d.byteLength > 0 && Object.assign(i, await s.read(15, d)),
            await this.handleError(t, r, n, i, this.deserializeMetadata(n)),
            new Error(
              "@smithy/core/protocols - HTTP Protocol error handler failed to throw.",
            )
          );
        }
        for (let d in n.headers) {
          let l = n.headers[d];
          (delete n.headers[d], (n.headers[d.toLowerCase()] = l));
        }
        let a = await this.deserializeHttpMessage(o, r, n, i);
        if (a.length) {
          let d = await ht(n.body, r);
          if (d.byteLength > 0) {
            let l = await s.read(o, d);
            for (let p of a) i[p] = l[p];
          }
        }
        return ((i.$metadata = this.deserializeMetadata(n)), i);
      }
      async deserializeHttpMessage(t, r, n, s, o) {
        let i;
        s instanceof Set ? (i = o) : (i = s);
        let a = this.deserializer,
          d = L.of(t),
          l = [];
        for (let [p, m] of d.structIterator()) {
          let g = m.getMemberTraits();
          if (g.httpPayload) {
            if (m.isStreaming())
              m.isStructSchema()
                ? (i[p] = await this.deserializeEventStream({
                    response: n,
                    responseSchema: d,
                  }))
                : (i[p] = (0, XS.sdkStreamMixin)(n.body));
            else if (n.body) {
              let E = await ht(n.body, r);
              E.byteLength > 0 && (i[p] = await a.read(m, E));
            }
          } else if (g.httpHeader) {
            let h = String(g.httpHeader).toLowerCase(),
              E = n.headers[h];
            if (E != null)
              if (m.isListSchema()) {
                let C = m.getValueSchema();
                C.getMergedTraits().httpHeader = h;
                let I;
                C.isTimestampSchema() && C.getSchema() === 4
                  ? (I = vu(E, ",", 2))
                  : (I = Cs(E));
                let R = [];
                for (let O of I) R.push(await a.read(C, O.trim()));
                i[p] = R;
              } else i[p] = await a.read(m, E);
          } else if (g.httpPrefixHeaders !== void 0) {
            i[p] = {};
            for (let [h, E] of Object.entries(n.headers))
              if (h.startsWith(g.httpPrefixHeaders)) {
                let C = m.getValueSchema();
                ((C.getMergedTraits().httpHeader = h),
                  (i[p][h.slice(g.httpPrefixHeaders.length)] = await a.read(
                    C,
                    E,
                  )));
              }
          } else g.httpResponseCode ? (i[p] = n.statusCode) : l.push(p);
        }
        return l;
      }
    };
  });
var ZS,
  Lt,
  ey = b(() => {
    we();
    ZS = v(me());
    gi();
    Pi();
    Lt = class extends Br {
      async serializeRequest(t, r, n) {
        let s = this.serializer,
          o = {},
          i = {},
          a = await n.endpoint(),
          d = L.of(t?.input),
          l = d.getSchema(),
          p,
          m = new ZS.HttpRequest({
            protocol: "",
            hostname: "",
            port: void 0,
            path: "/",
            fragment: void 0,
            query: o,
            headers: i,
            body: void 0,
          });
        a && (this.updateServiceEndpoint(m, a), this.setHostPrefix(m, t, r));
        let g = { ...r };
        if (r) {
          let h = d.getEventStreamMember();
          if (h) {
            if (g[h]) {
              let E = {};
              for (let [C, I] of d.structIterator())
                C !== h && g[C] && (s.write(I, g[C]), (E[C] = s.flush()));
              p = await this.serializeEventStream({
                eventStream: g[h],
                requestSchema: d,
                initialRequest: E,
              });
            }
          } else (s.write(l, g), (p = s.flush()));
        }
        return (
          (m.headers = i),
          (m.query = o),
          (m.body = p),
          (m.method = "POST"),
          m
        );
      }
      async deserializeResponse(t, r, n) {
        let s = this.deserializer,
          o = L.of(t.output),
          i = {};
        if (n.statusCode >= 300) {
          let d = await ht(n.body, r);
          throw (
            d.byteLength > 0 && Object.assign(i, await s.read(15, d)),
            await this.handleError(t, r, n, i, this.deserializeMetadata(n)),
            new Error(
              "@smithy/core/protocols - RPC Protocol error handler failed to throw.",
            )
          );
        }
        for (let d in n.headers) {
          let l = n.headers[d];
          (delete n.headers[d], (n.headers[d.toLowerCase()] = l));
        }
        let a = o.getEventStreamMember();
        if (a)
          i[a] = await this.deserializeEventStream({
            response: n,
            responseSchema: o,
            initialResponseContainer: i,
          });
        else {
          let d = await ht(n.body, r);
          d.byteLength > 0 && Object.assign(i, await s.read(o, d));
        }
        return ((i.$metadata = this.deserializeMetadata(n)), i);
      }
    };
  });
var Iu,
  Au = b(() => {
    Si();
    Iu = (e, t, r, n, s, o) => {
      if (t != null && t[r] !== void 0) {
        let i = n();
        if (i.length <= 0)
          throw new Error(
            "Empty value provided for input HTTP label: " + r + ".",
          );
        e = e.replace(
          s,
          o
            ? i
                .split("/")
                .map((a) => wt(a))
                .join("/")
            : wt(i),
        );
      } else
        throw new Error("No value provided for input HTTP label: " + r + ".");
      return e;
    };
  });
function Is(e, t) {
  return new Oi(e, t);
}
var ty,
  Oi,
  ry = b(() => {
    ty = v(me());
    Au();
    Oi = class {
      input;
      context;
      query = {};
      method = "";
      headers = {};
      path = "";
      body = null;
      hostname = "";
      resolvePathStack = [];
      constructor(t, r) {
        ((this.input = t), (this.context = r));
      }
      async build() {
        let {
          hostname: t,
          protocol: r = "https",
          port: n,
          path: s,
        } = await this.context.endpoint();
        this.path = s;
        for (let o of this.resolvePathStack) o(this.path);
        return new ty.HttpRequest({
          protocol: r,
          hostname: this.hostname || t,
          port: n,
          method: this.method,
          path: this.path,
          query: this.query,
          body: this.body,
          headers: this.headers,
        });
      }
      hn(t) {
        return ((this.hostname = t), this);
      }
      bp(t) {
        return (
          this.resolvePathStack.push((r) => {
            this.path = `${r?.endsWith("/") ? r.slice(0, -1) : r || ""}` + t;
          }),
          this
        );
      }
      p(t, r, n, s) {
        return (
          this.resolvePathStack.push((o) => {
            this.path = Iu(o, this.input, t, r, n, s);
          }),
          this
        );
      }
      h(t) {
        return ((this.headers = t), this);
      }
      q(t) {
        return ((this.query = t), this);
      }
      b(t) {
        return ((this.body = t), this);
      }
      m(t) {
        return ((this.method = t), this);
      }
    };
  });
function Ze(e, t) {
  if (
    t.timestampFormat.useTrait &&
    e.isTimestampSchema() &&
    (e.getSchema() === 5 || e.getSchema() === 6 || e.getSchema() === 7)
  )
    return e.getSchema();
  let {
    httpLabel: r,
    httpPrefixHeaders: n,
    httpHeader: s,
    httpQuery: o,
  } = e.getMergedTraits();
  return (
    (t.httpBindings
      ? typeof n == "string" || s
        ? 6
        : o || r
          ? 5
          : void 0
      : void 0) ?? t.timestampFormat.default
  );
}
var Di = b(() => {});
var Ru,
  ny,
  Vr,
  Nu = b(() => {
    we();
    Ke();
    ((Ru = v(De())), (ny = v(Oe())));
    Di();
    Vr = class {
      settings;
      serdeContext;
      constructor(t) {
        this.settings = t;
      }
      setSerdeContext(t) {
        this.serdeContext = t;
      }
      read(t, r) {
        let n = L.of(t);
        if (n.isListSchema())
          return Cs(r).map((s) => this.read(n.getValueSchema(), s));
        if (n.isBlobSchema())
          return (this.serdeContext?.base64Decoder ?? Ru.fromBase64)(r);
        if (n.isTimestampSchema())
          switch (Ze(n, this.settings)) {
            case 5:
              return bu(r);
            case 6:
              return xu(r);
            case 7:
              return Ts(r);
            default:
              return (
                console.warn(
                  "Missing timestamp format, parsing value with Date constructor:",
                  r,
                ),
                new Date(r)
              );
          }
        if (n.isStringSchema()) {
          let s = n.getMergedTraits().mediaType,
            o = r;
          if (s)
            return (
              n.getMergedTraits().httpHeader && (o = this.base64ToUtf8(o)),
              (s === "application/json" || s.endsWith("+json")) &&
                (o = Be.from(o)),
              o
            );
        }
        return n.isNumericSchema()
          ? Number(r)
          : n.isBigIntegerSchema()
            ? BigInt(r)
            : n.isBigDecimalSchema()
              ? new Ee(r, "bigDecimal")
              : n.isBooleanSchema()
                ? String(r).toLowerCase() === "true"
                : r;
      }
      base64ToUtf8(t) {
        return (this.serdeContext?.utf8Encoder ?? ny.toUtf8)(
          (this.serdeContext?.base64Decoder ?? Ru.fromBase64)(t),
        );
      }
    };
  });
var Mi,
  Gr,
  sy = b(() => {
    we();
    Mi = v(Oe());
    Nu();
    Gr = class {
      codecDeserializer;
      stringDeserializer;
      serdeContext;
      constructor(t, r) {
        ((this.codecDeserializer = t), (this.stringDeserializer = new Vr(r)));
      }
      setSerdeContext(t) {
        (this.stringDeserializer.setSerdeContext(t),
          this.codecDeserializer.setSerdeContext(t),
          (this.serdeContext = t));
      }
      read(t, r) {
        let n = L.of(t),
          s = n.getMergedTraits(),
          o = this.serdeContext?.utf8Encoder ?? Mi.toUtf8;
        if (s.httpHeader || s.httpResponseCode)
          return this.stringDeserializer.read(n, o(r));
        if (s.httpPayload) {
          if (n.isBlobSchema()) {
            let i = this.serdeContext?.utf8Decoder ?? Mi.fromUtf8;
            return typeof r == "string" ? i(r) : r;
          } else if (n.isStringSchema()) return "byteLength" in r ? o(r) : r;
        }
        return this.codecDeserializer.read(n, r);
      }
    };
  });
var Pu,
  As,
  Ou = b(() => {
    we();
    Ke();
    Pu = v(De());
    Di();
    As = class {
      settings;
      stringBuffer = "";
      serdeContext = void 0;
      constructor(t) {
        this.settings = t;
      }
      setSerdeContext(t) {
        this.serdeContext = t;
      }
      write(t, r) {
        let n = L.of(t);
        switch (typeof r) {
          case "object":
            if (r === null) {
              this.stringBuffer = "null";
              return;
            }
            if (n.isTimestampSchema()) {
              if (!(r instanceof Date))
                throw new Error(
                  `@smithy/core/protocols - received non-Date value ${r} when schema expected Date in ${n.getName(!0)}`,
                );
              switch (Ze(n, this.settings)) {
                case 5:
                  this.stringBuffer = r.toISOString().replace(".000Z", "Z");
                  break;
                case 6:
                  this.stringBuffer = bs(r);
                  break;
                case 7:
                  this.stringBuffer = String(r.getTime() / 1e3);
                  break;
                default:
                  (console.warn(
                    "Missing timestamp format, using epoch seconds",
                    r,
                  ),
                    (this.stringBuffer = String(r.getTime() / 1e3)));
              }
              return;
            }
            if (n.isBlobSchema() && "byteLength" in r) {
              this.stringBuffer = (
                this.serdeContext?.base64Encoder ?? Pu.toBase64
              )(r);
              return;
            }
            if (n.isListSchema() && Array.isArray(r)) {
              let i = "";
              for (let a of r) {
                this.write([n.getValueSchema(), n.getMergedTraits()], a);
                let d = this.flush(),
                  l = n.getValueSchema().isTimestampSchema() ? d : yu(d);
                (i !== "" && (i += ", "), (i += l));
              }
              this.stringBuffer = i;
              return;
            }
            this.stringBuffer = JSON.stringify(r, null, 2);
            break;
          case "string":
            let s = n.getMergedTraits().mediaType,
              o = r;
            if (
              s &&
              ((s === "application/json" || s.endsWith("+json")) &&
                (o = Be.from(o)),
              n.getMergedTraits().httpHeader)
            ) {
              this.stringBuffer = (
                this.serdeContext?.base64Encoder ?? Pu.toBase64
              )(o.toString());
              return;
            }
            this.stringBuffer = r;
            break;
          default:
            this.stringBuffer = String(r);
        }
      }
      flush() {
        let t = this.stringBuffer;
        return ((this.stringBuffer = ""), t);
      }
    };
  });
var Wr,
  oy = b(() => {
    we();
    Ou();
    Wr = class {
      codecSerializer;
      stringSerializer;
      buffer;
      constructor(t, r, n = new As(r)) {
        ((this.codecSerializer = t), (this.stringSerializer = n));
      }
      setSerdeContext(t) {
        (this.codecSerializer.setSerdeContext(t),
          this.stringSerializer.setSerdeContext(t));
      }
      write(t, r) {
        let n = L.of(t),
          s = n.getMergedTraits();
        if (s.httpHeader || s.httpLabel || s.httpQuery) {
          (this.stringSerializer.write(n, r),
            (this.buffer = this.stringSerializer.flush()));
          return;
        }
        return this.codecSerializer.write(n, r);
      }
      flush() {
        if (this.buffer !== void 0) {
          let t = this.buffer;
          return ((this.buffer = void 0), t);
        }
        return this.codecSerializer.flush();
      }
    };
  });
var iy = {};
st(iy, {
  FromStringShapeDeserializer: () => Vr,
  HttpBindingProtocol: () => qr,
  HttpInterceptingShapeDeserializer: () => Gr,
  HttpInterceptingShapeSerializer: () => Wr,
  HttpProtocol: () => Br,
  RequestBuilder: () => Oi,
  RpcProtocol: () => Lt,
  ToStringShapeSerializer: () => As,
  collectBody: () => ht,
  determineTimestampFormat: () => Ze,
  extendedEncodeURIComponent: () => wt,
  requestBuilder: () => Is,
  resolvedPath: () => Iu,
});
var et = b(() => {
  gi();
  Si();
  QS();
  Pi();
  ey();
  ry();
  Au();
  Nu();
  sy();
  oy();
  Ou();
  Di();
});
var ay = b(() => {
  et();
});
function XP(e, t, r) {
  (e.__smithy_context
    ? e.__smithy_context.features || (e.__smithy_context.features = {})
    : (e.__smithy_context = { features: {} }),
    (e.__smithy_context.features[t] = r));
}
var cy = b(() => {});
var Kr,
  dy = b(() => {
    Kr = class {
      authSchemes = new Map();
      constructor(t) {
        for (let [r, n] of Object.entries(t))
          n !== void 0 && this.authSchemes.set(r, n);
      }
      getIdentityProvider(t) {
        return this.authSchemes.get(t);
      }
    };
  });
var ly,
  Du,
  Mu,
  uy = b(() => {
    ((ly = v(me())),
      (Du = v(rr())),
      (Mu = class {
        async sign(t, r, n) {
          if (!n)
            throw new Error(
              "request could not be signed with `apiKey` since the `name` and `in` signer properties are missing",
            );
          if (!n.name)
            throw new Error(
              "request could not be signed with `apiKey` since the `name` signer property is missing",
            );
          if (!n.in)
            throw new Error(
              "request could not be signed with `apiKey` since the `in` signer property is missing",
            );
          if (!r.apiKey)
            throw new Error(
              "request could not be signed with `apiKey` since the `apiKey` is not defined",
            );
          let s = ly.HttpRequest.clone(t);
          if (n.in === Du.HttpApiKeyAuthLocation.QUERY)
            s.query[n.name] = r.apiKey;
          else if (n.in === Du.HttpApiKeyAuthLocation.HEADER)
            s.headers[n.name] = n.scheme ? `${n.scheme} ${r.apiKey}` : r.apiKey;
          else
            throw new Error(
              "request can only be signed with `apiKey` locations `query` or `header`, but found: `" +
                n.in +
                "`",
            );
          return s;
        }
      }));
  });
var fy,
  ku,
  py = b(() => {
    ((fy = v(me())),
      (ku = class {
        async sign(t, r, n) {
          let s = fy.HttpRequest.clone(t);
          if (!r.token)
            throw new Error(
              "request could not be signed with `token` since the `token` is not defined",
            );
          return ((s.headers.Authorization = `Bearer ${r.token}`), s);
        }
      }));
  });
var $t,
  my = b(() => {
    $t = class {
      async sign(t, r, n) {
        return t;
      }
    };
  });
var hy = b(() => {
  uy();
  py();
  my();
});
var gy,
  QP,
  Fu,
  ki,
  Lu,
  Sy = b(() => {
    ((gy = (e) =>
      function (r) {
        return ki(r) && r.expiration.getTime() - Date.now() < e;
      }),
      (QP = 3e5),
      (Fu = gy(3e5)),
      (ki = (e) => e.expiration !== void 0),
      (Lu = (e, t, r) => {
        if (e === void 0) return;
        let n = typeof e != "function" ? async () => Promise.resolve(e) : e,
          s,
          o,
          i,
          a = !1,
          d = async (l) => {
            o || (o = n(l));
            try {
              ((s = await o), (i = !0), (a = !1));
            } finally {
              o = void 0;
            }
            return s;
          };
        return t === void 0
          ? async (l) => ((!i || l?.forceRefresh) && (s = await d(l)), s)
          : async (l) => (
              (!i || l?.forceRefresh) && (s = await d(l)),
              a ? s : r(s) ? (t(s) && (await d(l)), s) : ((a = !0), s)
            );
      }));
  });
var yy = b(() => {
  dy();
  hy();
  Sy();
});
var vn = {};
st(vn, {
  DefaultIdentityProviderConfig: () => Kr,
  EXPIRATION_MS: () => QP,
  HttpApiKeyAuthSigner: () => Mu,
  HttpBearerAuthSigner: () => ku,
  NoAuthSigner: () => $t,
  createIsIdentityExpiredFunction: () => gy,
  createPaginator: () => kh,
  doesIdentityRequireRefresh: () => ki,
  getHttpAuthSchemeEndpointRuleSetPlugin: () => fs,
  getHttpAuthSchemePlugin: () => MR,
  getHttpSigningPlugin: () => ps,
  getSmithyContext: () => AR,
  httpAuthSchemeEndpointRuleSetMiddlewareOptions: () => Eh,
  httpAuthSchemeMiddleware: () => us,
  httpAuthSchemeMiddlewareOptions: () => Ch,
  httpSigningMiddleware: () => Sl,
  httpSigningMiddlewareOptions: () => Ph,
  isIdentityExpired: () => Fu,
  memoizeIdentityProvider: () => Lu,
  normalizeProvider: () => or,
  requestBuilder: () => Is,
  setFeature: () => XP,
});
var Je = b(() => {
  mh();
  Ah();
  Dh();
  Mh();
  Fh();
  ay();
  cy();
  yy();
});
var Tn = P((Jr) => {
  "use strict";
  var Uu = rr(),
    Hu = class {
      capacity;
      data = new Map();
      parameters = [];
      constructor({ size: t, params: r }) {
        ((this.capacity = t ?? 50), r && (this.parameters = r));
      }
      get(t, r) {
        let n = this.hash(t);
        if (n === !1) return r();
        if (!this.data.has(n)) {
          if (this.data.size > this.capacity + 10) {
            let s = this.data.keys(),
              o = 0;
            for (;;) {
              let { value: i, done: a } = s.next();
              if ((this.data.delete(i), a || ++o > 10)) break;
            }
          }
          this.data.set(n, r());
        }
        return this.data.get(n);
      }
      size() {
        return this.data.size;
      }
      hash(t) {
        let r = "",
          { parameters: n } = this;
        if (n.length === 0) return !1;
        for (let s of n) {
          let o = String(t[s] ?? "");
          if (o.includes("|;")) return !1;
          r += o + "|;";
        }
        return r;
      }
    },
    ZP = new RegExp(
      "^(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}$",
    ),
    Ey = (e) => ZP.test(e) || (e.startsWith("[") && e.endsWith("]")),
    e0 = new RegExp("^(?!.*-$)(?!-)[a-zA-Z0-9-]{1,63}$"),
    ju = (e, t = !1) => {
      if (!t) return e0.test(e);
      let r = e.split(".");
      for (let n of r) if (!ju(n)) return !1;
      return !0;
    },
    zu = {},
    Rs = "endpoints";
  function dr(e) {
    return typeof e != "object" || e == null
      ? e
      : "ref" in e
        ? `$${dr(e.ref)}`
        : "fn" in e
          ? `${e.fn}(${(e.argv || []).map(dr).join(", ")})`
          : JSON.stringify(e, null, 2);
  }
  var Ue = class extends Error {
      constructor(t) {
        (super(t), (this.name = "EndpointError"));
      }
    },
    t0 = (e, t) => e === t,
    r0 = (e) => {
      let t = e.split("."),
        r = [];
      for (let n of t) {
        let s = n.indexOf("[");
        if (s !== -1) {
          if (n.indexOf("]") !== n.length - 1)
            throw new Ue(`Path: '${e}' does not end with ']'`);
          let o = n.slice(s + 1, -1);
          if (Number.isNaN(parseInt(o)))
            throw new Ue(`Invalid array index: '${o}' in path: '${e}'`);
          (s !== 0 && r.push(n.slice(0, s)), r.push(o));
        } else r.push(n);
      }
      return r;
    },
    _y = (e, t) =>
      r0(t).reduce((r, n) => {
        if (typeof r != "object")
          throw new Ue(
            `Index '${n}' in '${t}' not found in '${JSON.stringify(e)}'`,
          );
        return Array.isArray(r) ? r[parseInt(n)] : r[n];
      }, e),
    n0 = (e) => e != null,
    s0 = (e) => !e,
    $u = { [Uu.EndpointURLScheme.HTTP]: 80, [Uu.EndpointURLScheme.HTTPS]: 443 },
    o0 = (e) => {
      let t = (() => {
        try {
          if (e instanceof URL) return e;
          if (typeof e == "object" && "hostname" in e) {
            let {
                hostname: g,
                port: h,
                protocol: E = "",
                path: C = "",
                query: I = {},
              } = e,
              R = new URL(`${E}//${g}${h ? `:${h}` : ""}${C}`);
            return (
              (R.search = Object.entries(I)
                .map(([O, $]) => `${O}=${$}`)
                .join("&")),
              R
            );
          }
          return new URL(e);
        } catch {
          return null;
        }
      })();
      if (!t)
        return (
          console.error(
            `Unable to parse ${JSON.stringify(e)} as a whatwg URL.`,
          ),
          null
        );
      let r = t.href,
        { host: n, hostname: s, pathname: o, protocol: i, search: a } = t;
      if (a) return null;
      let d = i.slice(0, -1);
      if (!Object.values(Uu.EndpointURLScheme).includes(d)) return null;
      let l = Ey(s),
        p =
          r.includes(`${n}:${$u[d]}`) ||
          (typeof e == "string" && e.includes(`${n}:${$u[d]}`)),
        m = `${n}${p ? `:${$u[d]}` : ""}`;
      return {
        scheme: d,
        authority: m,
        path: o,
        normalizedPath: o.endsWith("/") ? o : `${o}/`,
        isIp: l,
      };
    },
    i0 = (e, t) => e === t,
    a0 = (e, t, r, n) =>
      t >= r || e.length < r
        ? null
        : n
          ? e.substring(e.length - r, e.length - t)
          : e.substring(t, r),
    c0 = (e) =>
      encodeURIComponent(e).replace(
        /[!*'()]/g,
        (t) => `%${t.charCodeAt(0).toString(16).toUpperCase()}`,
      ),
    d0 = {
      booleanEquals: t0,
      getAttr: _y,
      isSet: n0,
      isValidHostLabel: ju,
      not: s0,
      parseURL: o0,
      stringEquals: i0,
      substring: a0,
      uriEncode: c0,
    },
    wy = (e, t) => {
      let r = [],
        n = { ...t.endpointParams, ...t.referenceRecord },
        s = 0;
      for (; s < e.length; ) {
        let o = e.indexOf("{", s);
        if (o === -1) {
          r.push(e.slice(s));
          break;
        }
        r.push(e.slice(s, o));
        let i = e.indexOf("}", o);
        if (i === -1) {
          r.push(e.slice(o));
          break;
        }
        e[o + 1] === "{" &&
          e[i + 1] === "}" &&
          (r.push(e.slice(o + 1, i)), (s = i + 2));
        let a = e.substring(o + 1, i);
        if (a.includes("#")) {
          let [d, l] = a.split("#");
          r.push(_y(n[d], l));
        } else r.push(n[a]);
        s = i + 1;
      }
      return r.join("");
    },
    l0 = ({ ref: e }, t) => ({ ...t.endpointParams, ...t.referenceRecord })[e],
    Fi = (e, t, r) => {
      if (typeof e == "string") return wy(e, r);
      if (e.fn) return by(e, r);
      if (e.ref) return l0(e, r);
      throw new Ue(
        `'${t}': ${String(e)} is not a string, function or reference.`,
      );
    },
    by = ({ fn: e, argv: t }, r) => {
      let n = t.map((o) =>
          ["boolean", "number"].includes(typeof o) ? o : Fi(o, "arg", r),
        ),
        s = e.split(".");
      return s[0] in zu && s[1] != null ? zu[s[0]][s[1]](...n) : d0[e](...n);
    },
    u0 = ({ assign: e, ...t }, r) => {
      if (e && e in r.referenceRecord)
        throw new Ue(`'${e}' is already defined in Reference Record.`);
      let n = by(t, r);
      return (
        r.logger?.debug?.(`${Rs} evaluateCondition: ${dr(t)} = ${dr(n)}`),
        {
          result: n === "" ? !0 : !!n,
          ...(e != null && { toAssign: { name: e, value: n } }),
        }
      );
    },
    Bu = (e = [], t) => {
      let r = {};
      for (let n of e) {
        let { result: s, toAssign: o } = u0(n, {
          ...t,
          referenceRecord: { ...t.referenceRecord, ...r },
        });
        if (!s) return { result: s };
        o &&
          ((r[o.name] = o.value),
          t.logger?.debug?.(`${Rs} assign: ${o.name} := ${dr(o.value)}`));
      }
      return { result: !0, referenceRecord: r };
    },
    f0 = (e, t) =>
      Object.entries(e).reduce(
        (r, [n, s]) => ({
          ...r,
          [n]: s.map((o) => {
            let i = Fi(o, "Header value entry", t);
            if (typeof i != "string")
              throw new Ue(`Header '${n}' value '${i}' is not a string`);
            return i;
          }),
        }),
        {},
      ),
    xy = (e, t) => {
      if (Array.isArray(e)) return e.map((r) => xy(r, t));
      switch (typeof e) {
        case "string":
          return wy(e, t);
        case "object":
          if (e === null) throw new Ue(`Unexpected endpoint property: ${e}`);
          return vy(e, t);
        case "boolean":
          return e;
        default:
          throw new Ue(`Unexpected endpoint property type: ${typeof e}`);
      }
    },
    vy = (e, t) =>
      Object.entries(e).reduce((r, [n, s]) => ({ ...r, [n]: xy(s, t) }), {}),
    p0 = (e, t) => {
      let r = Fi(e, "Endpoint URL", t);
      if (typeof r == "string")
        try {
          return new URL(r);
        } catch (n) {
          throw (console.error(`Failed to construct URL with ${r}`, n), n);
        }
      throw new Ue(`Endpoint URL must be a string, got ${typeof r}`);
    },
    m0 = (e, t) => {
      let { conditions: r, endpoint: n } = e,
        { result: s, referenceRecord: o } = Bu(r, t);
      if (!s) return;
      let i = { ...t, referenceRecord: { ...t.referenceRecord, ...o } },
        { url: a, properties: d, headers: l } = n;
      return (
        t.logger?.debug?.(`${Rs} Resolving endpoint from template: ${dr(n)}`),
        {
          ...(l != null && { headers: f0(l, i) }),
          ...(d != null && { properties: vy(d, i) }),
          url: p0(a, i),
        }
      );
    },
    h0 = (e, t) => {
      let { conditions: r, error: n } = e,
        { result: s, referenceRecord: o } = Bu(r, t);
      if (s)
        throw new Ue(
          Fi(n, "Error", {
            ...t,
            referenceRecord: { ...t.referenceRecord, ...o },
          }),
        );
    },
    g0 = (e, t) => {
      let { conditions: r, rules: n } = e,
        { result: s, referenceRecord: o } = Bu(r, t);
      if (s)
        return Ty(n, { ...t, referenceRecord: { ...t.referenceRecord, ...o } });
    },
    Ty = (e, t) => {
      for (let r of e)
        if (r.type === "endpoint") {
          let n = m0(r, t);
          if (n) return n;
        } else if (r.type === "error") h0(r, t);
        else if (r.type === "tree") {
          let n = g0(r, t);
          if (n) return n;
        } else throw new Ue(`Unknown endpoint rule: ${r}`);
      throw new Ue("Rules evaluation failed");
    },
    S0 = (e, t) => {
      let { endpointParams: r, logger: n } = t,
        { parameters: s, rules: o } = e;
      t.logger?.debug?.(`${Rs} Initial EndpointParams: ${dr(r)}`);
      let i = Object.entries(s)
        .filter(([, l]) => l.default != null)
        .map(([l, p]) => [l, p.default]);
      if (i.length > 0) for (let [l, p] of i) r[l] = r[l] ?? p;
      let a = Object.entries(s)
        .filter(([, l]) => l.required)
        .map(([l]) => l);
      for (let l of a)
        if (r[l] == null) throw new Ue(`Missing required parameter: '${l}'`);
      let d = Ty(o, { endpointParams: r, logger: n, referenceRecord: {} });
      return (t.logger?.debug?.(`${Rs} Resolved endpoint: ${dr(d)}`), d);
    };
  Jr.EndpointCache = Hu;
  Jr.EndpointError = Ue;
  Jr.customEndpointFunctions = zu;
  Jr.isIpAddress = Ey;
  Jr.isValidHostLabel = ju;
  Jr.resolveEndpoint = S0;
});
var Iy = P((Cy) => {
  "use strict";
  function y0(e) {
    let t = {};
    if (((e = e.replace(/^\?/, "")), e))
      for (let r of e.split("&")) {
        let [n, s = null] = r.split("=");
        ((n = decodeURIComponent(n)),
          s && (s = decodeURIComponent(s)),
          n in t
            ? Array.isArray(t[n])
              ? t[n].push(s)
              : (t[n] = [t[n], s])
            : (t[n] = s));
      }
    return t;
  }
  Cy.parseQueryString = y0;
});
var lr = P((Ry) => {
  "use strict";
  var E0 = Iy(),
    Ay = (e) => {
      if (typeof e == "string") return Ay(new URL(e));
      let { hostname: t, pathname: r, port: n, protocol: s, search: o } = e,
        i;
      return (
        o && (i = E0.parseQueryString(o)),
        {
          hostname: t,
          port: n ? parseInt(n) : void 0,
          protocol: s,
          path: r,
          query: i,
        }
      );
    };
  Ry.parseUrl = Ay;
});
var Cn = P((WV, Hy) => {
  "use strict";
  var Li = Object.defineProperty,
    _0 = Object.getOwnPropertyDescriptor,
    w0 = Object.getOwnPropertyNames,
    b0 = Object.prototype.hasOwnProperty,
    ur = (e, t) => Li(e, "name", { value: t, configurable: !0 }),
    x0 = (e, t) => {
      for (var r in t) Li(e, r, { get: t[r], enumerable: !0 });
    },
    v0 = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of w0(t))
          !b0.call(e, s) &&
            s !== r &&
            Li(e, s, {
              get: () => t[s],
              enumerable: !(n = _0(t, s)) || n.enumerable,
            });
      return e;
    },
    T0 = (e) => v0(Li({}, "__esModule", { value: !0 }), e),
    Py = {};
  x0(Py, {
    ConditionObject: () => he.ConditionObject,
    DeprecatedObject: () => he.DeprecatedObject,
    EndpointError: () => he.EndpointError,
    EndpointObject: () => he.EndpointObject,
    EndpointObjectHeaders: () => he.EndpointObjectHeaders,
    EndpointObjectProperties: () => he.EndpointObjectProperties,
    EndpointParams: () => he.EndpointParams,
    EndpointResolverOptions: () => he.EndpointResolverOptions,
    EndpointRuleObject: () => he.EndpointRuleObject,
    ErrorRuleObject: () => he.ErrorRuleObject,
    EvaluateOptions: () => he.EvaluateOptions,
    Expression: () => he.Expression,
    FunctionArgv: () => he.FunctionArgv,
    FunctionObject: () => he.FunctionObject,
    FunctionReturn: () => he.FunctionReturn,
    ParameterObject: () => he.ParameterObject,
    ReferenceObject: () => he.ReferenceObject,
    ReferenceRecord: () => he.ReferenceRecord,
    RuleSetObject: () => he.RuleSetObject,
    RuleSetRules: () => he.RuleSetRules,
    TreeRuleObject: () => he.TreeRuleObject,
    awsEndpointFunctions: () => $y,
    getUserAgentPrefix: () => R0,
    isIpAddress: () => he.isIpAddress,
    partition: () => Fy,
    resolveDefaultAwsRegionalEndpointsConfig: () => P0,
    resolveEndpoint: () => he.resolveEndpoint,
    setPartitionInfo: () => Ly,
    toEndpointV1: () => Uy,
    useDefaultPartitionInfo: () => A0,
  });
  Hy.exports = T0(Py);
  var he = Tn(),
    Oy = ur((e, t = !1) => {
      if (t) {
        for (let r of e.split(".")) if (!Oy(r)) return !1;
        return !0;
      }
      return !(
        !(0, he.isValidHostLabel)(e) ||
        e.length < 3 ||
        e.length > 63 ||
        e !== e.toLowerCase() ||
        (0, he.isIpAddress)(e)
      );
    }, "isVirtualHostableS3Bucket"),
    Ny = ":",
    C0 = "/",
    I0 = ur((e) => {
      let t = e.split(Ny);
      if (t.length < 6) return null;
      let [r, n, s, o, i, ...a] = t;
      if (r !== "arn" || n === "" || s === "" || a.join(Ny) === "") return null;
      let d = a.map((l) => l.split(C0)).flat();
      return {
        partition: n,
        service: s,
        region: o,
        accountId: i,
        resourceId: d,
      };
    }, "parseArn"),
    Dy = {
      partitions: [
        {
          id: "aws",
          outputs: {
            dnsSuffix: "amazonaws.com",
            dualStackDnsSuffix: "api.aws",
            implicitGlobalRegion: "us-east-1",
            name: "aws",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^(us|eu|ap|sa|ca|me|af|il|mx)\\-\\w+\\-\\d+$",
          regions: {
            "af-south-1": { description: "Africa (Cape Town)" },
            "ap-east-1": { description: "Asia Pacific (Hong Kong)" },
            "ap-east-2": { description: "Asia Pacific (Taipei)" },
            "ap-northeast-1": { description: "Asia Pacific (Tokyo)" },
            "ap-northeast-2": { description: "Asia Pacific (Seoul)" },
            "ap-northeast-3": { description: "Asia Pacific (Osaka)" },
            "ap-south-1": { description: "Asia Pacific (Mumbai)" },
            "ap-south-2": { description: "Asia Pacific (Hyderabad)" },
            "ap-southeast-1": { description: "Asia Pacific (Singapore)" },
            "ap-southeast-2": { description: "Asia Pacific (Sydney)" },
            "ap-southeast-3": { description: "Asia Pacific (Jakarta)" },
            "ap-southeast-4": { description: "Asia Pacific (Melbourne)" },
            "ap-southeast-5": { description: "Asia Pacific (Malaysia)" },
            "ap-southeast-6": { description: "Asia Pacific (New Zealand)" },
            "ap-southeast-7": { description: "Asia Pacific (Thailand)" },
            "aws-global": { description: "aws global region" },
            "ca-central-1": { description: "Canada (Central)" },
            "ca-west-1": { description: "Canada West (Calgary)" },
            "eu-central-1": { description: "Europe (Frankfurt)" },
            "eu-central-2": { description: "Europe (Zurich)" },
            "eu-north-1": { description: "Europe (Stockholm)" },
            "eu-south-1": { description: "Europe (Milan)" },
            "eu-south-2": { description: "Europe (Spain)" },
            "eu-west-1": { description: "Europe (Ireland)" },
            "eu-west-2": { description: "Europe (London)" },
            "eu-west-3": { description: "Europe (Paris)" },
            "il-central-1": { description: "Israel (Tel Aviv)" },
            "me-central-1": { description: "Middle East (UAE)" },
            "me-south-1": { description: "Middle East (Bahrain)" },
            "mx-central-1": { description: "Mexico (Central)" },
            "sa-east-1": { description: "South America (Sao Paulo)" },
            "us-east-1": { description: "US East (N. Virginia)" },
            "us-east-2": { description: "US East (Ohio)" },
            "us-west-1": { description: "US West (N. California)" },
            "us-west-2": { description: "US West (Oregon)" },
          },
        },
        {
          id: "aws-cn",
          outputs: {
            dnsSuffix: "amazonaws.com.cn",
            dualStackDnsSuffix: "api.amazonwebservices.com.cn",
            implicitGlobalRegion: "cn-northwest-1",
            name: "aws-cn",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^cn\\-\\w+\\-\\d+$",
          regions: {
            "aws-cn-global": { description: "aws-cn global region" },
            "cn-north-1": { description: "China (Beijing)" },
            "cn-northwest-1": { description: "China (Ningxia)" },
          },
        },
        {
          id: "aws-eusc",
          outputs: {
            dnsSuffix: "amazonaws.eu",
            dualStackDnsSuffix: "api.amazonwebservices.eu",
            implicitGlobalRegion: "eusc-de-east-1",
            name: "aws-eusc",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^eusc\\-(de)\\-\\w+\\-\\d+$",
          regions: { "eusc-de-east-1": { description: "EU (Germany)" } },
        },
        {
          id: "aws-iso",
          outputs: {
            dnsSuffix: "c2s.ic.gov",
            dualStackDnsSuffix: "api.aws.ic.gov",
            implicitGlobalRegion: "us-iso-east-1",
            name: "aws-iso",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^us\\-iso\\-\\w+\\-\\d+$",
          regions: {
            "aws-iso-global": { description: "aws-iso global region" },
            "us-iso-east-1": { description: "US ISO East" },
            "us-iso-west-1": { description: "US ISO WEST" },
          },
        },
        {
          id: "aws-iso-b",
          outputs: {
            dnsSuffix: "sc2s.sgov.gov",
            dualStackDnsSuffix: "api.aws.scloud",
            implicitGlobalRegion: "us-isob-east-1",
            name: "aws-iso-b",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^us\\-isob\\-\\w+\\-\\d+$",
          regions: {
            "aws-iso-b-global": { description: "aws-iso-b global region" },
            "us-isob-east-1": { description: "US ISOB East (Ohio)" },
          },
        },
        {
          id: "aws-iso-e",
          outputs: {
            dnsSuffix: "cloud.adc-e.uk",
            dualStackDnsSuffix: "api.cloud-aws.adc-e.uk",
            implicitGlobalRegion: "eu-isoe-west-1",
            name: "aws-iso-e",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^eu\\-isoe\\-\\w+\\-\\d+$",
          regions: {
            "aws-iso-e-global": { description: "aws-iso-e global region" },
            "eu-isoe-west-1": { description: "EU ISOE West" },
          },
        },
        {
          id: "aws-iso-f",
          outputs: {
            dnsSuffix: "csp.hci.ic.gov",
            dualStackDnsSuffix: "api.aws.hci.ic.gov",
            implicitGlobalRegion: "us-isof-south-1",
            name: "aws-iso-f",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^us\\-isof\\-\\w+\\-\\d+$",
          regions: {
            "aws-iso-f-global": { description: "aws-iso-f global region" },
            "us-isof-east-1": { description: "US ISOF EAST" },
            "us-isof-south-1": { description: "US ISOF SOUTH" },
          },
        },
        {
          id: "aws-us-gov",
          outputs: {
            dnsSuffix: "amazonaws.com",
            dualStackDnsSuffix: "api.aws",
            implicitGlobalRegion: "us-gov-west-1",
            name: "aws-us-gov",
            supportsDualStack: !0,
            supportsFIPS: !0,
          },
          regionRegex: "^us\\-gov\\-\\w+\\-\\d+$",
          regions: {
            "aws-us-gov-global": { description: "aws-us-gov global region" },
            "us-gov-east-1": { description: "AWS GovCloud (US-East)" },
            "us-gov-west-1": { description: "AWS GovCloud (US-West)" },
          },
        },
      ],
      version: "1.1",
    },
    My = Dy,
    ky = "",
    Fy = ur((e) => {
      let { partitions: t } = My;
      for (let n of t) {
        let { regions: s, outputs: o } = n;
        for (let [i, a] of Object.entries(s))
          if (i === e) return { ...o, ...a };
      }
      for (let n of t) {
        let { regionRegex: s, outputs: o } = n;
        if (new RegExp(s).test(e)) return { ...o };
      }
      let r = t.find((n) => n.id === "aws");
      if (!r)
        throw new Error(
          "Provided region was not found in the partition array or regex, and default partition with id 'aws' doesn't exist.",
        );
      return { ...r.outputs };
    }, "partition"),
    Ly = ur((e, t = "") => {
      ((My = e), (ky = t));
    }, "setPartitionInfo"),
    A0 = ur(() => {
      Ly(Dy, "");
    }, "useDefaultPartitionInfo"),
    R0 = ur(() => ky, "getUserAgentPrefix"),
    $y = { isVirtualHostableS3Bucket: Oy, parseArn: I0, partition: Fy };
  he.customEndpointFunctions.aws = $y;
  var N0 = lr(),
    P0 = ur((e) => {
      if (typeof e.endpointProvider != "function")
        throw new Error(
          "@aws-sdk/util-endpoint - endpointProvider and endpoint missing in config for this client.",
        );
      let { endpoint: t } = e;
      return (
        t === void 0 &&
          (e.endpoint = async () =>
            Uy(
              e.endpointProvider(
                {
                  Region:
                    typeof e.region == "function" ? await e.region() : e.region,
                  UseDualStack:
                    typeof e.useDualstackEndpoint == "function"
                      ? await e.useDualstackEndpoint()
                      : e.useDualstackEndpoint,
                  UseFIPS:
                    typeof e.useFipsEndpoint == "function"
                      ? await e.useFipsEndpoint()
                      : e.useFipsEndpoint,
                  Endpoint: void 0,
                },
                { logger: e.logger },
              ),
            )),
        e
      );
    }, "resolveDefaultAwsRegionalEndpointsConfig"),
    Uy = ur((e) => (0, N0.parseUrl)(e.url), "toEndpointV1");
});
var $i,
  In,
  zy = b(() => {
    (($i = { warningEmitted: !1 }),
      (In = (e) => {
        e &&
          !$i.warningEmitted &&
          parseInt(e.substring(1, e.indexOf("."))) < 18 &&
          (($i.warningEmitted = !0),
          process.emitWarning(`NodeDeprecationWarning: The AWS SDK for JavaScript (v3) will
no longer support Node.js 16.x on January 6, 2025.

To continue receiving updates to AWS services, bug fixes, and security
updates please upgrade to a supported Node.js LTS version.

More information can be found at: https://a.co/74kJMmI`));
      }));
  });
function fr(e, t, r) {
  return (e.$source || (e.$source = {}), (e.$source[t] = r), e);
}
var jy = b(() => {});
function By(e, t, r) {
  (e.__aws_sdk_context
    ? e.__aws_sdk_context.features || (e.__aws_sdk_context.features = {})
    : (e.__aws_sdk_context = { features: {} }),
    (e.__aws_sdk_context.features[t] = r));
}
var qy = b(() => {});
function Vy(e, t, r) {
  return (e.$source || (e.$source = {}), (e.$source[t] = r), e);
}
var Gy = b(() => {});
var pr = {};
st(pr, {
  emitWarningIfUnsupportedVersion: () => In,
  setCredentialFeature: () => fr,
  setFeature: () => By,
  setTokenFeature: () => Vy,
  state: () => $i,
});
var gt = b(() => {
  zy();
  jy();
  qy();
  Gy();
});
var Wy,
  qu,
  Ky = b(() => {
    ((Wy = v(me())),
      (qu = (e) =>
        Wy.HttpResponse.isInstance(e)
          ? (e.headers?.date ?? e.headers?.Date)
          : void 0));
  });
var An,
  Vu = b(() => {
    An = (e) => new Date(Date.now() + e);
  });
var Jy,
  Yy = b(() => {
    Vu();
    Jy = (e, t) => Math.abs(An(t).getTime() - e) >= 3e5;
  });
var Gu,
  Xy = b(() => {
    Yy();
    Gu = (e, t) => {
      let r = Date.parse(e);
      return Jy(r, t) ? r - Date.now() : t;
    };
  });
var Wu = b(() => {
  Ky();
  Vu();
  Xy();
});
var Qy,
  Ns,
  Rn,
  Ye,
  Ku,
  Ju = b(() => {
    Qy = v(me());
    Wu();
    ((Ns = (e, t) => {
      if (!t)
        throw new Error(
          `Property \`${e}\` is not resolved for AWS SDK SigV4Auth`,
        );
      return t;
    }),
      (Rn = async (e) => {
        let t = Ns("context", e.context),
          r = Ns("config", e.config),
          n = t.endpointV2?.properties?.authSchemes?.[0],
          o = await Ns("signer", r.signer)(n),
          i = e?.signingRegion,
          a = e?.signingRegionSet,
          d = e?.signingName;
        return {
          config: r,
          signer: o,
          signingRegion: i,
          signingRegionSet: a,
          signingName: d,
        };
      }),
      (Ye = class {
        async sign(t, r, n) {
          if (!Qy.HttpRequest.isInstance(t))
            throw new Error(
              "The request is not an instance of `HttpRequest` and cannot be signed",
            );
          let s = await Rn(n),
            { config: o, signer: i } = s,
            { signingRegion: a, signingName: d } = s,
            l = n.context;
          if (l?.authSchemes?.length ?? !1) {
            let [m, g] = l.authSchemes;
            m?.name === "sigv4a" &&
              g?.name === "sigv4" &&
              ((a = g?.signingRegion ?? a), (d = g?.signingName ?? d));
          }
          return await i.sign(t, {
            signingDate: An(o.systemClockOffset),
            signingRegion: a,
            signingService: d,
          });
        }
        errorHandler(t) {
          return (r) => {
            let n = r.ServerTime ?? qu(r.$response);
            if (n) {
              let s = Ns("config", t.config),
                o = s.systemClockOffset;
              ((s.systemClockOffset = Gu(n, s.systemClockOffset)),
                s.systemClockOffset !== o &&
                  r.$metadata &&
                  (r.$metadata.clockSkewCorrected = !0));
            }
            throw r;
          };
        }
        successHandler(t, r) {
          let n = qu(t);
          if (n) {
            let s = Ns("config", r.config);
            s.systemClockOffset = Gu(n, s.systemClockOffset);
          }
        }
      }),
      (Ku = Ye));
  });
var Zy,
  Ps,
  eE = b(() => {
    Zy = v(me());
    Wu();
    Ju();
    Ps = class extends Ye {
      async sign(t, r, n) {
        if (!Zy.HttpRequest.isInstance(t))
          throw new Error(
            "The request is not an instance of `HttpRequest` and cannot be signed",
          );
        let {
            config: s,
            signer: o,
            signingRegion: i,
            signingRegionSet: a,
            signingName: d,
          } = await Rn(n),
          p = ((await s.sigv4aSigningRegionSet?.()) ?? a ?? [i]).join(",");
        return await o.sign(t, {
          signingDate: An(s.systemClockOffset),
          signingRegion: p,
          signingService: d,
        });
      }
    };
  });
var Yu,
  tE = b(() => {
    Yu = (e) =>
      typeof e == "string" && e.length > 0
        ? e.split(",").map((t) => t.trim())
        : [];
  });
var Ui,
  Xu = b(() => {
    Ui = (e) => `AWS_BEARER_TOKEN_${e.replace(/[\s-]/g, "_").toUpperCase()}`;
  });
var rE,
  nE,
  Nn,
  sE = b(() => {
    tE();
    Xu();
    ((rE = "AWS_AUTH_SCHEME_PREFERENCE"),
      (nE = "auth_scheme_preference"),
      (Nn = {
        environmentVariableSelector: (e, t) => {
          if (t?.signingName && Ui(t.signingName) in e)
            return ["httpBearerAuth"];
          if (rE in e) return Yu(e[rE]);
        },
        configFileSelector: (e) => {
          if (nE in e) return Yu(e[nE]);
        },
        default: [],
      }));
  });
var qe = P((Yr) => {
  "use strict";
  var Pn = class e extends Error {
      name = "ProviderError";
      tryNextLink;
      constructor(t, r = !0) {
        let n,
          s = !0;
        (typeof r == "boolean"
          ? ((n = void 0), (s = r))
          : r != null &&
            typeof r == "object" &&
            ((n = r.logger), (s = r.tryNextLink ?? !0)),
          super(t),
          (this.tryNextLink = s),
          Object.setPrototypeOf(this, e.prototype),
          n?.debug?.(`@smithy/property-provider ${s ? "->" : "(!)"} ${t}`));
      }
      static from(t, r = !0) {
        return Object.assign(new this(t.message, r), t);
      }
    },
    Qu = class e extends Pn {
      name = "CredentialsProviderError";
      constructor(t, r = !0) {
        (super(t, r), Object.setPrototypeOf(this, e.prototype));
      }
    },
    Zu = class e extends Pn {
      name = "TokenProviderError";
      constructor(t, r = !0) {
        (super(t, r), Object.setPrototypeOf(this, e.prototype));
      }
    },
    O0 =
      (...e) =>
      async () => {
        if (e.length === 0) throw new Pn("No providers in chain");
        let t;
        for (let r of e)
          try {
            return await r();
          } catch (n) {
            if (((t = n), n?.tryNextLink)) continue;
            throw n;
          }
        throw t;
      },
    D0 = (e) => () => Promise.resolve(e),
    M0 = (e, t, r) => {
      let n,
        s,
        o,
        i = !1,
        a = async () => {
          s || (s = e());
          try {
            ((n = await s), (o = !0), (i = !1));
          } finally {
            s = void 0;
          }
          return n;
        };
      return t === void 0
        ? async (d) => ((!o || d?.forceRefresh) && (n = await a()), n)
        : async (d) => (
            (!o || d?.forceRefresh) && (n = await a()),
            i ? n : r && !r(n) ? ((i = !0), n) : (t(n) && (await a()), n)
          );
    };
  Yr.CredentialsProviderError = Qu;
  Yr.ProviderError = Pn;
  Yr.TokenProviderError = Zu;
  Yr.chain = O0;
  Yr.fromStatic = D0;
  Yr.memoize = M0;
});
var ef,
  oE,
  iE,
  aE = b(() => {
    Je();
    ((ef = v(qe())),
      (oE = (e) => (
        (e.sigv4aSigningRegionSet = or(e.sigv4aSigningRegionSet)),
        e
      )),
      (iE = {
        environmentVariableSelector(e) {
          if (e.AWS_SIGV4A_SIGNING_REGION_SET)
            return e.AWS_SIGV4A_SIGNING_REGION_SET.split(",").map((t) =>
              t.trim(),
            );
          throw new ef.ProviderError(
            "AWS_SIGV4A_SIGNING_REGION_SET not set in env.",
            { tryNextLink: !0 },
          );
        },
        configFileSelector(e) {
          if (e.sigv4a_signing_region_set)
            return (e.sigv4a_signing_region_set ?? "")
              .split(",")
              .map((t) => t.trim());
          throw new ef.ProviderError(
            "sigv4a_signing_region_set not set in profile.",
            { tryNextLink: !0 },
          );
        },
        default: void 0,
      }));
  });
var PE = P((G) => {
  "use strict";
  var mr = Gl(),
    Xr = Oe(),
    k0 = El(),
    uE = me(),
    cE = Ge(),
    Hi = Ol(),
    fE = "X-Amz-Algorithm",
    pE = "X-Amz-Credential",
    af = "X-Amz-Date",
    mE = "X-Amz-SignedHeaders",
    hE = "X-Amz-Expires",
    cf = "X-Amz-Signature",
    df = "X-Amz-Security-Token",
    F0 = "X-Amz-Region-Set",
    lf = "authorization",
    uf = af.toLowerCase(),
    gE = "date",
    SE = [lf, uf, gE],
    yE = cf.toLowerCase(),
    Vi = "x-amz-content-sha256",
    EE = df.toLowerCase(),
    L0 = "host",
    _E = {
      authorization: !0,
      "cache-control": !0,
      connection: !0,
      expect: !0,
      from: !0,
      "keep-alive": !0,
      "max-forwards": !0,
      pragma: !0,
      referer: !0,
      te: !0,
      trailer: !0,
      "transfer-encoding": !0,
      upgrade: !0,
      "user-agent": !0,
      "x-amzn-trace-id": !0,
    },
    wE = /^proxy-/,
    bE = /^sec-/,
    $0 = [/^proxy-/i, /^sec-/i],
    zi = "AWS4-HMAC-SHA256",
    U0 = "AWS4-ECDSA-P256-SHA256",
    xE = "AWS4-HMAC-SHA256-PAYLOAD",
    vE = "UNSIGNED-PAYLOAD",
    TE = 50,
    ff = "aws4_request",
    CE = 3600 * 24 * 7,
    On = {},
    ji = [],
    Bi = (e, t, r) => `${e}/${t}/${r}/${ff}`,
    IE = async (e, t, r, n, s) => {
      let o = await dE(e, t.secretAccessKey, t.accessKeyId),
        i = `${r}:${n}:${s}:${mr.toHex(o)}:${t.sessionToken}`;
      if (i in On) return On[i];
      for (ji.push(i); ji.length > TE; ) delete On[ji.shift()];
      let a = `AWS4${t.secretAccessKey}`;
      for (let d of [r, n, s, ff]) a = await dE(e, a, d);
      return (On[i] = a);
    },
    H0 = () => {
      ((ji.length = 0),
        Object.keys(On).forEach((e) => {
          delete On[e];
        }));
    },
    dE = (e, t, r) => {
      let n = new e(t);
      return (n.update(Xr.toUint8Array(r)), n.digest());
    },
    tf = ({ headers: e }, t, r) => {
      let n = {};
      for (let s of Object.keys(e).sort()) {
        if (e[s] == null) continue;
        let o = s.toLowerCase();
        ((o in _E || t?.has(o) || wE.test(o) || bE.test(o)) &&
          (!r || (r && !r.has(o)))) ||
          (n[o] = e[s].trim().replace(/\s+/g, " "));
      }
      return n;
    },
    qi = async ({ headers: e, body: t }, r) => {
      for (let n of Object.keys(e)) if (n.toLowerCase() === Vi) return e[n];
      if (t == null)
        return "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
      if (
        typeof t == "string" ||
        ArrayBuffer.isView(t) ||
        k0.isArrayBuffer(t)
      ) {
        let n = new r();
        return (n.update(Xr.toUint8Array(t)), mr.toHex(await n.digest()));
      }
      return vE;
    },
    rf = class {
      format(t) {
        let r = [];
        for (let o of Object.keys(t)) {
          let i = Xr.fromUtf8(o);
          r.push(
            Uint8Array.from([i.byteLength]),
            i,
            this.formatHeaderValue(t[o]),
          );
        }
        let n = new Uint8Array(r.reduce((o, i) => o + i.byteLength, 0)),
          s = 0;
        for (let o of r) (n.set(o, s), (s += o.byteLength));
        return n;
      }
      formatHeaderValue(t) {
        switch (t.type) {
          case "boolean":
            return Uint8Array.from([t.value ? 0 : 1]);
          case "byte":
            return Uint8Array.from([2, t.value]);
          case "short":
            let r = new DataView(new ArrayBuffer(3));
            return (
              r.setUint8(0, 3),
              r.setInt16(1, t.value, !1),
              new Uint8Array(r.buffer)
            );
          case "integer":
            let n = new DataView(new ArrayBuffer(5));
            return (
              n.setUint8(0, 4),
              n.setInt32(1, t.value, !1),
              new Uint8Array(n.buffer)
            );
          case "long":
            let s = new Uint8Array(9);
            return ((s[0] = 5), s.set(t.value.bytes, 1), s);
          case "binary":
            let o = new DataView(new ArrayBuffer(3 + t.value.byteLength));
            (o.setUint8(0, 6), o.setUint16(1, t.value.byteLength, !1));
            let i = new Uint8Array(o.buffer);
            return (i.set(t.value, 3), i);
          case "string":
            let a = Xr.fromUtf8(t.value),
              d = new DataView(new ArrayBuffer(3 + a.byteLength));
            (d.setUint8(0, 7), d.setUint16(1, a.byteLength, !1));
            let l = new Uint8Array(d.buffer);
            return (l.set(a, 3), l);
          case "timestamp":
            let p = new Uint8Array(9);
            return (
              (p[0] = 8),
              p.set(nf.fromNumber(t.value.valueOf()).bytes, 1),
              p
            );
          case "uuid":
            if (!z0.test(t.value))
              throw new Error(`Invalid UUID received: ${t.value}`);
            let m = new Uint8Array(17);
            return (
              (m[0] = 9),
              m.set(mr.fromHex(t.value.replace(/\-/g, "")), 1),
              m
            );
        }
      }
    },
    z0 = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/,
    nf = class e {
      bytes;
      constructor(t) {
        if (((this.bytes = t), t.byteLength !== 8))
          throw new Error("Int64 buffers must be exactly 8 bytes");
      }
      static fromNumber(t) {
        if (t > 9223372036854776e3 || t < -9223372036854776e3)
          throw new Error(
            `${t} is too large (or, if negative, too small) to represent as an Int64`,
          );
        let r = new Uint8Array(8);
        for (
          let n = 7, s = Math.abs(Math.round(t));
          n > -1 && s > 0;
          n--, s /= 256
        )
          r[n] = s;
        return (t < 0 && lE(r), new e(r));
      }
      valueOf() {
        let t = this.bytes.slice(0),
          r = t[0] & 128;
        return (r && lE(t), parseInt(mr.toHex(t), 16) * (r ? -1 : 1));
      }
      toString() {
        return String(this.valueOf());
      }
    };
  function lE(e) {
    for (let t = 0; t < 8; t++) e[t] ^= 255;
    for (let t = 7; t > -1 && (e[t]++, e[t] === 0); t--);
  }
  var AE = (e, t) => {
      e = e.toLowerCase();
      for (let r of Object.keys(t)) if (e === r.toLowerCase()) return !0;
      return !1;
    },
    RE = (e, t = {}) => {
      let { headers: r, query: n = {} } = uE.HttpRequest.clone(e);
      for (let s of Object.keys(r)) {
        let o = s.toLowerCase();
        ((o.slice(0, 6) === "x-amz-" && !t.unhoistableHeaders?.has(o)) ||
          t.hoistableHeaders?.has(o)) &&
          ((n[s] = r[s]), delete r[s]);
      }
      return { ...e, headers: r, query: n };
    },
    sf = (e) => {
      e = uE.HttpRequest.clone(e);
      for (let t of Object.keys(e.headers))
        SE.indexOf(t.toLowerCase()) > -1 && delete e.headers[t];
      return e;
    },
    NE = ({ query: e = {} }) => {
      let t = [],
        r = {};
      for (let n of Object.keys(e)) {
        if (n.toLowerCase() === yE) continue;
        let s = Hi.escapeUri(n);
        t.push(s);
        let o = e[n];
        typeof o == "string"
          ? (r[s] = `${s}=${Hi.escapeUri(o)}`)
          : Array.isArray(o) &&
            (r[s] = o
              .slice(0)
              .reduce((i, a) => i.concat([`${s}=${Hi.escapeUri(a)}`]), [])
              .sort()
              .join("&"));
      }
      return t
        .sort()
        .map((n) => r[n])
        .filter((n) => n)
        .join("&");
    },
    j0 = (e) =>
      B0(e)
        .toISOString()
        .replace(/\.\d{3}Z$/, "Z"),
    B0 = (e) =>
      typeof e == "number"
        ? new Date(e * 1e3)
        : typeof e == "string"
          ? Number(e)
            ? new Date(Number(e) * 1e3)
            : new Date(e)
          : e,
    Gi = class {
      service;
      regionProvider;
      credentialProvider;
      sha256;
      uriEscapePath;
      applyChecksum;
      constructor({
        applyChecksum: t,
        credentials: r,
        region: n,
        service: s,
        sha256: o,
        uriEscapePath: i = !0,
      }) {
        ((this.service = s),
          (this.sha256 = o),
          (this.uriEscapePath = i),
          (this.applyChecksum = typeof t == "boolean" ? t : !0),
          (this.regionProvider = cE.normalizeProvider(n)),
          (this.credentialProvider = cE.normalizeProvider(r)));
      }
      createCanonicalRequest(t, r, n) {
        let s = Object.keys(r).sort();
        return `${t.method}
${this.getCanonicalPath(t)}
${NE(t)}
${s.map((o) => `${o}:${r[o]}`).join(`
`)}

${s.join(";")}
${n}`;
      }
      async createStringToSign(t, r, n, s) {
        let o = new this.sha256();
        o.update(Xr.toUint8Array(n));
        let i = await o.digest();
        return `${s}
${t}
${r}
${mr.toHex(i)}`;
      }
      getCanonicalPath({ path: t }) {
        if (this.uriEscapePath) {
          let r = [];
          for (let o of t.split("/"))
            o?.length !== 0 && o !== "." && (o === ".." ? r.pop() : r.push(o));
          let n = `${t?.startsWith("/") ? "/" : ""}${r.join("/")}${r.length > 0 && t?.endsWith("/") ? "/" : ""}`;
          return Hi.escapeUri(n).replace(/%2F/g, "/");
        }
        return t;
      }
      validateResolvedCredentials(t) {
        if (
          typeof t != "object" ||
          typeof t.accessKeyId != "string" ||
          typeof t.secretAccessKey != "string"
        )
          throw new Error("Resolved credential object is not valid");
      }
      formatDate(t) {
        let r = j0(t).replace(/[\-:]/g, "");
        return { longDate: r, shortDate: r.slice(0, 8) };
      }
      getCanonicalHeaderList(t) {
        return Object.keys(t).sort().join(";");
      }
    },
    of = class extends Gi {
      headerFormatter = new rf();
      constructor({
        applyChecksum: t,
        credentials: r,
        region: n,
        service: s,
        sha256: o,
        uriEscapePath: i = !0,
      }) {
        super({
          applyChecksum: t,
          credentials: r,
          region: n,
          service: s,
          sha256: o,
          uriEscapePath: i,
        });
      }
      async presign(t, r = {}) {
        let {
            signingDate: n = new Date(),
            expiresIn: s = 3600,
            unsignableHeaders: o,
            unhoistableHeaders: i,
            signableHeaders: a,
            hoistableHeaders: d,
            signingRegion: l,
            signingService: p,
          } = r,
          m = await this.credentialProvider();
        this.validateResolvedCredentials(m);
        let g = l ?? (await this.regionProvider()),
          { longDate: h, shortDate: E } = this.formatDate(n);
        if (s > CE)
          return Promise.reject(
            "Signature version 4 presigned URLs must have an expiration date less than one week in the future",
          );
        let C = Bi(E, g, p ?? this.service),
          I = RE(sf(t), { unhoistableHeaders: i, hoistableHeaders: d });
        (m.sessionToken && (I.query[df] = m.sessionToken),
          (I.query[fE] = zi),
          (I.query[pE] = `${m.accessKeyId}/${C}`),
          (I.query[af] = h),
          (I.query[hE] = s.toString(10)));
        let R = tf(I, o, a);
        return (
          (I.query[mE] = this.getCanonicalHeaderList(R)),
          (I.query[cf] = await this.getSignature(
            h,
            C,
            this.getSigningKey(m, g, E, p),
            this.createCanonicalRequest(I, R, await qi(t, this.sha256)),
          )),
          I
        );
      }
      async sign(t, r) {
        return typeof t == "string"
          ? this.signString(t, r)
          : t.headers && t.payload
            ? this.signEvent(t, r)
            : t.message
              ? this.signMessage(t, r)
              : this.signRequest(t, r);
      }
      async signEvent(
        { headers: t, payload: r },
        {
          signingDate: n = new Date(),
          priorSignature: s,
          signingRegion: o,
          signingService: i,
        },
      ) {
        let a = o ?? (await this.regionProvider()),
          { shortDate: d, longDate: l } = this.formatDate(n),
          p = Bi(d, a, i ?? this.service),
          m = await qi({ headers: {}, body: r }, this.sha256),
          g = new this.sha256();
        g.update(t);
        let h = mr.toHex(await g.digest()),
          E = [xE, l, p, s, h, m].join(`
`);
        return this.signString(E, {
          signingDate: n,
          signingRegion: a,
          signingService: i,
        });
      }
      async signMessage(
        t,
        { signingDate: r = new Date(), signingRegion: n, signingService: s },
      ) {
        return this.signEvent(
          {
            headers: this.headerFormatter.format(t.message.headers),
            payload: t.message.body,
          },
          {
            signingDate: r,
            signingRegion: n,
            signingService: s,
            priorSignature: t.priorSignature,
          },
        ).then((i) => ({ message: t.message, signature: i }));
      }
      async signString(
        t,
        {
          signingDate: r = new Date(),
          signingRegion: n,
          signingService: s,
        } = {},
      ) {
        let o = await this.credentialProvider();
        this.validateResolvedCredentials(o);
        let i = n ?? (await this.regionProvider()),
          { shortDate: a } = this.formatDate(r),
          d = new this.sha256(await this.getSigningKey(o, i, a, s));
        return (d.update(Xr.toUint8Array(t)), mr.toHex(await d.digest()));
      }
      async signRequest(
        t,
        {
          signingDate: r = new Date(),
          signableHeaders: n,
          unsignableHeaders: s,
          signingRegion: o,
          signingService: i,
        } = {},
      ) {
        let a = await this.credentialProvider();
        this.validateResolvedCredentials(a);
        let d = o ?? (await this.regionProvider()),
          l = sf(t),
          { longDate: p, shortDate: m } = this.formatDate(r),
          g = Bi(m, d, i ?? this.service);
        ((l.headers[uf] = p),
          a.sessionToken && (l.headers[EE] = a.sessionToken));
        let h = await qi(l, this.sha256);
        !AE(Vi, l.headers) && this.applyChecksum && (l.headers[Vi] = h);
        let E = tf(l, s, n),
          C = await this.getSignature(
            p,
            g,
            this.getSigningKey(a, d, m, i),
            this.createCanonicalRequest(l, E, h),
          );
        return (
          (l.headers[lf] =
            `${zi} Credential=${a.accessKeyId}/${g}, SignedHeaders=${this.getCanonicalHeaderList(E)}, Signature=${C}`),
          l
        );
      }
      async getSignature(t, r, n, s) {
        let o = await this.createStringToSign(t, r, s, zi),
          i = new this.sha256(await n);
        return (i.update(Xr.toUint8Array(o)), mr.toHex(await i.digest()));
      }
      getSigningKey(t, r, n, s) {
        return IE(this.sha256, t, n, r, s || this.service);
      }
    },
    q0 = { SignatureV4a: null };
  G.ALGORITHM_IDENTIFIER = zi;
  G.ALGORITHM_IDENTIFIER_V4A = U0;
  G.ALGORITHM_QUERY_PARAM = fE;
  G.ALWAYS_UNSIGNABLE_HEADERS = _E;
  G.AMZ_DATE_HEADER = uf;
  G.AMZ_DATE_QUERY_PARAM = af;
  G.AUTH_HEADER = lf;
  G.CREDENTIAL_QUERY_PARAM = pE;
  G.DATE_HEADER = gE;
  G.EVENT_ALGORITHM_IDENTIFIER = xE;
  G.EXPIRES_QUERY_PARAM = hE;
  G.GENERATED_HEADERS = SE;
  G.HOST_HEADER = L0;
  G.KEY_TYPE_IDENTIFIER = ff;
  G.MAX_CACHE_SIZE = TE;
  G.MAX_PRESIGNED_TTL = CE;
  G.PROXY_HEADER_PATTERN = wE;
  G.REGION_SET_PARAM = F0;
  G.SEC_HEADER_PATTERN = bE;
  G.SHA256_HEADER = Vi;
  G.SIGNATURE_HEADER = yE;
  G.SIGNATURE_QUERY_PARAM = cf;
  G.SIGNED_HEADERS_QUERY_PARAM = mE;
  G.SignatureV4 = of;
  G.SignatureV4Base = Gi;
  G.TOKEN_HEADER = EE;
  G.TOKEN_QUERY_PARAM = df;
  G.UNSIGNABLE_PATTERNS = $0;
  G.UNSIGNED_PAYLOAD = vE;
  G.clearCredentialCache = H0;
  G.createScope = Bi;
  G.getCanonicalHeaders = tf;
  G.getCanonicalQuery = NE;
  G.getPayloadHash = qi;
  G.getSigningKey = IE;
  G.hasHeader = AE;
  G.moveHeadersToQuery = RE;
  G.prepareRequest = sf;
  G.signatureV4aContainer = q0;
});
function V0(e, { credentials: t, credentialDefaultProvider: r }) {
  let n;
  return (
    t
      ? t?.memoized
        ? (n = t)
        : (n = Lu(t, Fu, ki))
      : r
        ? (n = or(r(Object.assign({}, e, { parentClientConfig: e }))))
        : (n = async () => {
            throw new Error(
              "@aws-sdk/core::resolveAwsSdkSigV4Config - `credentials` not provided and no credentialDefaultProvider was configured.",
            );
          }),
    (n.memoized = !0),
    n
  );
}
function G0(e, t) {
  if (t.configBound) return t;
  let r = async (n) => t({ ...n, callerClientConfig: e });
  return ((r.memoized = t.memoized), (r.configBound = !0), r);
}
var pf,
  Qr,
  OE,
  DE = b(() => {
    gt();
    Je();
    ((pf = v(PE())),
      (Qr = (e) => {
        let t = e.credentials,
          r = !!e.credentials,
          n;
        (Object.defineProperty(e, "credentials", {
          set(l) {
            (l && l !== t && l !== n && (r = !0), (t = l));
            let p = V0(e, {
                credentials: t,
                credentialDefaultProvider: e.credentialDefaultProvider,
              }),
              m = G0(e, p);
            r && !m.attributed
              ? ((n = async (g) =>
                  m(g).then((h) => fr(h, "CREDENTIALS_CODE", "e"))),
                (n.memoized = m.memoized),
                (n.configBound = m.configBound),
                (n.attributed = !0))
              : (n = m);
          },
          get() {
            return n;
          },
          enumerable: !0,
          configurable: !0,
        }),
          (e.credentials = t));
        let {
            signingEscapePath: s = !0,
            systemClockOffset: o = e.systemClockOffset || 0,
            sha256: i,
          } = e,
          a;
        return (
          e.signer
            ? (a = or(e.signer))
            : e.regionInfoProvider
              ? (a = () =>
                  or(e.region)()
                    .then(async (l) => [
                      (await e.regionInfoProvider(l, {
                        useFipsEndpoint: await e.useFipsEndpoint(),
                        useDualstackEndpoint: await e.useDualstackEndpoint(),
                      })) || {},
                      l,
                    ])
                    .then(([l, p]) => {
                      let { signingRegion: m, signingService: g } = l;
                      ((e.signingRegion = e.signingRegion || m || p),
                        (e.signingName = e.signingName || g || e.serviceId));
                      let h = {
                          ...e,
                          credentials: e.credentials,
                          region: e.signingRegion,
                          service: e.signingName,
                          sha256: i,
                          uriEscapePath: s,
                        },
                        E = e.signerConstructor || pf.SignatureV4;
                      return new E(h);
                    }))
              : (a = async (l) => {
                  l = Object.assign(
                    {},
                    {
                      name: "sigv4",
                      signingName: e.signingName || e.defaultSigningName,
                      signingRegion: await or(e.region)(),
                      properties: {},
                    },
                    l,
                  );
                  let p = l.signingRegion,
                    m = l.signingName;
                  ((e.signingRegion = e.signingRegion || p),
                    (e.signingName = e.signingName || m || e.serviceId));
                  let g = {
                      ...e,
                      credentials: e.credentials,
                      region: e.signingRegion,
                      service: e.signingName,
                      sha256: i,
                      uriEscapePath: s,
                    },
                    h = e.signerConstructor || pf.SignatureV4;
                  return new h(g);
                }),
          Object.assign(e, {
            systemClockOffset: o,
            signingEscapePath: s,
            signer: a,
          })
        );
      }),
      (OE = Qr));
  });
var ME = b(() => {
  Ju();
  eE();
  sE();
  aE();
  DE();
});
var kE = {};
st(kE, {
  AWSSDKSigV4Signer: () => Ku,
  AwsSdkSigV4ASigner: () => Ps,
  AwsSdkSigV4Signer: () => Ye,
  NODE_AUTH_SCHEME_PREFERENCE_OPTIONS: () => Nn,
  NODE_SIGV4A_CONFIG_OPTIONS: () => iE,
  getBearerTokenEnvKey: () => Ui,
  resolveAWSSDKSigV4Config: () => OE,
  resolveAwsSdkSigV4AConfig: () => oE,
  resolveAwsSdkSigV4Config: () => Qr,
  validateSigningProperties: () => Rn,
});
var mf = b(() => {
  ME();
  Xu();
});
function hr(e) {
  return typeof Buffer < "u" ? Buffer.alloc(e) : new Uint8Array(e);
}
function Wi(e) {
  return ((e[hf] = !0), e);
}
var hf,
  Ki = b(() => {
    hf = Symbol("@smithy/core/cbor::tagSymbol");
  });
function $E(e) {
  ((fe = e), (Ht = new DataView(fe.buffer, fe.byteOffset, fe.byteLength)));
}
function vt(e, t) {
  if (e >= t) throw new Error("unexpected end of (decode) payload.");
  let r = (fe[e] & 224) >> 5,
    n = fe[e] & 31;
  switch (r) {
    case 0:
    case 1:
    case 6:
      let s, o;
      if (n < 24) ((s = n), (o = 1));
      else
        switch (n) {
          case 24:
          case 25:
          case 26:
          case 27:
            let i = HE[n],
              a = i + 1;
            if (((o = a), t - e < a))
              throw new Error(
                `countLength ${i} greater than remaining buf len.`,
              );
            let d = e + 1;
            i === 1
              ? (s = fe[d])
              : i === 2
                ? (s = Ht.getUint16(d))
                : i === 4
                  ? (s = Ht.getUint32(d))
                  : (s = Ht.getBigUint64(d));
            break;
          default:
            throw new Error(`unexpected minor value ${n}.`);
        }
      if (r === 0) return ((J = o), gf(s));
      if (r === 1) {
        let i;
        return (
          typeof s == "bigint" ? (i = BigInt(-1) - s) : (i = -1 - s),
          (J = o),
          gf(i)
        );
      } else if (n === 2 || n === 3) {
        let i = ks(e + o, t),
          a = BigInt(0),
          d = e + o + J;
        for (let l = d; l < d + i; ++l) a = (a << BigInt(8)) | BigInt(fe[l]);
        return ((J = o + J + i), n === 3 ? -a - BigInt(1) : a);
      } else if (n === 4) {
        let i = vt(e + o, t),
          [a, d] = i,
          l = d < 0 ? -1 : 1,
          p = "0".repeat(Math.abs(a) + 1) + String(BigInt(l) * BigInt(d)),
          m,
          g = d < 0 ? "-" : "";
        return (
          (m = a === 0 ? p : p.slice(0, p.length + a) + "." + p.slice(a)),
          (m = m.replace(/^0+/g, "")),
          m === "" && (m = "0"),
          m[0] === "." && (m = "0" + m),
          (m = g + m),
          (J = o + J),
          Tu(m)
        );
      } else {
        let i = vt(e + o, t);
        return ((J = o + J), Wi({ tag: gf(s), value: i }));
      }
    case 3:
    case 5:
    case 4:
    case 2:
      if (n === 31)
        switch (r) {
          case 3:
            return Z0(e, t);
          case 5:
            return sO(e, t);
          case 4:
            return rO(e, t);
          case 2:
            return eO(e, t);
        }
      else
        switch (r) {
          case 3:
            return Q0(e, t);
          case 5:
            return nO(e, t);
          case 4:
            return tO(e, t);
          case 2:
            return bf(e, t);
        }
    default:
      return oO(e, t);
  }
}
function UE(e, t, r) {
  return J0 && e.constructor?.name === "Buffer"
    ? e.toString("utf-8", t, r)
    : FE
      ? FE.decode(e.subarray(t, r))
      : (0, LE.toUtf8)(e.subarray(t, r));
}
function Y0(e) {
  let t = Number(e);
  return (
    (t < Number.MIN_SAFE_INTEGER || Number.MAX_SAFE_INTEGER < t) &&
      console.warn(
        new Error(
          `@smithy/core/cbor - truncating BigInt(${e}) to ${t} with loss of precision.`,
        ),
      ),
    t
  );
}
function X0(e, t) {
  let r = e >> 7,
    n = (e & 124) >> 2,
    s = ((e & 3) << 8) | t,
    o = r === 0 ? 1 : -1,
    i,
    a;
  if (n === 0) {
    if (s === 0) return 0;
    ((i = Math.pow(2, -14)), (a = 0));
  } else {
    if (n === 31) return s === 0 ? o * (1 / 0) : NaN;
    ((i = Math.pow(2, n - 15)), (a = 1));
  }
  return ((a += s / 1024), o * (i * a));
}
function ks(e, t) {
  let r = fe[e] & 31;
  if (r < 24) return ((J = 1), r);
  if (r === 24 || r === 25 || r === 26 || r === 27) {
    let n = HE[r];
    if (((J = n + 1), t - e < J))
      throw new Error(`countLength ${n} greater than remaining buf len.`);
    let s = e + 1;
    return n === 1
      ? fe[s]
      : n === 2
        ? Ht.getUint16(s)
        : n === 4
          ? Ht.getUint32(s)
          : Y0(Ht.getBigUint64(s));
  }
  throw new Error(`unexpected minor value ${r}.`);
}
function Q0(e, t) {
  let r = ks(e, t),
    n = J;
  if (((e += n), t - e < r))
    throw new Error(`string len ${r} greater than remaining buf len.`);
  let s = UE(fe, e, e + r);
  return ((J = n + r), s);
}
function Z0(e, t) {
  e += 1;
  let r = [];
  for (let n = e; e < t; ) {
    if (fe[e] === 255) {
      let d = hr(r.length);
      return (d.set(r, 0), (J = e - n + 2), UE(d, 0, d.length));
    }
    let s = (fe[e] & 224) >> 5,
      o = fe[e] & 31;
    if (s !== 3)
      throw new Error(`unexpected major type ${s} in indefinite string.`);
    if (o === 31) throw new Error("nested indefinite string.");
    let i = bf(e, t);
    e += J;
    for (let d = 0; d < i.length; ++d) r.push(i[d]);
  }
  throw new Error("expected break marker.");
}
function bf(e, t) {
  let r = ks(e, t),
    n = J;
  if (((e += n), t - e < r))
    throw new Error(
      `unstructured byte string len ${r} greater than remaining buf len.`,
    );
  let s = fe.subarray(e, e + r);
  return ((J = n + r), s);
}
function eO(e, t) {
  e += 1;
  let r = [];
  for (let n = e; e < t; ) {
    if (fe[e] === 255) {
      let d = hr(r.length);
      return (d.set(r, 0), (J = e - n + 2), d);
    }
    let s = (fe[e] & 224) >> 5,
      o = fe[e] & 31;
    if (s !== 2)
      throw new Error(`unexpected major type ${s} in indefinite string.`);
    if (o === 31) throw new Error("nested indefinite string.");
    let i = bf(e, t);
    e += J;
    for (let d = 0; d < i.length; ++d) r.push(i[d]);
  }
  throw new Error("expected break marker.");
}
function tO(e, t) {
  let r = ks(e, t),
    n = J;
  e += n;
  let s = e,
    o = Array(r);
  for (let i = 0; i < r; ++i) {
    let a = vt(e, t),
      d = J;
    ((o[i] = a), (e += d));
  }
  return ((J = n + (e - s)), o);
}
function rO(e, t) {
  e += 1;
  let r = [];
  for (let n = e; e < t; ) {
    if (fe[e] === 255) return ((J = e - n + 2), r);
    let s = vt(e, t);
    ((e += J), r.push(s));
  }
  throw new Error("expected break marker.");
}
function nO(e, t) {
  let r = ks(e, t),
    n = J;
  e += n;
  let s = e,
    o = {};
  for (let i = 0; i < r; ++i) {
    if (e >= t) throw new Error("unexpected end of map payload.");
    let a = (fe[e] & 224) >> 5;
    if (a !== 3)
      throw new Error(`unexpected major type ${a} for map key at index ${e}.`);
    let d = vt(e, t);
    e += J;
    let l = vt(e, t);
    ((e += J), (o[d] = l));
  }
  return ((J = n + (e - s)), o);
}
function sO(e, t) {
  e += 1;
  let r = e,
    n = {};
  for (; e < t; ) {
    if (e >= t) throw new Error("unexpected end of map payload.");
    if (fe[e] === 255) return ((J = e - r + 2), n);
    let s = (fe[e] & 224) >> 5;
    if (s !== 3) throw new Error(`unexpected major type ${s} for map key.`);
    let o = vt(e, t);
    e += J;
    let i = vt(e, t);
    ((e += J), (n[o] = i));
  }
  throw new Error("expected break marker.");
}
function oO(e, t) {
  let r = fe[e] & 31;
  switch (r) {
    case 21:
    case 20:
      return ((J = 1), r === 21);
    case 22:
      return ((J = 1), null);
    case 23:
      return ((J = 1), null);
    case 25:
      if (t - e < 3) throw new Error("incomplete float16 at end of buf.");
      return ((J = 3), X0(fe[e + 1], fe[e + 2]));
    case 26:
      if (t - e < 5) throw new Error("incomplete float32 at end of buf.");
      return ((J = 5), Ht.getFloat32(e + 1));
    case 27:
      if (t - e < 9) throw new Error("incomplete float64 at end of buf.");
      return ((J = 9), Ht.getFloat64(e + 1));
    default:
      throw new Error(`unexpected minor value ${r}.`);
  }
}
function gf(e) {
  if (typeof e == "number") return e;
  let t = Number(e);
  return Number.MIN_SAFE_INTEGER <= t && t <= Number.MAX_SAFE_INTEGER ? t : e;
}
var LE,
  K0,
  J0,
  fe,
  Ht,
  FE,
  J,
  HE,
  zE = b(() => {
    Ke();
    LE = v(Oe());
    Ki();
    ((K0 = typeof TextDecoder < "u"),
      (J0 = typeof Buffer < "u"),
      (fe = hr(0)),
      (Ht = new DataView(fe.buffer, fe.byteOffset, fe.byteLength)),
      (FE = K0 ? new TextDecoder() : null),
      (J = 0));
    HE = { 24: 1, 25: 2, 26: 4, 27: 8 };
  });
function vf(e) {
  B.byteLength - U < e &&
    (U < 16e6
      ? Yi(Math.max(B.byteLength * 4, B.byteLength + e))
      : Yi(B.byteLength + e + 16e6));
}
function Tf() {
  let e = hr(U);
  return (e.set(B.subarray(0, U), 0), (U = 0), e);
}
function Yi(e) {
  let t = B;
  ((B = hr(e)),
    t && (t.copy ? t.copy(B, 0, 0, t.byteLength) : B.set(t, 0)),
    (Bt = new DataView(B.buffer, B.byteOffset, B.byteLength)));
}
function jt(e, t) {
  t < 24
    ? (B[U++] = (e << 5) | t)
    : t < 256
      ? ((B[U++] = (e << 5) | 24), (B[U++] = t))
      : t < 65536
        ? ((B[U++] = (e << 5) | 25), Bt.setUint16(U, t), (U += 2))
        : t < 2 ** 32
          ? ((B[U++] = (e << 5) | 26), Bt.setUint32(U, t), (U += 4))
          : ((B[U++] = (e << 5) | 27),
            Bt.setBigUint64(U, typeof t == "bigint" ? t : BigInt(t)),
            (U += 8));
}
function qE(e) {
  let t = [e];
  for (; t.length; ) {
    let r = t.pop();
    if ((vf(typeof r == "string" ? r.length * 4 : 64), typeof r == "string")) {
      if (jE) (jt(3, Buffer.byteLength(r)), (U += B.write(r, U)));
      else {
        let n = (0, BE.fromUtf8)(r);
        (jt(3, n.byteLength), B.set(n, U), (U += n.byteLength));
      }
      continue;
    } else if (typeof r == "number") {
      if (Number.isInteger(r)) {
        let n = r >= 0,
          s = n ? 0 : 1,
          o = n ? r : -r - 1;
        o < 24
          ? (B[U++] = (s << 5) | o)
          : o < 256
            ? ((B[U++] = (s << 5) | 24), (B[U++] = o))
            : o < 65536
              ? ((B[U++] = (s << 5) | 25), (B[U++] = o >> 8), (B[U++] = o))
              : o < 4294967296
                ? ((B[U++] = (s << 5) | 26), Bt.setUint32(U, o), (U += 4))
                : ((B[U++] = (s << 5) | 27),
                  Bt.setBigUint64(U, BigInt(o)),
                  (U += 8));
        continue;
      }
      ((B[U++] = 251), Bt.setFloat64(U, r), (U += 8));
      continue;
    } else if (typeof r == "bigint") {
      let n = r >= 0,
        s = n ? 0 : 1,
        o = n ? r : -r - BigInt(1),
        i = Number(o);
      if (i < 24) B[U++] = (s << 5) | i;
      else if (i < 256) ((B[U++] = (s << 5) | 24), (B[U++] = i));
      else if (i < 65536)
        ((B[U++] = (s << 5) | 25), (B[U++] = i >> 8), (B[U++] = i & 255));
      else if (i < 4294967296)
        ((B[U++] = (s << 5) | 26), Bt.setUint32(U, i), (U += 4));
      else if (o < BigInt("18446744073709551616"))
        ((B[U++] = (s << 5) | 27), Bt.setBigUint64(U, o), (U += 8));
      else {
        let a = o.toString(2),
          d = new Uint8Array(Math.ceil(a.length / 8)),
          l = o,
          p = 0;
        for (; d.byteLength - ++p >= 0; )
          ((d[d.byteLength - p] = Number(l & BigInt(255))), (l >>= BigInt(8)));
        (vf(d.byteLength * 2),
          (B[U++] = n ? 194 : 195),
          jE ? jt(2, Buffer.byteLength(d)) : jt(2, d.byteLength),
          B.set(d, U),
          (U += d.byteLength));
      }
      continue;
    } else if (r === null) {
      B[U++] = 246;
      continue;
    } else if (typeof r == "boolean") {
      B[U++] = 224 | (r ? 21 : 20);
      continue;
    } else {
      if (typeof r > "u")
        throw new Error(
          "@smithy/core/cbor: client may not serialize undefined value.",
        );
      if (Array.isArray(r)) {
        for (let n = r.length - 1; n >= 0; --n) t.push(r[n]);
        jt(4, r.length);
        continue;
      } else if (typeof r.byteLength == "number") {
        (vf(r.length * 2), jt(2, r.length), B.set(r, U), (U += r.byteLength));
        continue;
      } else if (typeof r == "object") {
        if (r instanceof Ee) {
          let s = r.string.indexOf("."),
            o = s === -1 ? 0 : s - r.string.length + 1,
            i = BigInt(r.string.replace(".", ""));
          ((B[U++] = 196), t.push(i), t.push(o), jt(4, 2));
          continue;
        }
        if (r[hf])
          if ("tag" in r && "value" in r) {
            (t.push(r.value), jt(6, r.tag));
            continue;
          } else
            throw new Error(
              "tag encountered with missing fields, need 'tag' and 'value', found: " +
                JSON.stringify(r),
            );
        let n = Object.keys(r);
        for (let s = n.length - 1; s >= 0; --s) {
          let o = n[s];
          (t.push(r[o]), t.push(o));
        }
        jt(5, n.length);
        continue;
      }
    }
    throw new Error(
      `data type ${r?.constructor?.name ?? typeof r} not compatible for encoding.`,
    );
  }
}
var BE,
  jE,
  iO,
  B,
  Bt,
  U,
  VE = b(() => {
    Ke();
    BE = v(Oe());
    Ki();
    ((jE = typeof Buffer < "u"),
      (iO = 2048),
      (B = hr(iO)),
      (Bt = new DataView(B.buffer, B.byteOffset, B.byteLength)),
      (U = 0));
  });
var Cf,
  GE = b(() => {
    zE();
    VE();
    Cf = {
      deserialize(e) {
        return ($E(e), vt(0, e.length));
      },
      serialize(e) {
        try {
          return (qE(e), Tf());
        } catch (t) {
          throw (Tf(), t);
        }
      },
      resizeEncodingBuffer(e) {
        Yi(e);
      },
    };
  });
var Xi,
  Qi,
  Zi = b(() => {
    Ki();
    ((Xi = (e) => Wi({ tag: 1, value: e.getTime() / 1e3 })),
      (Qi = (e, t) => {
        let r = (s) => {
          let o = s;
          return (
            typeof o == "number" && (o = o.toString()),
            o.indexOf(",") >= 0 && (o = o.split(",")[0]),
            o.indexOf(":") >= 0 && (o = o.split(":")[0]),
            o.indexOf("#") >= 0 && (o = o.split("#")[1]),
            o
          );
        };
        if (t.__type !== void 0) return r(t.__type);
        let n = Object.keys(t).find((s) => s.toLowerCase() === "code");
        if (n && t[n] !== void 0) return r(t[n]);
      }));
  });
var Rf,
  ea,
  If,
  Af,
  Nf = b(() => {
    we();
    Ke();
    Rf = v(De());
    GE();
    Zi();
    ((ea = class {
      serdeContext;
      createSerializer() {
        let t = new If();
        return (t.setSerdeContext(this.serdeContext), t);
      }
      createDeserializer() {
        let t = new Af();
        return (t.setSerdeContext(this.serdeContext), t);
      }
      setSerdeContext(t) {
        this.serdeContext = t;
      }
    }),
      (If = class {
        serdeContext;
        value;
        setSerdeContext(t) {
          this.serdeContext = t;
        }
        write(t, r) {
          this.value = this.serialize(t, r);
        }
        serialize(t, r) {
          let n = L.of(t);
          if (r == null) return n.isIdempotencyToken() ? (0, xt.v4)() : r;
          if (n.isBlobSchema())
            return typeof r == "string"
              ? (this.serdeContext?.base64Decoder ?? Rf.fromBase64)(r)
              : r;
          if (n.isTimestampSchema())
            return typeof r == "number" || typeof r == "bigint"
              ? Xi(new Date((Number(r) / 1e3) | 0))
              : Xi(r);
          if (typeof r == "function" || typeof r == "object") {
            let s = r;
            if (n.isListSchema() && Array.isArray(s)) {
              let i = !!n.getMergedTraits().sparse,
                a = [],
                d = 0;
              for (let l of s) {
                let p = this.serialize(n.getValueSchema(), l);
                (p != null || i) && (a[d++] = p);
              }
              return a;
            }
            if (s instanceof Date) return Xi(s);
            let o = {};
            if (n.isMapSchema()) {
              let i = !!n.getMergedTraits().sparse;
              for (let a of Object.keys(s)) {
                let d = this.serialize(n.getValueSchema(), s[a]);
                (d != null || i) && (o[a] = d);
              }
            } else if (n.isStructSchema())
              for (let [i, a] of n.structIterator()) {
                let d = this.serialize(a, s[i]);
                d != null && (o[i] = d);
              }
            else if (n.isDocumentSchema())
              for (let i of Object.keys(s))
                o[i] = this.serialize(n.getValueSchema(), s[i]);
            return o;
          }
          return r;
        }
        flush() {
          let t = Cf.serialize(this.value);
          return ((this.value = void 0), t);
        }
      }),
      (Af = class {
        serdeContext;
        setSerdeContext(t) {
          this.serdeContext = t;
        }
        read(t, r) {
          let n = Cf.deserialize(r);
          return this.readValue(t, n);
        }
        readValue(t, r) {
          let n = L.of(t);
          if (n.isTimestampSchema() && typeof r == "number") return Ts(r);
          if (n.isBlobSchema())
            return typeof r == "string"
              ? (this.serdeContext?.base64Decoder ?? Rf.fromBase64)(r)
              : r;
          if (
            typeof r > "u" ||
            typeof r == "boolean" ||
            typeof r == "number" ||
            typeof r == "string" ||
            typeof r == "bigint" ||
            typeof r == "symbol"
          )
            return r;
          if (typeof r == "function" || typeof r == "object") {
            if (r === null) return null;
            if ("byteLength" in r || r instanceof Date || n.isDocumentSchema())
              return r;
            if (n.isListSchema()) {
              let o = [],
                i = n.getValueSchema(),
                a = !!n.getMergedTraits().sparse;
              for (let d of r) {
                let l = this.readValue(i, d);
                (l != null || a) && o.push(l);
              }
              return o;
            }
            let s = {};
            if (n.isMapSchema()) {
              let o = !!n.getMergedTraits().sparse,
                i = n.getValueSchema();
              for (let a of Object.keys(r)) {
                let d = this.readValue(i, r[a]);
                (d != null || o) && (s[a] = d);
              }
            } else if (n.isStructSchema())
              for (let [o, i] of n.structIterator())
                s[o] = this.readValue(i, r[o]);
            return s;
          } else return r;
        }
      }));
  });
var WE,
  ta,
  KE = b(() => {
    et();
    we();
    WE = v(Ge());
    Nf();
    Zi();
    ta = class extends Lt {
      codec = new ea();
      serializer = this.codec.createSerializer();
      deserializer = this.codec.createDeserializer();
      constructor({ defaultNamespace: t }) {
        super({ defaultNamespace: t });
      }
      getShapeId() {
        return "smithy.protocols#rpcv2Cbor";
      }
      getPayloadCodec() {
        return this.codec;
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n);
        if (
          (Object.assign(s.headers, {
            "content-type": this.getDefaultContentType(),
            "smithy-protocol": "rpc-v2-cbor",
            accept: this.getDefaultContentType(),
          }),
          ot(t.input) === "unit")
        )
          (delete s.body, delete s.headers["content-type"]);
        else {
          s.body ||
            (this.serializer.write(15, {}), (s.body = this.serializer.flush()));
          try {
            s.headers["content-length"] = String(s.body.byteLength);
          } catch {}
        }
        let { service: o, operation: i } = (0, WE.getSmithyContext)(n),
          a = `/service/${o}/operation/${i}`;
        return (
          s.path.endsWith("/") ? (s.path += a.slice(1)) : (s.path += a),
          s
        );
      }
      async deserializeResponse(t, r, n) {
        return super.deserializeResponse(t, r, n);
      }
      async handleError(t, r, n, s, o) {
        let i = Qi(n, s) ?? "Unknown",
          a = this.options.defaultNamespace;
        i.includes("#") && ([a] = i.split("#"));
        let d = {
            $metadata: o,
            $response: n,
            $fault: n.statusCode <= 500 ? "client" : "server",
          },
          l = Te.for(a),
          p;
        try {
          p = l.getSchema(i);
        } catch {
          s.Message && (s.message = s.Message);
          let R = Te.for("smithy.ts.sdk.synthetic." + a),
            O = R.getBaseException();
          if (O) {
            let $ = R.getErrorCtor(O);
            throw Object.assign(new $({ name: i }), d, s);
          }
          throw Object.assign(new Error(i), d, s);
        }
        let m = L.of(p),
          g = l.getErrorCtor(p),
          h = s.message ?? s.Message ?? "Unknown",
          E = new g(h),
          C = {};
        for (let [I, R] of m.structIterator())
          C[I] = this.deserializer.readValue(R, s[I]);
        throw Object.assign(
          E,
          d,
          { $fault: m.getMergedTraits().error, message: h },
          C,
        );
      }
      getDefaultContentType() {
        return "application/cbor";
      }
    };
  });
var JE = b(() => {
  Zi();
  KE();
  Nf();
});
var it,
  Mn = b(() => {
    we();
    it = class {
      resolveRestContentType(t, r) {
        let n = r.getMemberSchemas(),
          s = Object.values(n).find((o) => !!o.getMergedTraits().httpPayload);
        if (s) {
          let o = s.getMergedTraits().mediaType;
          return (
            o ||
            (s.isStringSchema()
              ? "text/plain"
              : s.isBlobSchema()
                ? "application/octet-stream"
                : t)
          );
        } else if (
          !r.isUnitSchema() &&
          Object.values(n).find((i) => {
            let {
              httpQuery: a,
              httpQueryParams: d,
              httpHeader: l,
              httpLabel: p,
              httpPrefixHeaders: m,
            } = i.getMergedTraits();
            return !a && !d && !l && !p && m === void 0;
          })
        )
          return t;
      }
      async getErrorSchemaOrThrowBaseException(t, r, n, s, o, i) {
        let a = r,
          d = t;
        t.includes("#") && ([a, d] = t.split("#"));
        let l = {
            $metadata: o,
            $response: n,
            $fault: n.statusCode < 500 ? "client" : "server",
          },
          p = Te.for(a);
        try {
          return { errorSchema: i?.(p, d) ?? p.getSchema(t), errorMetadata: l };
        } catch {
          s.message = s.message ?? s.Message ?? "UnknownError";
          let g = Te.for("smithy.ts.sdk.synthetic." + a),
            h = g.getBaseException();
          if (h) {
            let E = g.getErrorCtor(h) ?? Error;
            throw Object.assign(new E({ name: d }), l, s);
          }
          throw Object.assign(new Error(d), l, s);
        }
      }
      setQueryCompatError(t, r) {
        let n = r.headers?.["x-amzn-query-error"];
        if (t !== void 0 && n != null) {
          let [s, o] = n.split(";"),
            i = Object.entries(t),
            a = { Code: s, Type: o };
          Object.assign(t, a);
          for (let [d, l] of i) a[d] = l;
          (delete a.__type, (t.Error = a));
        }
      }
      queryCompatOutput(t, r) {
        (t.Error && (r.Error = t.Error),
          t.Type && (r.Type = t.Type),
          t.Code && (r.Code = t.Code));
      }
    };
  });
var Pf,
  YE = b(() => {
    JE();
    we();
    Mn();
    Pf = class extends ta {
      awsQueryCompatible;
      mixin = new it();
      constructor({ defaultNamespace: t, awsQueryCompatible: r }) {
        (super({ defaultNamespace: t }), (this.awsQueryCompatible = !!r));
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n);
        return (
          this.awsQueryCompatible && (s.headers["x-amzn-query-mode"] = "true"),
          s
        );
      }
      async handleError(t, r, n, s, o) {
        this.awsQueryCompatible && this.mixin.setQueryCompatError(s, n);
        let i = Qi(n, s) ?? "Unknown",
          { errorSchema: a, errorMetadata: d } =
            await this.mixin.getErrorSchemaOrThrowBaseException(
              i,
              this.options.defaultNamespace,
              n,
              s,
              o,
            ),
          l = L.of(a),
          p = s.message ?? s.Message ?? "Unknown",
          m = Te.for(a.namespace).getErrorCtor(a) ?? Error,
          g = new m(p),
          h = {};
        for (let [E, C] of l.structIterator())
          h[E] = this.deserializer.readValue(C, s[E]);
        throw (
          this.awsQueryCompatible && this.mixin.queryCompatOutput(s, h),
          Object.assign(
            g,
            d,
            { $fault: l.getMergedTraits().error, message: p },
            h,
          )
        );
      }
    };
  });
var aO,
  cO,
  dO,
  XE = b(() => {
    ((aO = (e) => {
      if (e == null) return e;
      if (typeof e == "number" || typeof e == "bigint") {
        let t = new Error(`Received number ${e} where a string was expected.`);
        return ((t.name = "Warning"), console.warn(t), String(e));
      }
      if (typeof e == "boolean") {
        let t = new Error(`Received boolean ${e} where a string was expected.`);
        return ((t.name = "Warning"), console.warn(t), String(e));
      }
      return e;
    }),
      (cO = (e) => {
        if (e == null) return e;
        if (typeof e == "string") {
          let t = e.toLowerCase();
          if (e !== "" && t !== "false" && t !== "true") {
            let r = new Error(
              `Received string "${e}" where a boolean was expected.`,
            );
            ((r.name = "Warning"), console.warn(r));
          }
          return e !== "" && t !== "false";
        }
        return e;
      }),
      (dO = (e) => {
        if (e == null) return e;
        if (typeof e == "string") {
          let t = Number(e);
          if (t.toString() !== e) {
            let r = new Error(
              `Received string "${e}" where a number was expected.`,
            );
            return ((r.name = "Warning"), console.warn(r), e);
          }
          return t;
        }
        return e;
      }));
  });
var He,
  Er = b(() => {
    He = class {
      serdeContext;
      setSerdeContext(t) {
        this.serdeContext = t;
      }
    };
  });
function QE(e, t, r) {
  if (r?.source) {
    let n = r.source;
    if (
      typeof t == "number" &&
      (t > Number.MAX_SAFE_INTEGER ||
        t < Number.MIN_SAFE_INTEGER ||
        n !== String(t))
    )
      return n.includes(".") ? new Ee(n, "bigDecimal") : BigInt(n);
  }
  return t;
}
var ZE = b(() => {
  Ke();
});
var n_ = P((r_) => {
  "use strict";
  var Zr = (e, t) => {
      let r = [];
      if ((e && r.push(e), t)) for (let n of t) r.push(n);
      return r;
    },
    _r = (e, t) =>
      `${e || "anonymous"}${t && t.length > 0 ? ` (a.k.a. ${t.join(",")})` : ""}`,
    Of = () => {
      let e = [],
        t = [],
        r = !1,
        n = new Set(),
        s = (m) =>
          m.sort(
            (g, h) =>
              e_[h.step] - e_[g.step] ||
              t_[h.priority || "normal"] - t_[g.priority || "normal"],
          ),
        o = (m) => {
          let g = !1,
            h = (E) => {
              let C = Zr(E.name, E.aliases);
              if (C.includes(m)) {
                g = !0;
                for (let I of C) n.delete(I);
                return !1;
              }
              return !0;
            };
          return ((e = e.filter(h)), (t = t.filter(h)), g);
        },
        i = (m) => {
          let g = !1,
            h = (E) => {
              if (E.middleware === m) {
                g = !0;
                for (let C of Zr(E.name, E.aliases)) n.delete(C);
                return !1;
              }
              return !0;
            };
          return ((e = e.filter(h)), (t = t.filter(h)), g);
        },
        a = (m) => (
          e.forEach((g) => {
            m.add(g.middleware, { ...g });
          }),
          t.forEach((g) => {
            m.addRelativeTo(g.middleware, { ...g });
          }),
          m.identifyOnResolve?.(p.identifyOnResolve()),
          m
        ),
        d = (m) => {
          let g = [];
          return (
            m.before.forEach((h) => {
              h.before.length === 0 && h.after.length === 0
                ? g.push(h)
                : g.push(...d(h));
            }),
            g.push(m),
            m.after.reverse().forEach((h) => {
              h.before.length === 0 && h.after.length === 0
                ? g.push(h)
                : g.push(...d(h));
            }),
            g
          );
        },
        l = (m = !1) => {
          let g = [],
            h = [],
            E = {};
          return (
            e.forEach((I) => {
              let R = { ...I, before: [], after: [] };
              for (let O of Zr(R.name, R.aliases)) E[O] = R;
              g.push(R);
            }),
            t.forEach((I) => {
              let R = { ...I, before: [], after: [] };
              for (let O of Zr(R.name, R.aliases)) E[O] = R;
              h.push(R);
            }),
            h.forEach((I) => {
              if (I.toMiddleware) {
                let R = E[I.toMiddleware];
                if (R === void 0) {
                  if (m) return;
                  throw new Error(
                    `${I.toMiddleware} is not found when adding ${_r(I.name, I.aliases)} middleware ${I.relation} ${I.toMiddleware}`,
                  );
                }
                (I.relation === "after" && R.after.push(I),
                  I.relation === "before" && R.before.push(I));
              }
            }),
            s(g)
              .map(d)
              .reduce((I, R) => (I.push(...R), I), [])
          );
        },
        p = {
          add: (m, g = {}) => {
            let { name: h, override: E, aliases: C } = g,
              I = {
                step: "initialize",
                priority: "normal",
                middleware: m,
                ...g,
              },
              R = Zr(h, C);
            if (R.length > 0) {
              if (R.some((O) => n.has(O))) {
                if (!E)
                  throw new Error(`Duplicate middleware name '${_r(h, C)}'`);
                for (let O of R) {
                  let $ = e.findIndex(
                    (H) => H.name === O || H.aliases?.some((se) => se === O),
                  );
                  if ($ === -1) continue;
                  let j = e[$];
                  if (j.step !== I.step || I.priority !== j.priority)
                    throw new Error(
                      `"${_r(j.name, j.aliases)}" middleware with ${j.priority} priority in ${j.step} step cannot be overridden by "${_r(h, C)}" middleware with ${I.priority} priority in ${I.step} step.`,
                    );
                  e.splice($, 1);
                }
              }
              for (let O of R) n.add(O);
            }
            e.push(I);
          },
          addRelativeTo: (m, g) => {
            let { name: h, override: E, aliases: C } = g,
              I = { middleware: m, ...g },
              R = Zr(h, C);
            if (R.length > 0) {
              if (R.some((O) => n.has(O))) {
                if (!E)
                  throw new Error(`Duplicate middleware name '${_r(h, C)}'`);
                for (let O of R) {
                  let $ = t.findIndex(
                    (H) => H.name === O || H.aliases?.some((se) => se === O),
                  );
                  if ($ === -1) continue;
                  let j = t[$];
                  if (
                    j.toMiddleware !== I.toMiddleware ||
                    j.relation !== I.relation
                  )
                    throw new Error(
                      `"${_r(j.name, j.aliases)}" middleware ${j.relation} "${j.toMiddleware}" middleware cannot be overridden by "${_r(h, C)}" middleware ${I.relation} "${I.toMiddleware}" middleware.`,
                    );
                  t.splice($, 1);
                }
              }
              for (let O of R) n.add(O);
            }
            t.push(I);
          },
          clone: () => a(Of()),
          use: (m) => {
            m.applyToStack(p);
          },
          remove: (m) => (typeof m == "string" ? o(m) : i(m)),
          removeByTag: (m) => {
            let g = !1,
              h = (E) => {
                let { tags: C, name: I, aliases: R } = E;
                if (C && C.includes(m)) {
                  let O = Zr(I, R);
                  for (let $ of O) n.delete($);
                  return ((g = !0), !1);
                }
                return !0;
              };
            return ((e = e.filter(h)), (t = t.filter(h)), g);
          },
          concat: (m) => {
            let g = a(Of());
            return (
              g.use(m),
              g.identifyOnResolve(
                r || g.identifyOnResolve() || (m.identifyOnResolve?.() ?? !1),
              ),
              g
            );
          },
          applyToStack: a,
          identify: () =>
            l(!0).map((m) => {
              let g = m.step ?? m.relation + " " + m.toMiddleware;
              return _r(m.name, m.aliases) + " - " + g;
            }),
          identifyOnResolve(m) {
            return (typeof m == "boolean" && (r = m), r);
          },
          resolve: (m, g) => {
            for (let h of l()
              .map((E) => E.middleware)
              .reverse())
              m = h(m, g);
            return (r && console.log(p.identify()), m);
          },
        };
      return p;
    },
    e_ = {
      initialize: 5,
      serialize: 4,
      build: 3,
      finalizeRequest: 2,
      deserialize: 1,
    },
    t_ = { high: 3, normal: 2, low: 1 };
  r_.constructStack = Of;
});
var Y = P((le) => {
  "use strict";
  var i_ = n_(),
    zf = (et(), ce(iy)),
    Mf = rr(),
    lO = (we(), ce(Qg)),
    s_ = (Ke(), ce(VS)),
    kf = class {
      config;
      middlewareStack = i_.constructStack();
      initConfig;
      handlers;
      constructor(t) {
        this.config = t;
      }
      send(t, r, n) {
        let s = typeof r != "function" ? r : void 0,
          o = typeof r == "function" ? r : n,
          i = s === void 0 && this.config.cacheMiddleware === !0,
          a;
        if (i) {
          this.handlers || (this.handlers = new WeakMap());
          let d = this.handlers;
          d.has(t.constructor)
            ? (a = d.get(t.constructor))
            : ((a = t.resolveMiddleware(this.middlewareStack, this.config, s)),
              d.set(t.constructor, a));
        } else
          (delete this.handlers,
            (a = t.resolveMiddleware(this.middlewareStack, this.config, s)));
        if (o)
          a(t)
            .then(
              (d) => o(null, d.output),
              (d) => o(d),
            )
            .catch(() => {});
        else return a(t).then((d) => d.output);
      }
      destroy() {
        (this.config?.requestHandler?.destroy?.(), delete this.handlers);
      }
    },
    Df = "***SensitiveInformation***";
  function Ff(e, t) {
    if (t == null) return t;
    let r = lO.NormalizedSchema.of(e);
    if (r.getMergedTraits().sensitive) return Df;
    if (r.isListSchema()) {
      if (!!r.getValueSchema().getMergedTraits().sensitive) return Df;
    } else if (r.isMapSchema()) {
      if (
        !!r.getKeySchema().getMergedTraits().sensitive ||
        !!r.getValueSchema().getMergedTraits().sensitive
      )
        return Df;
    } else if (r.isStructSchema() && typeof t == "object") {
      let n = t,
        s = {};
      for (let [o, i] of r.structIterator())
        n[o] != null && (s[o] = Ff(i, n[o]));
      return s;
    }
    return t;
  }
  var ra = class {
      middlewareStack = i_.constructStack();
      schema;
      static classBuilder() {
        return new Lf();
      }
      resolveMiddlewareWithContext(
        t,
        r,
        n,
        {
          middlewareFn: s,
          clientName: o,
          commandName: i,
          inputFilterSensitiveLog: a,
          outputFilterSensitiveLog: d,
          smithyContext: l,
          additionalContext: p,
          CommandCtor: m,
        },
      ) {
        for (let I of s.bind(this)(m, t, r, n)) this.middlewareStack.use(I);
        let g = t.concat(this.middlewareStack),
          { logger: h } = r,
          E = {
            logger: h,
            clientName: o,
            commandName: i,
            inputFilterSensitiveLog: a,
            outputFilterSensitiveLog: d,
            [Mf.SMITHY_CONTEXT_KEY]: { commandInstance: this, ...l },
            ...p,
          },
          { requestHandler: C } = r;
        return g.resolve((I) => C.handle(I.request, n || {}), E);
      }
    },
    Lf = class {
      _init = () => {};
      _ep = {};
      _middlewareFn = () => [];
      _commandName = "";
      _clientName = "";
      _additionalContext = {};
      _smithyContext = {};
      _inputFilterSensitiveLog = void 0;
      _outputFilterSensitiveLog = void 0;
      _serializer = null;
      _deserializer = null;
      _operationSchema;
      init(t) {
        this._init = t;
      }
      ep(t) {
        return ((this._ep = t), this);
      }
      m(t) {
        return ((this._middlewareFn = t), this);
      }
      s(t, r, n = {}) {
        return (
          (this._smithyContext = { service: t, operation: r, ...n }),
          this
        );
      }
      c(t = {}) {
        return ((this._additionalContext = t), this);
      }
      n(t, r) {
        return ((this._clientName = t), (this._commandName = r), this);
      }
      f(t = (n) => n, r = (n) => n) {
        return (
          (this._inputFilterSensitiveLog = t),
          (this._outputFilterSensitiveLog = r),
          this
        );
      }
      ser(t) {
        return ((this._serializer = t), this);
      }
      de(t) {
        return ((this._deserializer = t), this);
      }
      sc(t) {
        return (
          (this._operationSchema = t),
          (this._smithyContext.operationSchema = t),
          this
        );
      }
      build() {
        let t = this,
          r;
        return (r = class extends ra {
          input;
          static getEndpointParameterInstructions() {
            return t._ep;
          }
          constructor(...[n]) {
            (super(),
              (this.input = n ?? {}),
              t._init(this),
              (this.schema = t._operationSchema));
          }
          resolveMiddleware(n, s, o) {
            return this.resolveMiddlewareWithContext(n, s, o, {
              CommandCtor: r,
              middlewareFn: t._middlewareFn,
              clientName: t._clientName,
              commandName: t._commandName,
              inputFilterSensitiveLog:
                t._inputFilterSensitiveLog ??
                (t._operationSchema
                  ? Ff.bind(null, t._operationSchema.input)
                  : (i) => i),
              outputFilterSensitiveLog:
                t._outputFilterSensitiveLog ??
                (t._operationSchema
                  ? Ff.bind(null, t._operationSchema.output)
                  : (i) => i),
              smithyContext: t._smithyContext,
              additionalContext: t._additionalContext,
            });
          }
          serialize = t._serializer;
          deserialize = t._deserializer;
        });
      }
    },
    uO = "***SensitiveInformation***",
    fO = (e, t) => {
      for (let r of Object.keys(e)) {
        let n = e[r],
          s = async function (i, a, d) {
            let l = new n(i);
            if (typeof a == "function") this.send(l, a);
            else if (typeof d == "function") {
              if (typeof a != "object")
                throw new Error(`Expected http options but got ${typeof a}`);
              this.send(l, a || {}, d);
            } else return this.send(l, a);
          },
          o = (r[0].toLowerCase() + r.slice(1)).replace(/Command$/, "");
        t.prototype[o] = s;
      }
    },
    $f = class e extends Error {
      $fault;
      $response;
      $retryable;
      $metadata;
      constructor(t) {
        (super(t.message),
          Object.setPrototypeOf(
            this,
            Object.getPrototypeOf(this).constructor.prototype,
          ),
          (this.name = t.name),
          (this.$fault = t.$fault),
          (this.$metadata = t.$metadata));
      }
      static isInstance(t) {
        if (!t) return !1;
        let r = t;
        return (
          e.prototype.isPrototypeOf(r) ||
          (!!r.$fault &&
            !!r.$metadata &&
            (r.$fault === "client" || r.$fault === "server"))
        );
      }
      static [Symbol.hasInstance](t) {
        if (!t) return !1;
        let r = t;
        return this === e
          ? e.isInstance(t)
          : e.isInstance(t)
            ? r.name && this.name
              ? this.prototype.isPrototypeOf(t) || r.name === this.name
              : this.prototype.isPrototypeOf(t)
            : !1;
      }
    },
    a_ = (e, t = {}) => {
      Object.entries(t)
        .filter(([, n]) => n !== void 0)
        .forEach(([n, s]) => {
          (e[n] == null || e[n] === "") && (e[n] = s);
        });
      let r = e.message || e.Message || "UnknownError";
      return ((e.message = r), delete e.Message, e);
    },
    c_ = ({ output: e, parsedBody: t, exceptionCtor: r, errorCode: n }) => {
      let s = mO(e),
        o = s.httpStatusCode ? s.httpStatusCode + "" : void 0,
        i = new r({
          name: t?.code || t?.Code || n || o || "UnknownError",
          $fault: "client",
          $metadata: s,
        });
      throw a_(i, t);
    },
    pO =
      (e) =>
      ({ output: t, parsedBody: r, errorCode: n }) => {
        c_({ output: t, parsedBody: r, exceptionCtor: e, errorCode: n });
      },
    mO = (e) => ({
      httpStatusCode: e.statusCode,
      requestId:
        e.headers["x-amzn-requestid"] ??
        e.headers["x-amzn-request-id"] ??
        e.headers["x-amz-request-id"],
      extendedRequestId: e.headers["x-amz-id-2"],
      cfId: e.headers["x-amz-cf-id"],
    }),
    hO = (e) => {
      switch (e) {
        case "standard":
          return { retryMode: "standard", connectionTimeout: 3100 };
        case "in-region":
          return { retryMode: "standard", connectionTimeout: 1100 };
        case "cross-region":
          return { retryMode: "standard", connectionTimeout: 3100 };
        case "mobile":
          return { retryMode: "standard", connectionTimeout: 3e4 };
        default:
          return {};
      }
    },
    o_ = !1,
    gO = (e) => {
      e && !o_ && parseInt(e.substring(1, e.indexOf("."))) < 16 && (o_ = !0);
    },
    SO = (e) => {
      let t = [];
      for (let r in Mf.AlgorithmId) {
        let n = Mf.AlgorithmId[r];
        e[n] !== void 0 &&
          t.push({ algorithmId: () => n, checksumConstructor: () => e[n] });
      }
      return {
        addChecksumAlgorithm(r) {
          t.push(r);
        },
        checksumAlgorithms() {
          return t;
        },
      };
    },
    yO = (e) => {
      let t = {};
      return (
        e.checksumAlgorithms().forEach((r) => {
          t[r.algorithmId()] = r.checksumConstructor();
        }),
        t
      );
    },
    EO = (e) => ({
      setRetryStrategy(t) {
        e.retryStrategy = t;
      },
      retryStrategy() {
        return e.retryStrategy;
      },
    }),
    _O = (e) => {
      let t = {};
      return ((t.retryStrategy = e.retryStrategy()), t);
    },
    d_ = (e) => Object.assign(SO(e), EO(e)),
    wO = d_,
    bO = (e) => Object.assign(yO(e), _O(e)),
    xO = (e) => (Array.isArray(e) ? e : [e]),
    l_ = (e) => {
      let t = "#text";
      for (let r in e)
        e.hasOwnProperty(r) && e[r][t] !== void 0
          ? (e[r] = e[r][t])
          : typeof e[r] == "object" && e[r] !== null && (e[r] = l_(e[r]));
      return e;
    },
    vO = (e) => e != null,
    Uf = class {
      trace() {}
      debug() {}
      info() {}
      warn() {}
      error() {}
    };
  function u_(e, t, r) {
    let n, s, o;
    if (typeof t > "u" && typeof r > "u") ((n = {}), (o = e));
    else {
      if (((n = e), typeof t == "function"))
        return ((s = t), (o = r), IO(n, s, o));
      o = t;
    }
    for (let i of Object.keys(o)) {
      if (!Array.isArray(o[i])) {
        n[i] = o[i];
        continue;
      }
      f_(n, null, o, i);
    }
    return n;
  }
  var TO = (e) => {
      let t = {};
      for (let [r, n] of Object.entries(e || {})) t[r] = [, n];
      return t;
    },
    CO = (e, t) => {
      let r = {};
      for (let n in t) f_(r, e, t, n);
      return r;
    },
    IO = (e, t, r) =>
      u_(
        e,
        Object.entries(r).reduce(
          (n, [s, o]) => (
            Array.isArray(o)
              ? (n[s] = o)
              : typeof o == "function"
                ? (n[s] = [t, o()])
                : (n[s] = [t, o]),
            n
          ),
          {},
        ),
      ),
    f_ = (e, t, r, n) => {
      if (t !== null) {
        let i = r[n];
        typeof i == "function" && (i = [, i]);
        let [a = AO, d = RO, l = n] = i;
        ((typeof a == "function" && a(t[l])) ||
          (typeof a != "function" && a)) &&
          (e[n] = d(t[l]));
        return;
      }
      let [s, o] = r[n];
      if (typeof o == "function") {
        let i,
          a = s === void 0 && (i = o()) != null,
          d =
            (typeof s == "function" && !!s(void 0)) ||
            (typeof s != "function" && !!s);
        a ? (e[n] = i) : d && (e[n] = o());
      } else {
        let i = s === void 0 && o != null,
          a =
            (typeof s == "function" && !!s(o)) ||
            (typeof s != "function" && !!s);
        (i || a) && (e[n] = o);
      }
    },
    AO = (e) => e != null,
    RO = (e) => e,
    NO = (e) => {
      if (e !== e) return "NaN";
      switch (e) {
        case 1 / 0:
          return "Infinity";
        case -1 / 0:
          return "-Infinity";
        default:
          return e;
      }
    },
    PO = (e) => e.toISOString().replace(".000Z", "Z"),
    Hf = (e) => {
      if (e == null) return {};
      if (Array.isArray(e)) return e.filter((t) => t != null).map(Hf);
      if (typeof e == "object") {
        let t = {};
        for (let r of Object.keys(e)) e[r] != null && (t[r] = Hf(e[r]));
        return t;
      }
      return e;
    };
  Object.defineProperty(le, "collectBody", {
    enumerable: !0,
    get: function () {
      return zf.collectBody;
    },
  });
  Object.defineProperty(le, "extendedEncodeURIComponent", {
    enumerable: !0,
    get: function () {
      return zf.extendedEncodeURIComponent;
    },
  });
  Object.defineProperty(le, "resolvedPath", {
    enumerable: !0,
    get: function () {
      return zf.resolvedPath;
    },
  });
  le.Client = kf;
  le.Command = ra;
  le.NoOpLogger = Uf;
  le.SENSITIVE_STRING = uO;
  le.ServiceException = $f;
  le._json = Hf;
  le.convertMap = TO;
  le.createAggregatedClient = fO;
  le.decorateServiceException = a_;
  le.emitWarningIfUnsupportedVersion = gO;
  le.getArrayIfSingleItem = xO;
  le.getDefaultClientConfiguration = wO;
  le.getDefaultExtensionConfiguration = d_;
  le.getValueFromTextNode = l_;
  le.isSerializableHeaderValue = vO;
  le.loadConfigsForDefaultMode = hO;
  le.map = u_;
  le.resolveDefaultRuntimeConfig = bO;
  le.serializeDateTime = PO;
  le.serializeFloat = NO;
  le.take = CO;
  le.throwDefaultError = c_;
  le.withBaseException = pO;
  Object.keys(s_).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(le, e) &&
      Object.defineProperty(le, e, {
        enumerable: !0,
        get: function () {
          return s_[e];
        },
      });
  });
});
var p_,
  m_,
  na,
  jf = b(() => {
    ((p_ = v(Y())),
      (m_ = v(Oe())),
      (na = (e, t) =>
        (0, p_.collectBody)(e, t).then((r) =>
          (t?.utf8Encoder ?? m_.toUtf8)(r),
        )));
  });
var kn,
  Bf,
  en,
  Fs = b(() => {
    jf();
    ((kn = (e, t) =>
      na(e, t).then((r) => {
        if (r.length)
          try {
            return JSON.parse(r);
          } catch (n) {
            throw (
              n?.name === "SyntaxError" &&
                Object.defineProperty(n, "$responseBodyText", { value: r }),
              n
            );
          }
        return {};
      })),
      (Bf = async (e, t) => {
        let r = await kn(e, t);
        return ((r.message = r.message ?? r.Message), r);
      }),
      (en = (e, t) => {
        let r = (o, i) =>
            Object.keys(o).find((a) => a.toLowerCase() === i.toLowerCase()),
          n = (o) => {
            let i = o;
            return (
              typeof i == "number" && (i = i.toString()),
              i.indexOf(",") >= 0 && (i = i.split(",")[0]),
              i.indexOf(":") >= 0 && (i = i.split(":")[0]),
              i.indexOf("#") >= 0 && (i = i.split("#")[1]),
              i
            );
          },
          s = r(e.headers, "x-amzn-errortype");
        if (s !== void 0) return n(e.headers[s]);
        if (t && typeof t == "object") {
          let o = r(t, "code");
          if (o && t[o] !== void 0) return n(t[o]);
          if (t.__type !== void 0) return n(t.__type);
        }
      }));
  });
var h_,
  Ls,
  qf = b(() => {
    et();
    we();
    Ke();
    h_ = v(De());
    Er();
    ZE();
    Fs();
    Ls = class extends He {
      settings;
      constructor(t) {
        (super(), (this.settings = t));
      }
      async read(t, r) {
        return this._read(
          t,
          typeof r == "string"
            ? JSON.parse(r, QE)
            : await kn(r, this.serdeContext),
        );
      }
      readObject(t, r) {
        return this._read(t, r);
      }
      _read(t, r) {
        let n = r !== null && typeof r == "object",
          s = L.of(t);
        if (s.isListSchema() && Array.isArray(r)) {
          let i = s.getValueSchema(),
            a = [],
            d = !!s.getMergedTraits().sparse;
          for (let l of r) (d || l != null) && a.push(this._read(i, l));
          return a;
        } else if (s.isMapSchema() && n) {
          let i = s.getValueSchema(),
            a = {},
            d = !!s.getMergedTraits().sparse;
          for (let [l, p] of Object.entries(r))
            (d || p != null) && (a[l] = this._read(i, p));
          return a;
        } else if (s.isStructSchema() && n) {
          let i = {};
          for (let [a, d] of s.structIterator()) {
            let l = this.settings.jsonName
                ? (d.getMergedTraits().jsonName ?? a)
                : a,
              p = this._read(d, r[l]);
            p != null && (i[a] = p);
          }
          return i;
        }
        if (s.isBlobSchema() && typeof r == "string")
          return (0, h_.fromBase64)(r);
        let o = s.getMergedTraits().mediaType;
        if (
          s.isStringSchema() &&
          typeof r == "string" &&
          o &&
          (o === "application/json" || o.endsWith("+json"))
        )
          return Be.from(r);
        if (s.isTimestampSchema() && r != null)
          switch (Ze(s, this.settings)) {
            case 5:
              return fu(r);
            case 6:
              return pu(r);
            case 7:
              return mu(r);
            default:
              return (
                console.warn(
                  "Missing timestamp format, parsing value with Date constructor:",
                  r,
                ),
                new Date(r)
              );
          }
        if (
          s.isBigIntegerSchema() &&
          (typeof r == "number" || typeof r == "string")
        )
          return BigInt(r);
        if (s.isBigDecimalSchema() && r != null) {
          if (r instanceof Ee) return r;
          let i = r;
          return i.type === "bigDecimal" && "string" in i
            ? new Ee(i.string, i.type)
            : new Ee(String(r), "bigDecimal");
        }
        if (s.isNumericSchema() && typeof r == "string")
          switch (r) {
            case "Infinity":
              return 1 / 0;
            case "-Infinity":
              return -1 / 0;
            case "NaN":
              return NaN;
          }
        if (s.isDocumentSchema())
          if (n) {
            let i = Array.isArray(r) ? [] : {};
            for (let [a, d] of Object.entries(r))
              d instanceof Ee ? (i[a] = d) : (i[a] = this._read(s, d));
            return i;
          } else return structuredClone(r);
        return r;
      }
    };
  });
var g_,
  sa,
  S_ = b(() => {
    Ke();
    ((g_ = "\u039D"),
      (sa = class {
        values = new Map();
        counter = 0;
        stage = 0;
        createReplacer() {
          if (this.stage === 1)
            throw new Error(
              "@aws-sdk/core/protocols - JsonReplacer already created.",
            );
          if (this.stage === 2)
            throw new Error(
              "@aws-sdk/core/protocols - JsonReplacer exhausted.",
            );
          return (
            (this.stage = 1),
            (t, r) => {
              if (r instanceof Ee) {
                let n = `${g_ + "nv" + this.counter++}_` + r.string;
                return (this.values.set(`"${n}"`, r.string), n);
              }
              if (typeof r == "bigint") {
                let n = r.toString(),
                  s = `${g_ + "b" + this.counter++}_` + n;
                return (this.values.set(`"${s}"`, n), s);
              }
              return r;
            }
          );
        }
        replaceInJson(t) {
          if (this.stage === 0)
            throw new Error(
              "@aws-sdk/core/protocols - JsonReplacer not created yet.",
            );
          if (this.stage === 2)
            throw new Error(
              "@aws-sdk/core/protocols - JsonReplacer exhausted.",
            );
          if (((this.stage = 2), this.counter === 0)) return t;
          for (let [r, n] of this.values) t = t.replace(r, n);
          return t;
        }
      }));
  });
var y_,
  $s,
  Vf = b(() => {
    et();
    we();
    Ke();
    y_ = v(De());
    Er();
    S_();
    $s = class extends He {
      settings;
      buffer;
      rootSchema;
      constructor(t) {
        (super(), (this.settings = t));
      }
      write(t, r) {
        ((this.rootSchema = L.of(t)),
          (this.buffer = this._write(this.rootSchema, r)));
      }
      writeDiscriminatedDocument(t, r) {
        (this.write(t, r),
          typeof this.buffer == "object" &&
            (this.buffer.__type = L.of(t).getName(!0)));
      }
      flush() {
        let { rootSchema: t } = this;
        if (
          ((this.rootSchema = void 0),
          t?.isStructSchema() || t?.isDocumentSchema())
        ) {
          let r = new sa();
          return r.replaceInJson(
            JSON.stringify(this.buffer, r.createReplacer(), 0),
          );
        }
        return this.buffer;
      }
      _write(t, r, n) {
        let s = r !== null && typeof r == "object",
          o = L.of(t);
        if (o.isListSchema() && Array.isArray(r)) {
          let i = o.getValueSchema(),
            a = [],
            d = !!o.getMergedTraits().sparse;
          for (let l of r) (d || l != null) && a.push(this._write(i, l));
          return a;
        } else if (o.isMapSchema() && s) {
          let i = o.getValueSchema(),
            a = {},
            d = !!o.getMergedTraits().sparse;
          for (let [l, p] of Object.entries(r))
            (d || p != null) && (a[l] = this._write(i, p));
          return a;
        } else if (o.isStructSchema() && s) {
          let i = {};
          for (let [a, d] of o.structIterator()) {
            let l = this.settings.jsonName
                ? (d.getMergedTraits().jsonName ?? a)
                : a,
              p = this._write(d, r[a], o);
            p !== void 0 && (i[l] = p);
          }
          return i;
        }
        if (!(r === null && n?.isStructSchema())) {
          if (
            (o.isBlobSchema() &&
              (r instanceof Uint8Array || typeof r == "string")) ||
            (o.isDocumentSchema() && r instanceof Uint8Array)
          )
            return o === this.rootSchema
              ? r
              : this.serdeContext?.base64Encoder
                ? this.serdeContext?.base64Encoder(r)
                : (0, y_.toBase64)(r);
          if (
            (o.isTimestampSchema() || o.isDocumentSchema()) &&
            r instanceof Date
          )
            switch (Ze(o, this.settings)) {
              case 5:
                return r.toISOString().replace(".000Z", "Z");
              case 6:
                return bs(r);
              case 7:
                return r.getTime() / 1e3;
              default:
                return (
                  console.warn(
                    "Missing timestamp format, using epoch seconds",
                    r,
                  ),
                  r.getTime() / 1e3
                );
            }
          if (
            o.isNumericSchema() &&
            typeof r == "number" &&
            (Math.abs(r) === 1 / 0 || isNaN(r))
          )
            return String(r);
          if (o.isStringSchema()) {
            if (typeof r > "u" && o.isIdempotencyToken()) return (0, xt.v4)();
            let i = o.getMergedTraits().mediaType;
            if (
              r != null &&
              i &&
              (i === "application/json" || i.endsWith("+json"))
            )
              return Be.from(r);
          }
          if (o.isDocumentSchema())
            if (s) {
              let i = Array.isArray(r) ? [] : {};
              for (let [a, d] of Object.entries(r))
                d instanceof Ee ? (i[a] = d) : (i[a] = this._write(o, d));
              return i;
            } else return structuredClone(r);
          return r;
        }
      }
    };
  });
var tn,
  oa = b(() => {
    Er();
    qf();
    Vf();
    tn = class extends He {
      settings;
      constructor(t) {
        (super(), (this.settings = t));
      }
      createSerializer() {
        let t = new $s(this.settings);
        return (t.setSerdeContext(this.serdeContext), t);
      }
      createDeserializer() {
        let t = new Ls(this.settings);
        return (t.setSerdeContext(this.serdeContext), t);
      }
    };
  });
var rn,
  ia = b(() => {
    et();
    we();
    Mn();
    oa();
    Fs();
    rn = class extends Lt {
      serializer;
      deserializer;
      serviceTarget;
      codec;
      mixin = new it();
      awsQueryCompatible;
      constructor({
        defaultNamespace: t,
        serviceTarget: r,
        awsQueryCompatible: n,
      }) {
        (super({ defaultNamespace: t }),
          (this.serviceTarget = r),
          (this.codec = new tn({
            timestampFormat: { useTrait: !0, default: 7 },
            jsonName: !1,
          })),
          (this.serializer = this.codec.createSerializer()),
          (this.deserializer = this.codec.createDeserializer()),
          (this.awsQueryCompatible = !!n));
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n);
        return (
          s.path.endsWith("/") || (s.path += "/"),
          Object.assign(s.headers, {
            "content-type": `application/x-amz-json-${this.getJsonRpcVersion()}`,
            "x-amz-target": `${this.serviceTarget}.${L.of(t).getName()}`,
          }),
          this.awsQueryCompatible && (s.headers["x-amzn-query-mode"] = "true"),
          (ot(t.input) === "unit" || !s.body) && (s.body = "{}"),
          s
        );
      }
      getPayloadCodec() {
        return this.codec;
      }
      async handleError(t, r, n, s, o) {
        this.awsQueryCompatible && this.mixin.setQueryCompatError(s, n);
        let i = en(n, s) ?? "Unknown",
          { errorSchema: a, errorMetadata: d } =
            await this.mixin.getErrorSchemaOrThrowBaseException(
              i,
              this.options.defaultNamespace,
              n,
              s,
              o,
            ),
          l = L.of(a),
          p = s.message ?? s.Message ?? "Unknown",
          m = Te.for(a.namespace).getErrorCtor(a) ?? Error,
          g = new m(p),
          h = {};
        for (let [E, C] of l.structIterator()) {
          let I = C.getMergedTraits().jsonName ?? E;
          h[E] = this.codec.createDeserializer().readObject(C, s[I]);
        }
        throw (
          this.awsQueryCompatible && this.mixin.queryCompatOutput(s, h),
          Object.assign(
            g,
            d,
            { $fault: l.getMergedTraits().error, message: p },
            h,
          )
        );
      }
    };
  });
var Gf,
  E_ = b(() => {
    ia();
    Gf = class extends rn {
      constructor({
        defaultNamespace: t,
        serviceTarget: r,
        awsQueryCompatible: n,
      }) {
        super({ defaultNamespace: t, serviceTarget: r, awsQueryCompatible: n });
      }
      getShapeId() {
        return "aws.protocols#awsJson1_0";
      }
      getJsonRpcVersion() {
        return "1.0";
      }
      getDefaultContentType() {
        return "application/x-amz-json-1.0";
      }
    };
  });
var Wf,
  __ = b(() => {
    ia();
    Wf = class extends rn {
      constructor({
        defaultNamespace: t,
        serviceTarget: r,
        awsQueryCompatible: n,
      }) {
        super({ defaultNamespace: t, serviceTarget: r, awsQueryCompatible: n });
      }
      getShapeId() {
        return "aws.protocols#awsJson1_1";
      }
      getJsonRpcVersion() {
        return "1.1";
      }
      getDefaultContentType() {
        return "application/x-amz-json-1.1";
      }
    };
  });
var Kf,
  w_ = b(() => {
    et();
    we();
    Mn();
    oa();
    Fs();
    Kf = class extends qr {
      serializer;
      deserializer;
      codec;
      mixin = new it();
      constructor({ defaultNamespace: t }) {
        super({ defaultNamespace: t });
        let r = {
          timestampFormat: { useTrait: !0, default: 7 },
          httpBindings: !0,
          jsonName: !0,
        };
        ((this.codec = new tn(r)),
          (this.serializer = new Wr(this.codec.createSerializer(), r)),
          (this.deserializer = new Gr(this.codec.createDeserializer(), r)));
      }
      getShapeId() {
        return "aws.protocols#restJson1";
      }
      getPayloadCodec() {
        return this.codec;
      }
      setSerdeContext(t) {
        (this.codec.setSerdeContext(t), super.setSerdeContext(t));
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n),
          o = L.of(t.input);
        if (!s.headers["content-type"]) {
          let i = this.mixin.resolveRestContentType(
            this.getDefaultContentType(),
            o,
          );
          i && (s.headers["content-type"] = i);
        }
        return (s.headers["content-type"] && !s.body && (s.body = "{}"), s);
      }
      async handleError(t, r, n, s, o) {
        let i = en(n, s) ?? "Unknown",
          { errorSchema: a, errorMetadata: d } =
            await this.mixin.getErrorSchemaOrThrowBaseException(
              i,
              this.options.defaultNamespace,
              n,
              s,
              o,
            ),
          l = L.of(a),
          p = s.message ?? s.Message ?? "Unknown",
          m = Te.for(a.namespace).getErrorCtor(a) ?? Error,
          g = new m(p);
        await this.deserializeHttpMessage(a, r, n, s);
        let h = {};
        for (let [E, C] of l.structIterator()) {
          let I = C.getMergedTraits().jsonName ?? E;
          h[E] = this.codec.createDeserializer().readObject(C, s[I]);
        }
        throw Object.assign(
          g,
          d,
          { $fault: l.getMergedTraits().error, message: p },
          h,
        );
      }
      getDefaultContentType() {
        return "application/json";
      }
    };
  });
var b_,
  OO,
  x_ = b(() => {
    ((b_ = v(Y())),
      (OO = (e) => {
        if (e != null)
          return (
            typeof e == "object" && "__type" in e && delete e.__type,
            (0, b_.expectUnion)(e)
          );
      }));
  });
var T_ = P((a4, v_) => {
  (() => {
    "use strict";
    var e = {
        d: (u, f) => {
          for (var S in f)
            e.o(f, S) &&
              !e.o(u, S) &&
              Object.defineProperty(u, S, { enumerable: !0, get: f[S] });
        },
        o: (u, f) => Object.prototype.hasOwnProperty.call(u, f),
        r: (u) => {
          (typeof Symbol < "u" &&
            Symbol.toStringTag &&
            Object.defineProperty(u, Symbol.toStringTag, { value: "Module" }),
            Object.defineProperty(u, "__esModule", { value: !0 }));
        },
      },
      t = {};
    (e.r(t),
      e.d(t, {
        XMLBuilder: () => er,
        XMLParser: () => IA,
        XMLValidator: () => kA,
      }));
    let r =
        ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD",
      n = new RegExp(
        "^[" + r + "][" + r + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$",
      );
    function s(u, f) {
      let S = [],
        w = f.exec(u);
      for (; w; ) {
        let y = [];
        y.startIndex = f.lastIndex - w[0].length;
        let _ = w.length;
        for (let A = 0; A < _; A++) y.push(w[A]);
        (S.push(y), (w = f.exec(u)));
      }
      return S;
    }
    let o = function (u) {
        return n.exec(u) != null;
      },
      i = { allowBooleanAttributes: !1, unpairedTags: [] };
    function a(u, f) {
      f = Object.assign({}, i, f);
      let S = [],
        w = !1,
        y = !1;
      u[0] === "\uFEFF" && (u = u.substr(1));
      for (let _ = 0; _ < u.length; _++)
        if (u[_] === "<" && u[_ + 1] === "?") {
          if (((_ += 2), (_ = l(u, _)), _.err)) return _;
        } else {
          if (u[_] !== "<") {
            if (d(u[_])) continue;
            return R(
              "InvalidChar",
              "char '" + u[_] + "' is not expected.",
              $(u, _),
            );
          }
          {
            let A = _;
            if ((_++, u[_] === "!")) {
              _ = p(u, _);
              continue;
            }
            {
              let T = !1;
              u[_] === "/" && ((T = !0), _++);
              let N = "";
              for (
                ;
                _ < u.length &&
                u[_] !== ">" &&
                u[_] !== " " &&
                u[_] !== "	" &&
                u[_] !==
                  `
` &&
                u[_] !== "\r";
                _++
              )
                N += u[_];
              if (
                ((N = N.trim()),
                N[N.length - 1] === "/" &&
                  ((N = N.substring(0, N.length - 1)), _--),
                !o(N))
              ) {
                let z;
                return (
                  (z =
                    N.trim().length === 0
                      ? "Invalid space after '<'."
                      : "Tag '" + N + "' is an invalid name."),
                  R("InvalidTag", z, $(u, _))
                );
              }
              let M = h(u, _);
              if (M === !1)
                return R(
                  "InvalidAttr",
                  "Attributes for '" + N + "' have open quote.",
                  $(u, _),
                );
              let q = M.value;
              if (((_ = M.index), q[q.length - 1] === "/")) {
                let z = _ - q.length;
                q = q.substring(0, q.length - 1);
                let oe = C(q, f);
                if (oe !== !0)
                  return R(oe.err.code, oe.err.msg, $(u, z + oe.err.line));
                w = !0;
              } else if (T) {
                if (!M.tagClosed)
                  return R(
                    "InvalidTag",
                    "Closing tag '" + N + "' doesn't have proper closing.",
                    $(u, _),
                  );
                if (q.trim().length > 0)
                  return R(
                    "InvalidTag",
                    "Closing tag '" +
                      N +
                      "' can't have attributes or invalid starting.",
                    $(u, A),
                  );
                if (S.length === 0)
                  return R(
                    "InvalidTag",
                    "Closing tag '" + N + "' has not been opened.",
                    $(u, A),
                  );
                {
                  let z = S.pop();
                  if (N !== z.tagName) {
                    let oe = $(u, z.tagStartPos);
                    return R(
                      "InvalidTag",
                      "Expected closing tag '" +
                        z.tagName +
                        "' (opened in line " +
                        oe.line +
                        ", col " +
                        oe.col +
                        ") instead of closing tag '" +
                        N +
                        "'.",
                      $(u, A),
                    );
                  }
                  S.length == 0 && (y = !0);
                }
              } else {
                let z = C(q, f);
                if (z !== !0)
                  return R(
                    z.err.code,
                    z.err.msg,
                    $(u, _ - q.length + z.err.line),
                  );
                if (y === !0)
                  return R(
                    "InvalidXml",
                    "Multiple possible root nodes found.",
                    $(u, _),
                  );
                (f.unpairedTags.indexOf(N) !== -1 ||
                  S.push({ tagName: N, tagStartPos: A }),
                  (w = !0));
              }
              for (_++; _ < u.length; _++)
                if (u[_] === "<") {
                  if (u[_ + 1] === "!") {
                    (_++, (_ = p(u, _)));
                    continue;
                  }
                  if (u[_ + 1] !== "?") break;
                  if (((_ = l(u, ++_)), _.err)) return _;
                } else if (u[_] === "&") {
                  let z = I(u, _);
                  if (z == -1)
                    return R(
                      "InvalidChar",
                      "char '&' is not expected.",
                      $(u, _),
                    );
                  _ = z;
                } else if (y === !0 && !d(u[_]))
                  return R("InvalidXml", "Extra text at the end", $(u, _));
              u[_] === "<" && _--;
            }
          }
        }
      return w
        ? S.length == 1
          ? R(
              "InvalidTag",
              "Unclosed tag '" + S[0].tagName + "'.",
              $(u, S[0].tagStartPos),
            )
          : !(S.length > 0) ||
            R(
              "InvalidXml",
              "Invalid '" +
                JSON.stringify(
                  S.map((_) => _.tagName),
                  null,
                  4,
                ).replace(/\r?\n/g, "") +
                "' found.",
              { line: 1, col: 1 },
            )
        : R("InvalidXml", "Start tag expected.", 1);
    }
    function d(u) {
      return (
        u === " " ||
        u === "	" ||
        u ===
          `
` ||
        u === "\r"
      );
    }
    function l(u, f) {
      let S = f;
      for (; f < u.length; f++)
        if (!(u[f] != "?" && u[f] != " ")) {
          let w = u.substr(S, f - S);
          if (f > 5 && w === "xml")
            return R(
              "InvalidXml",
              "XML declaration allowed only at the start of the document.",
              $(u, f),
            );
          if (u[f] == "?" && u[f + 1] == ">") {
            f++;
            break;
          }
        }
      return f;
    }
    function p(u, f) {
      if (u.length > f + 5 && u[f + 1] === "-" && u[f + 2] === "-") {
        for (f += 3; f < u.length; f++)
          if (u[f] === "-" && u[f + 1] === "-" && u[f + 2] === ">") {
            f += 2;
            break;
          }
      } else if (
        u.length > f + 8 &&
        u[f + 1] === "D" &&
        u[f + 2] === "O" &&
        u[f + 3] === "C" &&
        u[f + 4] === "T" &&
        u[f + 5] === "Y" &&
        u[f + 6] === "P" &&
        u[f + 7] === "E"
      ) {
        let S = 1;
        for (f += 8; f < u.length; f++)
          if (u[f] === "<") S++;
          else if (u[f] === ">" && (S--, S === 0)) break;
      } else if (
        u.length > f + 9 &&
        u[f + 1] === "[" &&
        u[f + 2] === "C" &&
        u[f + 3] === "D" &&
        u[f + 4] === "A" &&
        u[f + 5] === "T" &&
        u[f + 6] === "A" &&
        u[f + 7] === "["
      ) {
        for (f += 8; f < u.length; f++)
          if (u[f] === "]" && u[f + 1] === "]" && u[f + 2] === ">") {
            f += 2;
            break;
          }
      }
      return f;
    }
    let m = '"',
      g = "'";
    function h(u, f) {
      let S = "",
        w = "",
        y = !1;
      for (; f < u.length; f++) {
        if (u[f] === m || u[f] === g)
          w === "" ? (w = u[f]) : w !== u[f] || (w = "");
        else if (u[f] === ">" && w === "") {
          y = !0;
          break;
        }
        S += u[f];
      }
      return w === "" && { value: S, index: f, tagClosed: y };
    }
    let E = new RegExp(
      `(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`,
      "g",
    );
    function C(u, f) {
      let S = s(u, E),
        w = {};
      for (let y = 0; y < S.length; y++) {
        if (S[y][1].length === 0)
          return R(
            "InvalidAttr",
            "Attribute '" + S[y][2] + "' has no space in starting.",
            j(S[y]),
          );
        if (S[y][3] !== void 0 && S[y][4] === void 0)
          return R(
            "InvalidAttr",
            "Attribute '" + S[y][2] + "' is without value.",
            j(S[y]),
          );
        if (S[y][3] === void 0 && !f.allowBooleanAttributes)
          return R(
            "InvalidAttr",
            "boolean attribute '" + S[y][2] + "' is not allowed.",
            j(S[y]),
          );
        let _ = S[y][2];
        if (!O(_))
          return R(
            "InvalidAttr",
            "Attribute '" + _ + "' is an invalid name.",
            j(S[y]),
          );
        if (w.hasOwnProperty(_))
          return R(
            "InvalidAttr",
            "Attribute '" + _ + "' is repeated.",
            j(S[y]),
          );
        w[_] = 1;
      }
      return !0;
    }
    function I(u, f) {
      if (u[++f] === ";") return -1;
      if (u[f] === "#")
        return (function (w, y) {
          let _ = /\d/;
          for (w[y] === "x" && (y++, (_ = /[\da-fA-F]/)); y < w.length; y++) {
            if (w[y] === ";") return y;
            if (!w[y].match(_)) break;
          }
          return -1;
        })(u, ++f);
      let S = 0;
      for (; f < u.length; f++, S++)
        if (!(u[f].match(/\w/) && S < 20)) {
          if (u[f] === ";") break;
          return -1;
        }
      return f;
    }
    function R(u, f, S) {
      return { err: { code: u, msg: f, line: S.line || S, col: S.col } };
    }
    function O(u) {
      return o(u);
    }
    function $(u, f) {
      let S = u.substring(0, f).split(/\r?\n/);
      return { line: S.length, col: S[S.length - 1].length + 1 };
    }
    function j(u) {
      return u.startIndex + u[1].length;
    }
    let H = {
        preserveOrder: !1,
        attributeNamePrefix: "@_",
        attributesGroupName: !1,
        textNodeName: "#text",
        ignoreAttributes: !0,
        removeNSPrefix: !1,
        allowBooleanAttributes: !1,
        parseTagValue: !0,
        parseAttributeValue: !1,
        trimValues: !0,
        cdataPropName: !1,
        numberParseOptions: { hex: !0, leadingZeros: !0, eNotation: !0 },
        tagValueProcessor: function (u, f) {
          return f;
        },
        attributeValueProcessor: function (u, f) {
          return f;
        },
        stopNodes: [],
        alwaysCreateTextNode: !1,
        isArray: () => !1,
        commentPropName: !1,
        unpairedTags: [],
        processEntities: !0,
        htmlEntities: !1,
        ignoreDeclaration: !1,
        ignorePiTags: !1,
        transformTagName: !1,
        transformAttributeName: !1,
        updateTag: function (u, f, S) {
          return u;
        },
        captureMetaData: !1,
      },
      se;
    se =
      typeof Symbol != "function"
        ? "@@xmlMetadata"
        : Symbol("XML Node Metadata");
    class Le {
      constructor(f) {
        ((this.tagname = f), (this.child = []), (this[":@"] = {}));
      }
      add(f, S) {
        (f === "__proto__" && (f = "#__proto__"), this.child.push({ [f]: S }));
      }
      addChild(f, S) {
        (f.tagname === "__proto__" && (f.tagname = "#__proto__"),
          f[":@"] && Object.keys(f[":@"]).length > 0
            ? this.child.push({ [f.tagname]: f.child, ":@": f[":@"] })
            : this.child.push({ [f.tagname]: f.child }),
          S !== void 0 &&
            (this.child[this.child.length - 1][se] = { startIndex: S }));
      }
      static getMetaDataSymbol() {
        return se;
      }
    }
    function Ve(u, f) {
      let S = {};
      if (
        u[f + 3] !== "O" ||
        u[f + 4] !== "C" ||
        u[f + 5] !== "T" ||
        u[f + 6] !== "Y" ||
        u[f + 7] !== "P" ||
        u[f + 8] !== "E"
      )
        throw new Error("Invalid Tag instead of DOCTYPE");
      {
        f += 9;
        let w = 1,
          y = !1,
          _ = !1,
          A = "";
        for (; f < u.length; f++)
          if (u[f] !== "<" || _)
            if (u[f] === ">") {
              if (
                (_
                  ? u[f - 1] === "-" && u[f - 2] === "-" && ((_ = !1), w--)
                  : w--,
                w === 0)
              )
                break;
            } else u[f] === "[" ? (y = !0) : (A += u[f]);
          else {
            if (y && Ur(u, "!ENTITY", f)) {
              let T, N;
              ((f += 7),
                ([T, N, f] = ue(u, f + 1)),
                N.indexOf("&") === -1 &&
                  (S[T] = { regx: RegExp(`&${T};`, "g"), val: N }));
            } else if (y && Ur(u, "!ELEMENT", f)) {
              f += 8;
              let { index: T } = iA(u, f + 1);
              f = T;
            } else if (y && Ur(u, "!ATTLIST", f)) f += 8;
            else if (y && Ur(u, "!NOTATION", f)) {
              f += 9;
              let { index: T } = ve(u, f + 1);
              f = T;
            } else {
              if (!Ur(u, "!--", f)) throw new Error("Invalid DOCTYPE");
              _ = !0;
            }
            (w++, (A = ""));
          }
        if (w !== 0) throw new Error("Unclosed DOCTYPE");
      }
      return { entities: S, i: f };
    }
    let ge = (u, f) => {
      for (; f < u.length && /\s/.test(u[f]); ) f++;
      return f;
    };
    function ue(u, f) {
      f = ge(u, f);
      let S = "";
      for (; f < u.length && !/\s/.test(u[f]) && u[f] !== '"' && u[f] !== "'"; )
        ((S += u[f]), f++);
      if (
        (Zd(S),
        (f = ge(u, f)),
        u.substring(f, f + 6).toUpperCase() === "SYSTEM")
      )
        throw new Error("External entities are not supported");
      if (u[f] === "%") throw new Error("Parameter entities are not supported");
      let w = "";
      return (([f, w] = mn(u, f, "entity")), [S, w, --f]);
    }
    function ve(u, f) {
      f = ge(u, f);
      let S = "";
      for (; f < u.length && !/\s/.test(u[f]); ) ((S += u[f]), f++);
      (Zd(S), (f = ge(u, f)));
      let w = u.substring(f, f + 6).toUpperCase();
      if (w !== "SYSTEM" && w !== "PUBLIC")
        throw new Error(`Expected SYSTEM or PUBLIC, found "${w}"`);
      ((f += w.length), (f = ge(u, f)));
      let y = null,
        _ = null;
      if (w === "PUBLIC")
        (([f, y] = mn(u, f, "publicIdentifier")),
          (u[(f = ge(u, f))] !== '"' && u[f] !== "'") ||
            ([f, _] = mn(u, f, "systemIdentifier")));
      else if (w === "SYSTEM" && (([f, _] = mn(u, f, "systemIdentifier")), !_))
        throw new Error(
          "Missing mandatory system identifier for SYSTEM notation",
        );
      return {
        notationName: S,
        publicIdentifier: y,
        systemIdentifier: _,
        index: --f,
      };
    }
    function mn(u, f, S) {
      let w = "",
        y = u[f];
      if (y !== '"' && y !== "'")
        throw new Error(`Expected quoted string, found "${y}"`);
      for (f++; f < u.length && u[f] !== y; ) ((w += u[f]), f++);
      if (u[f] !== y) throw new Error(`Unterminated ${S} value`);
      return [++f, w];
    }
    function iA(u, f) {
      f = ge(u, f);
      let S = "";
      for (; f < u.length && !/\s/.test(u[f]); ) ((S += u[f]), f++);
      if (!Zd(S)) throw new Error(`Invalid element name: "${S}"`);
      let w = "";
      if (u[(f = ge(u, f))] === "E" && Ur(u, "MPTY", f)) f += 4;
      else if (u[f] === "A" && Ur(u, "NY", f)) f += 2;
      else {
        if (u[f] !== "(")
          throw new Error(`Invalid Element Expression, found "${u[f]}"`);
        for (f++; f < u.length && u[f] !== ")"; ) ((w += u[f]), f++);
        if (u[f] !== ")") throw new Error("Unterminated content model");
      }
      return { elementName: S, contentModel: w.trim(), index: f };
    }
    function Ur(u, f, S) {
      for (let w = 0; w < f.length; w++) if (f[w] !== u[S + w + 1]) return !1;
      return !0;
    }
    function Zd(u) {
      if (o(u)) return u;
      throw new Error(`Invalid entity name ${u}`);
    }
    let aA = /^[-+]?0x[a-fA-F0-9]+$/,
      cA = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/,
      dA = { hex: !0, leadingZeros: !0, decimalPoint: ".", eNotation: !0 },
      lA = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
    function Ym(u) {
      return typeof u == "function"
        ? u
        : Array.isArray(u)
          ? (f) => {
              for (let S of u)
                if (
                  (typeof S == "string" && f === S) ||
                  (S instanceof RegExp && S.test(f))
                )
                  return !0;
            }
          : () => !1;
    }
    class uA {
      constructor(f) {
        ((this.options = f),
          (this.currentNode = null),
          (this.tagsNodeStack = []),
          (this.docTypeEntities = {}),
          (this.lastEntities = {
            apos: { regex: /&(apos|#39|#x27);/g, val: "'" },
            gt: { regex: /&(gt|#62|#x3E);/g, val: ">" },
            lt: { regex: /&(lt|#60|#x3C);/g, val: "<" },
            quot: { regex: /&(quot|#34|#x22);/g, val: '"' },
          }),
          (this.ampEntity = { regex: /&(amp|#38|#x26);/g, val: "&" }),
          (this.htmlEntities = {
            space: { regex: /&(nbsp|#160);/g, val: " " },
            cent: { regex: /&(cent|#162);/g, val: "\xA2" },
            pound: { regex: /&(pound|#163);/g, val: "\xA3" },
            yen: { regex: /&(yen|#165);/g, val: "\xA5" },
            euro: { regex: /&(euro|#8364);/g, val: "\u20AC" },
            copyright: { regex: /&(copy|#169);/g, val: "\xA9" },
            reg: { regex: /&(reg|#174);/g, val: "\xAE" },
            inr: { regex: /&(inr|#8377);/g, val: "\u20B9" },
            num_dec: {
              regex: /&#([0-9]{1,7});/g,
              val: (S, w) => String.fromCodePoint(Number.parseInt(w, 10)),
            },
            num_hex: {
              regex: /&#x([0-9a-fA-F]{1,6});/g,
              val: (S, w) => String.fromCodePoint(Number.parseInt(w, 16)),
            },
          }),
          (this.addExternalEntities = fA),
          (this.parseXml = SA),
          (this.parseTextData = pA),
          (this.resolveNameSpace = mA),
          (this.buildAttributesMap = gA),
          (this.isItStopNode = wA),
          (this.replaceEntitiesValue = EA),
          (this.readStopNodeData = bA),
          (this.saveTextToParentTag = _A),
          (this.addChild = yA),
          (this.ignoreAttributesFn = Ym(this.options.ignoreAttributes)));
      }
    }
    function fA(u) {
      let f = Object.keys(u);
      for (let S = 0; S < f.length; S++) {
        let w = f[S];
        this.lastEntities[w] = {
          regex: new RegExp("&" + w + ";", "g"),
          val: u[w],
        };
      }
    }
    function pA(u, f, S, w, y, _, A) {
      if (
        u !== void 0 &&
        (this.options.trimValues && !w && (u = u.trim()), u.length > 0)
      ) {
        A || (u = this.replaceEntitiesValue(u));
        let T = this.options.tagValueProcessor(f, u, S, y, _);
        return T == null
          ? u
          : typeof T != typeof u || T !== u
            ? T
            : this.options.trimValues || u.trim() === u
              ? Xm(
                  u,
                  this.options.parseTagValue,
                  this.options.numberParseOptions,
                )
              : u;
      }
    }
    function mA(u) {
      if (this.options.removeNSPrefix) {
        let f = u.split(":"),
          S = u.charAt(0) === "/" ? "/" : "";
        if (f[0] === "xmlns") return "";
        f.length === 2 && (u = S + f[1]);
      }
      return u;
    }
    let hA = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
    function gA(u, f, S) {
      if (this.options.ignoreAttributes !== !0 && typeof u == "string") {
        let w = s(u, hA),
          y = w.length,
          _ = {};
        for (let A = 0; A < y; A++) {
          let T = this.resolveNameSpace(w[A][1]);
          if (this.ignoreAttributesFn(T, f)) continue;
          let N = w[A][4],
            M = this.options.attributeNamePrefix + T;
          if (T.length)
            if (
              (this.options.transformAttributeName &&
                (M = this.options.transformAttributeName(M)),
              M === "__proto__" && (M = "#__proto__"),
              N !== void 0)
            ) {
              (this.options.trimValues && (N = N.trim()),
                (N = this.replaceEntitiesValue(N)));
              let q = this.options.attributeValueProcessor(T, N, f);
              _[M] =
                q == null
                  ? N
                  : typeof q != typeof N || q !== N
                    ? q
                    : Xm(
                        N,
                        this.options.parseAttributeValue,
                        this.options.numberParseOptions,
                      );
            } else this.options.allowBooleanAttributes && (_[M] = !0);
        }
        if (!Object.keys(_).length) return;
        if (this.options.attributesGroupName) {
          let A = {};
          return ((A[this.options.attributesGroupName] = _), A);
        }
        return _;
      }
    }
    let SA = function (u) {
      u = u.replace(
        /\r\n?/g,
        `
`,
      );
      let f = new Le("!xml"),
        S = f,
        w = "",
        y = "";
      for (let _ = 0; _ < u.length; _++)
        if (u[_] === "<")
          if (u[_ + 1] === "/") {
            let A = Hr(u, ">", _, "Closing Tag is not closed."),
              T = u.substring(_ + 2, A).trim();
            if (this.options.removeNSPrefix) {
              let q = T.indexOf(":");
              q !== -1 && (T = T.substr(q + 1));
            }
            (this.options.transformTagName &&
              (T = this.options.transformTagName(T)),
              S && (w = this.saveTextToParentTag(w, S, y)));
            let N = y.substring(y.lastIndexOf(".") + 1);
            if (T && this.options.unpairedTags.indexOf(T) !== -1)
              throw new Error(
                `Unpaired tag can not be used as closing tag: </${T}>`,
              );
            let M = 0;
            (N && this.options.unpairedTags.indexOf(N) !== -1
              ? ((M = y.lastIndexOf(".", y.lastIndexOf(".") - 1)),
                this.tagsNodeStack.pop())
              : (M = y.lastIndexOf(".")),
              (y = y.substring(0, M)),
              (S = this.tagsNodeStack.pop()),
              (w = ""),
              (_ = A));
          } else if (u[_ + 1] === "?") {
            let A = el(u, _, !1, "?>");
            if (!A) throw new Error("Pi Tag is not closed.");
            if (
              ((w = this.saveTextToParentTag(w, S, y)),
              !(
                (this.options.ignoreDeclaration && A.tagName === "?xml") ||
                this.options.ignorePiTags
              ))
            ) {
              let T = new Le(A.tagName);
              (T.add(this.options.textNodeName, ""),
                A.tagName !== A.tagExp &&
                  A.attrExpPresent &&
                  (T[":@"] = this.buildAttributesMap(A.tagExp, y, A.tagName)),
                this.addChild(S, T, y, _));
            }
            _ = A.closeIndex + 1;
          } else if (u.substr(_ + 1, 3) === "!--") {
            let A = Hr(u, "-->", _ + 4, "Comment is not closed.");
            if (this.options.commentPropName) {
              let T = u.substring(_ + 4, A - 2);
              ((w = this.saveTextToParentTag(w, S, y)),
                S.add(this.options.commentPropName, [
                  { [this.options.textNodeName]: T },
                ]));
            }
            _ = A;
          } else if (u.substr(_ + 1, 2) === "!D") {
            let A = Ve(u, _);
            ((this.docTypeEntities = A.entities), (_ = A.i));
          } else if (u.substr(_ + 1, 2) === "![") {
            let A = Hr(u, "]]>", _, "CDATA is not closed.") - 2,
              T = u.substring(_ + 9, A);
            w = this.saveTextToParentTag(w, S, y);
            let N = this.parseTextData(T, S.tagname, y, !0, !1, !0, !0);
            (N == null && (N = ""),
              this.options.cdataPropName
                ? S.add(this.options.cdataPropName, [
                    { [this.options.textNodeName]: T },
                  ])
                : S.add(this.options.textNodeName, N),
              (_ = A + 2));
          } else {
            let A = el(u, _, this.options.removeNSPrefix),
              T = A.tagName,
              N = A.rawTagName,
              M = A.tagExp,
              q = A.attrExpPresent,
              z = A.closeIndex;
            (this.options.transformTagName &&
              (T = this.options.transformTagName(T)),
              S &&
                w &&
                S.tagname !== "!xml" &&
                (w = this.saveTextToParentTag(w, S, y, !1)));
            let oe = S;
            (oe &&
              this.options.unpairedTags.indexOf(oe.tagname) !== -1 &&
              ((S = this.tagsNodeStack.pop()),
              (y = y.substring(0, y.lastIndexOf(".")))),
              T !== f.tagname && (y += y ? "." + T : T));
            let de = _;
            if (this.isItStopNode(this.options.stopNodes, y, T)) {
              let ie = "";
              if (M.length > 0 && M.lastIndexOf("/") === M.length - 1)
                (T[T.length - 1] === "/"
                  ? ((T = T.substr(0, T.length - 1)),
                    (y = y.substr(0, y.length - 1)),
                    (M = T))
                  : (M = M.substr(0, M.length - 1)),
                  (_ = A.closeIndex));
              else if (this.options.unpairedTags.indexOf(T) !== -1)
                _ = A.closeIndex;
              else {
                let _t = this.readStopNodeData(u, N, z + 1);
                if (!_t) throw new Error(`Unexpected end of ${N}`);
                ((_ = _t.i), (ie = _t.tagContent));
              }
              let Ie = new Le(T);
              (T !== M && q && (Ie[":@"] = this.buildAttributesMap(M, y, T)),
                ie && (ie = this.parseTextData(ie, T, y, !0, q, !0, !0)),
                (y = y.substr(0, y.lastIndexOf("."))),
                Ie.add(this.options.textNodeName, ie),
                this.addChild(S, Ie, y, de));
            } else {
              if (M.length > 0 && M.lastIndexOf("/") === M.length - 1) {
                (T[T.length - 1] === "/"
                  ? ((T = T.substr(0, T.length - 1)),
                    (y = y.substr(0, y.length - 1)),
                    (M = T))
                  : (M = M.substr(0, M.length - 1)),
                  this.options.transformTagName &&
                    (T = this.options.transformTagName(T)));
                let ie = new Le(T);
                (T !== M && q && (ie[":@"] = this.buildAttributesMap(M, y, T)),
                  this.addChild(S, ie, y, de),
                  (y = y.substr(0, y.lastIndexOf("."))));
              } else {
                let ie = new Le(T);
                (this.tagsNodeStack.push(S),
                  T !== M && q && (ie[":@"] = this.buildAttributesMap(M, y, T)),
                  this.addChild(S, ie, y, de),
                  (S = ie));
              }
              ((w = ""), (_ = z));
            }
          }
        else w += u[_];
      return f.child;
    };
    function yA(u, f, S, w) {
      this.options.captureMetaData || (w = void 0);
      let y = this.options.updateTag(f.tagname, S, f[":@"]);
      y === !1 || (typeof y == "string" && (f.tagname = y), u.addChild(f, w));
    }
    let EA = function (u) {
      if (this.options.processEntities) {
        for (let f in this.docTypeEntities) {
          let S = this.docTypeEntities[f];
          u = u.replace(S.regx, S.val);
        }
        for (let f in this.lastEntities) {
          let S = this.lastEntities[f];
          u = u.replace(S.regex, S.val);
        }
        if (this.options.htmlEntities)
          for (let f in this.htmlEntities) {
            let S = this.htmlEntities[f];
            u = u.replace(S.regex, S.val);
          }
        u = u.replace(this.ampEntity.regex, this.ampEntity.val);
      }
      return u;
    };
    function _A(u, f, S, w) {
      return (
        u &&
          (w === void 0 && (w = f.child.length === 0),
          (u = this.parseTextData(
            u,
            f.tagname,
            S,
            !1,
            !!f[":@"] && Object.keys(f[":@"]).length !== 0,
            w,
          )) !== void 0 &&
            u !== "" &&
            f.add(this.options.textNodeName, u),
          (u = "")),
        u
      );
    }
    function wA(u, f, S) {
      let w = "*." + S;
      for (let y in u) {
        let _ = u[y];
        if (w === _ || f === _) return !0;
      }
      return !1;
    }
    function Hr(u, f, S, w) {
      let y = u.indexOf(f, S);
      if (y === -1) throw new Error(w);
      return y + f.length - 1;
    }
    function el(u, f, S, w = ">") {
      let y = (function (z, oe, de = ">") {
        let ie,
          Ie = "";
        for (let _t = oe; _t < z.length; _t++) {
          let tr = z[_t];
          if (ie) tr === ie && (ie = "");
          else if (tr === '"' || tr === "'") ie = tr;
          else if (tr === de[0]) {
            if (!de[1]) return { data: Ie, index: _t };
            if (z[_t + 1] === de[1]) return { data: Ie, index: _t };
          } else tr === "	" && (tr = " ");
          Ie += tr;
        }
      })(u, f + 1, w);
      if (!y) return;
      let _ = y.data,
        A = y.index,
        T = _.search(/\s/),
        N = _,
        M = !0;
      T !== -1 &&
        ((N = _.substring(0, T)), (_ = _.substring(T + 1).trimStart()));
      let q = N;
      if (S) {
        let z = N.indexOf(":");
        z !== -1 && ((N = N.substr(z + 1)), (M = N !== y.data.substr(z + 1)));
      }
      return {
        tagName: N,
        tagExp: _,
        closeIndex: A,
        attrExpPresent: M,
        rawTagName: q,
      };
    }
    function bA(u, f, S) {
      let w = S,
        y = 1;
      for (; S < u.length; S++)
        if (u[S] === "<")
          if (u[S + 1] === "/") {
            let _ = Hr(u, ">", S, `${f} is not closed`);
            if (u.substring(S + 2, _).trim() === f && (y--, y === 0))
              return { tagContent: u.substring(w, S), i: _ };
            S = _;
          } else if (u[S + 1] === "?")
            S = Hr(u, "?>", S + 1, "StopNode is not closed.");
          else if (u.substr(S + 1, 3) === "!--")
            S = Hr(u, "-->", S + 3, "StopNode is not closed.");
          else if (u.substr(S + 1, 2) === "![")
            S = Hr(u, "]]>", S, "StopNode is not closed.") - 2;
          else {
            let _ = el(u, S, ">");
            _ &&
              ((_ && _.tagName) === f &&
                _.tagExp[_.tagExp.length - 1] !== "/" &&
                y++,
              (S = _.closeIndex));
          }
    }
    function Xm(u, f, S) {
      if (f && typeof u == "string") {
        let w = u.trim();
        return (
          w === "true" ||
          (w !== "false" &&
            (function (y, _ = {}) {
              if (((_ = Object.assign({}, dA, _)), !y || typeof y != "string"))
                return y;
              let A = y.trim();
              if (_.skipLike !== void 0 && _.skipLike.test(A)) return y;
              if (y === "0") return 0;
              if (_.hex && aA.test(A))
                return (function (N) {
                  if (parseInt) return parseInt(N, 16);
                  if (Number.parseInt) return Number.parseInt(N, 16);
                  if (window && window.parseInt) return window.parseInt(N, 16);
                  throw new Error(
                    "parseInt, Number.parseInt, window.parseInt are not supported",
                  );
                })(A);
              if (A.search(/.+[eE].+/) !== -1)
                return (function (N, M, q) {
                  if (!q.eNotation) return N;
                  let z = M.match(lA);
                  if (z) {
                    let oe = z[1] || "",
                      de = z[3].indexOf("e") === -1 ? "E" : "e",
                      ie = z[2],
                      Ie = oe ? N[ie.length + 1] === de : N[ie.length] === de;
                    return ie.length > 1 && Ie
                      ? N
                      : ie.length !== 1 ||
                          (!z[3].startsWith(`.${de}`) && z[3][0] !== de)
                        ? q.leadingZeros && !Ie
                          ? ((M = (z[1] || "") + z[3]), Number(M))
                          : N
                        : Number(M);
                  }
                  return N;
                })(y, A, _);
              {
                let N = cA.exec(A);
                if (N) {
                  let M = N[1] || "",
                    q = N[2],
                    z =
                      ((T = N[3]) &&
                        T.indexOf(".") !== -1 &&
                        ((T = T.replace(/0+$/, "")) === "."
                          ? (T = "0")
                          : T[0] === "."
                            ? (T = "0" + T)
                            : T[T.length - 1] === "." &&
                              (T = T.substring(0, T.length - 1))),
                      T),
                    oe = M ? y[q.length + 1] === "." : y[q.length] === ".";
                  if (
                    !_.leadingZeros &&
                    (q.length > 1 || (q.length === 1 && !oe))
                  )
                    return y;
                  {
                    let de = Number(A),
                      ie = String(de);
                    if (de === 0 || de === -0) return de;
                    if (ie.search(/[eE]/) !== -1) return _.eNotation ? de : y;
                    if (A.indexOf(".") !== -1)
                      return ie === "0" || ie === z || ie === `${M}${z}`
                        ? de
                        : y;
                    let Ie = q ? z : A;
                    return q
                      ? Ie === ie || M + Ie === ie
                        ? de
                        : y
                      : Ie === ie || Ie === M + ie
                        ? de
                        : y;
                  }
                }
                return y;
              }
              var T;
            })(u, S))
        );
      }
      return u !== void 0 ? u : "";
    }
    let tl = Le.getMetaDataSymbol();
    function xA(u, f) {
      return Qm(u, f);
    }
    function Qm(u, f, S) {
      let w,
        y = {};
      for (let _ = 0; _ < u.length; _++) {
        let A = u[_],
          T = vA(A),
          N = "";
        if (((N = S === void 0 ? T : S + "." + T), T === f.textNodeName))
          w === void 0 ? (w = A[T]) : (w += "" + A[T]);
        else {
          if (T === void 0) continue;
          if (A[T]) {
            let M = Qm(A[T], f, N),
              q = CA(M, f);
            (A[tl] !== void 0 && (M[tl] = A[tl]),
              A[":@"]
                ? TA(M, A[":@"], N, f)
                : Object.keys(M).length !== 1 ||
                    M[f.textNodeName] === void 0 ||
                    f.alwaysCreateTextNode
                  ? Object.keys(M).length === 0 &&
                    (f.alwaysCreateTextNode
                      ? (M[f.textNodeName] = "")
                      : (M = ""))
                  : (M = M[f.textNodeName]),
              y[T] !== void 0 && y.hasOwnProperty(T)
                ? (Array.isArray(y[T]) || (y[T] = [y[T]]), y[T].push(M))
                : f.isArray(T, N, q)
                  ? (y[T] = [M])
                  : (y[T] = M));
          }
        }
      }
      return (
        typeof w == "string"
          ? w.length > 0 && (y[f.textNodeName] = w)
          : w !== void 0 && (y[f.textNodeName] = w),
        y
      );
    }
    function vA(u) {
      let f = Object.keys(u);
      for (let S = 0; S < f.length; S++) {
        let w = f[S];
        if (w !== ":@") return w;
      }
    }
    function TA(u, f, S, w) {
      if (f) {
        let y = Object.keys(f),
          _ = y.length;
        for (let A = 0; A < _; A++) {
          let T = y[A];
          w.isArray(T, S + "." + T, !0, !0) ? (u[T] = [f[T]]) : (u[T] = f[T]);
        }
      }
    }
    function CA(u, f) {
      let { textNodeName: S } = f,
        w = Object.keys(u).length;
      return (
        w === 0 ||
        !(w !== 1 || (!u[S] && typeof u[S] != "boolean" && u[S] !== 0))
      );
    }
    class IA {
      constructor(f) {
        ((this.externalEntities = {}),
          (this.options = (function (S) {
            return Object.assign({}, H, S);
          })(f)));
      }
      parse(f, S) {
        if (typeof f != "string") {
          if (!f.toString)
            throw new Error("XML data is accepted in String or Bytes[] form.");
          f = f.toString();
        }
        if (S) {
          S === !0 && (S = {});
          let _ = a(f, S);
          if (_ !== !0) throw Error(`${_.err.msg}:${_.err.line}:${_.err.col}`);
        }
        let w = new uA(this.options);
        w.addExternalEntities(this.externalEntities);
        let y = w.parseXml(f);
        return this.options.preserveOrder || y === void 0
          ? y
          : xA(y, this.options);
      }
      addEntity(f, S) {
        if (S.indexOf("&") !== -1)
          throw new Error("Entity value can't have '&'");
        if (f.indexOf("&") !== -1 || f.indexOf(";") !== -1)
          throw new Error(
            "An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'",
          );
        if (S === "&")
          throw new Error("An entity with value '&' is not permitted");
        this.externalEntities[f] = S;
      }
      static getMetaDataSymbol() {
        return Le.getMetaDataSymbol();
      }
    }
    function AA(u, f) {
      let S = "";
      return (
        f.format &&
          f.indentBy.length > 0 &&
          (S = `
`),
        Zm(u, f, "", S)
      );
    }
    function Zm(u, f, S, w) {
      let y = "",
        _ = !1;
      for (let A = 0; A < u.length; A++) {
        let T = u[A],
          N = RA(T);
        if (N === void 0) continue;
        let M = "";
        if (((M = S.length === 0 ? N : `${S}.${N}`), N === f.textNodeName)) {
          let de = T[N];
          (NA(M, f) || ((de = f.tagValueProcessor(N, de)), (de = th(de, f))),
            _ && (y += w),
            (y += de),
            (_ = !1));
          continue;
        }
        if (N === f.cdataPropName) {
          (_ && (y += w),
            (y += `<![CDATA[${T[N][0][f.textNodeName]}]]>`),
            (_ = !1));
          continue;
        }
        if (N === f.commentPropName) {
          ((y += w + `<!--${T[N][0][f.textNodeName]}-->`), (_ = !0));
          continue;
        }
        if (N[0] === "?") {
          let de = eh(T[":@"], f),
            ie = N === "?xml" ? "" : w,
            Ie = T[N][0][f.textNodeName];
          ((Ie = Ie.length !== 0 ? " " + Ie : ""),
            (y += ie + `<${N}${Ie}${de}?>`),
            (_ = !0));
          continue;
        }
        let q = w;
        q !== "" && (q += f.indentBy);
        let z = w + `<${N}${eh(T[":@"], f)}`,
          oe = Zm(T[N], f, M, q);
        (f.unpairedTags.indexOf(N) !== -1
          ? f.suppressUnpairedNode
            ? (y += z + ">")
            : (y += z + "/>")
          : (oe && oe.length !== 0) || !f.suppressEmptyNode
            ? oe && oe.endsWith(">")
              ? (y += z + `>${oe}${w}</${N}>`)
              : ((y += z + ">"),
                oe && w !== "" && (oe.includes("/>") || oe.includes("</"))
                  ? (y += w + f.indentBy + oe + w)
                  : (y += oe),
                (y += `</${N}>`))
            : (y += z + "/>"),
          (_ = !0));
      }
      return y;
    }
    function RA(u) {
      let f = Object.keys(u);
      for (let S = 0; S < f.length; S++) {
        let w = f[S];
        if (u.hasOwnProperty(w) && w !== ":@") return w;
      }
    }
    function eh(u, f) {
      let S = "";
      if (u && !f.ignoreAttributes)
        for (let w in u) {
          if (!u.hasOwnProperty(w)) continue;
          let y = f.attributeValueProcessor(w, u[w]);
          ((y = th(y, f)),
            y === !0 && f.suppressBooleanAttributes
              ? (S += ` ${w.substr(f.attributeNamePrefix.length)}`)
              : (S += ` ${w.substr(f.attributeNamePrefix.length)}="${y}"`));
        }
      return S;
    }
    function NA(u, f) {
      let S = (u = u.substr(0, u.length - f.textNodeName.length - 1)).substr(
        u.lastIndexOf(".") + 1,
      );
      for (let w in f.stopNodes)
        if (f.stopNodes[w] === u || f.stopNodes[w] === "*." + S) return !0;
      return !1;
    }
    function th(u, f) {
      if (u && u.length > 0 && f.processEntities)
        for (let S = 0; S < f.entities.length; S++) {
          let w = f.entities[S];
          u = u.replace(w.regex, w.val);
        }
      return u;
    }
    let PA = {
      attributeNamePrefix: "@_",
      attributesGroupName: !1,
      textNodeName: "#text",
      ignoreAttributes: !0,
      cdataPropName: !1,
      format: !1,
      indentBy: "  ",
      suppressEmptyNode: !1,
      suppressUnpairedNode: !0,
      suppressBooleanAttributes: !0,
      tagValueProcessor: function (u, f) {
        return f;
      },
      attributeValueProcessor: function (u, f) {
        return f;
      },
      preserveOrder: !1,
      commentPropName: !1,
      unpairedTags: [],
      entities: [
        { regex: new RegExp("&", "g"), val: "&amp;" },
        { regex: new RegExp(">", "g"), val: "&gt;" },
        { regex: new RegExp("<", "g"), val: "&lt;" },
        { regex: new RegExp("'", "g"), val: "&apos;" },
        { regex: new RegExp('"', "g"), val: "&quot;" },
      ],
      processEntities: !0,
      stopNodes: [],
      oneListGroup: !1,
    };
    function er(u) {
      ((this.options = Object.assign({}, PA, u)),
        this.options.ignoreAttributes === !0 || this.options.attributesGroupName
          ? (this.isAttribute = function () {
              return !1;
            })
          : ((this.ignoreAttributesFn = Ym(this.options.ignoreAttributes)),
            (this.attrPrefixLen = this.options.attributeNamePrefix.length),
            (this.isAttribute = MA)),
        (this.processTextOrObjNode = OA),
        this.options.format
          ? ((this.indentate = DA),
            (this.tagEndChar = `>
`),
            (this.newLine = `
`))
          : ((this.indentate = function () {
              return "";
            }),
            (this.tagEndChar = ">"),
            (this.newLine = "")));
    }
    function OA(u, f, S, w) {
      let y = this.j2x(u, S + 1, w.concat(f));
      return u[this.options.textNodeName] !== void 0 &&
        Object.keys(u).length === 1
        ? this.buildTextValNode(u[this.options.textNodeName], f, y.attrStr, S)
        : this.buildObjectNode(y.val, f, y.attrStr, S);
    }
    function DA(u) {
      return this.options.indentBy.repeat(u);
    }
    function MA(u) {
      return (
        !(
          !u.startsWith(this.options.attributeNamePrefix) ||
          u === this.options.textNodeName
        ) && u.substr(this.attrPrefixLen)
      );
    }
    ((er.prototype.build = function (u) {
      return this.options.preserveOrder
        ? AA(u, this.options)
        : (Array.isArray(u) &&
            this.options.arrayNodeName &&
            this.options.arrayNodeName.length > 1 &&
            (u = { [this.options.arrayNodeName]: u }),
          this.j2x(u, 0, []).val);
    }),
      (er.prototype.j2x = function (u, f, S) {
        let w = "",
          y = "",
          _ = S.join(".");
        for (let A in u)
          if (Object.prototype.hasOwnProperty.call(u, A))
            if (u[A] === void 0) this.isAttribute(A) && (y += "");
            else if (u[A] === null)
              this.isAttribute(A) || A === this.options.cdataPropName
                ? (y += "")
                : A[0] === "?"
                  ? (y += this.indentate(f) + "<" + A + "?" + this.tagEndChar)
                  : (y += this.indentate(f) + "<" + A + "/" + this.tagEndChar);
            else if (u[A] instanceof Date)
              y += this.buildTextValNode(u[A], A, "", f);
            else if (typeof u[A] != "object") {
              let T = this.isAttribute(A);
              if (T && !this.ignoreAttributesFn(T, _))
                w += this.buildAttrPairStr(T, "" + u[A]);
              else if (!T)
                if (A === this.options.textNodeName) {
                  let N = this.options.tagValueProcessor(A, "" + u[A]);
                  y += this.replaceEntitiesValue(N);
                } else y += this.buildTextValNode(u[A], A, "", f);
            } else if (Array.isArray(u[A])) {
              let T = u[A].length,
                N = "",
                M = "";
              for (let q = 0; q < T; q++) {
                let z = u[A][q];
                if (z !== void 0)
                  if (z === null)
                    A[0] === "?"
                      ? (y +=
                          this.indentate(f) + "<" + A + "?" + this.tagEndChar)
                      : (y +=
                          this.indentate(f) + "<" + A + "/" + this.tagEndChar);
                  else if (typeof z == "object")
                    if (this.options.oneListGroup) {
                      let oe = this.j2x(z, f + 1, S.concat(A));
                      ((N += oe.val),
                        this.options.attributesGroupName &&
                          z.hasOwnProperty(this.options.attributesGroupName) &&
                          (M += oe.attrStr));
                    } else N += this.processTextOrObjNode(z, A, f, S);
                  else if (this.options.oneListGroup) {
                    let oe = this.options.tagValueProcessor(A, z);
                    ((oe = this.replaceEntitiesValue(oe)), (N += oe));
                  } else N += this.buildTextValNode(z, A, "", f);
              }
              (this.options.oneListGroup &&
                (N = this.buildObjectNode(N, A, M, f)),
                (y += N));
            } else if (
              this.options.attributesGroupName &&
              A === this.options.attributesGroupName
            ) {
              let T = Object.keys(u[A]),
                N = T.length;
              for (let M = 0; M < N; M++)
                w += this.buildAttrPairStr(T[M], "" + u[A][T[M]]);
            } else y += this.processTextOrObjNode(u[A], A, f, S);
        return { attrStr: w, val: y };
      }),
      (er.prototype.buildAttrPairStr = function (u, f) {
        return (
          (f = this.options.attributeValueProcessor(u, "" + f)),
          (f = this.replaceEntitiesValue(f)),
          this.options.suppressBooleanAttributes && f === "true"
            ? " " + u
            : " " + u + '="' + f + '"'
        );
      }),
      (er.prototype.buildObjectNode = function (u, f, S, w) {
        if (u === "")
          return f[0] === "?"
            ? this.indentate(w) + "<" + f + S + "?" + this.tagEndChar
            : this.indentate(w) +
                "<" +
                f +
                S +
                this.closeTag(f) +
                this.tagEndChar;
        {
          let y = "</" + f + this.tagEndChar,
            _ = "";
          return (
            f[0] === "?" && ((_ = "?"), (y = "")),
            (!S && S !== "") || u.indexOf("<") !== -1
              ? this.options.commentPropName !== !1 &&
                f === this.options.commentPropName &&
                _.length === 0
                ? this.indentate(w) + `<!--${u}-->` + this.newLine
                : this.indentate(w) +
                  "<" +
                  f +
                  S +
                  _ +
                  this.tagEndChar +
                  u +
                  this.indentate(w) +
                  y
              : this.indentate(w) + "<" + f + S + _ + ">" + u + y
          );
        }
      }),
      (er.prototype.closeTag = function (u) {
        let f = "";
        return (
          this.options.unpairedTags.indexOf(u) !== -1
            ? this.options.suppressUnpairedNode || (f = "/")
            : (f = this.options.suppressEmptyNode ? "/" : `></${u}`),
          f
        );
      }),
      (er.prototype.buildTextValNode = function (u, f, S, w) {
        if (
          this.options.cdataPropName !== !1 &&
          f === this.options.cdataPropName
        )
          return this.indentate(w) + `<![CDATA[${u}]]>` + this.newLine;
        if (
          this.options.commentPropName !== !1 &&
          f === this.options.commentPropName
        )
          return this.indentate(w) + `<!--${u}-->` + this.newLine;
        if (f[0] === "?")
          return this.indentate(w) + "<" + f + S + "?" + this.tagEndChar;
        {
          let y = this.options.tagValueProcessor(f, u);
          return (
            (y = this.replaceEntitiesValue(y)),
            y === ""
              ? this.indentate(w) +
                "<" +
                f +
                S +
                this.closeTag(f) +
                this.tagEndChar
              : this.indentate(w) +
                "<" +
                f +
                S +
                ">" +
                y +
                "</" +
                f +
                this.tagEndChar
          );
        }
      }),
      (er.prototype.replaceEntitiesValue = function (u) {
        if (u && u.length > 0 && this.options.processEntities)
          for (let f = 0; f < this.options.entities.length; f++) {
            let S = this.options.entities[f];
            u = u.replace(S.regex, S.val);
          }
        return u;
      }));
    let kA = { validate: a };
    v_.exports = t;
  })();
});
var C_ = P((Yf) => {
  "use strict";
  Object.defineProperty(Yf, "__esModule", { value: !0 });
  Yf.parseXML = MO;
  var DO = T_(),
    Jf = new DO.XMLParser({
      attributeNamePrefix: "",
      htmlEntities: !0,
      ignoreAttributes: !1,
      ignoreDeclaration: !0,
      parseTagValue: !1,
      trimValues: !1,
      tagValueProcessor: (e, t) =>
        t.trim() === "" &&
        t.includes(`
`)
          ? ""
          : void 0,
    });
  Jf.addEntity("#xD", "\r");
  Jf.addEntity(
    "#10",
    `
`,
  );
  function MO(e) {
    return Jf.parse(e, !0);
  }
});
var la = P((d4, P_) => {
  "use strict";
  var ca = Object.defineProperty,
    kO = Object.getOwnPropertyDescriptor,
    FO = Object.getOwnPropertyNames,
    LO = Object.prototype.hasOwnProperty,
    da = (e, t) => ca(e, "name", { value: t, configurable: !0 }),
    $O = (e, t) => {
      for (var r in t) ca(e, r, { get: t[r], enumerable: !0 });
    },
    UO = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of FO(t))
          !LO.call(e, s) &&
            s !== r &&
            ca(e, s, {
              get: () => t[s],
              enumerable: !(n = kO(t, s)) || n.enumerable,
            });
      return e;
    },
    HO = (e) => UO(ca({}, "__esModule", { value: !0 }), e),
    I_ = {};
  $O(I_, { XmlNode: () => zO, XmlText: () => N_, parseXML: () => jO.parseXML });
  P_.exports = HO(I_);
  function A_(e) {
    return e
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  da(A_, "escapeAttribute");
  function R_(e) {
    return e
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\r/g, "&#x0D;")
      .replace(/\n/g, "&#x0A;")
      .replace(/\u0085/g, "&#x85;")
      .replace(/\u2028/, "&#x2028;");
  }
  da(R_, "escapeElement");
  var N_ = class {
      constructor(e) {
        this.value = e;
      }
      static {
        da(this, "XmlText");
      }
      toString() {
        return R_("" + this.value);
      }
    },
    zO = class aa {
      constructor(t, r = []) {
        ((this.name = t), (this.children = r));
      }
      static {
        da(this, "XmlNode");
      }
      attributes = {};
      static of(t, r, n) {
        let s = new aa(t);
        return (
          r !== void 0 && s.addChildNode(new N_(r)),
          n !== void 0 && s.withName(n),
          s
        );
      }
      withName(t) {
        return ((this.name = t), this);
      }
      addAttribute(t, r) {
        return ((this.attributes[t] = r), this);
      }
      addChildNode(t) {
        return (this.children.push(t), this);
      }
      removeAttribute(t) {
        return (delete this.attributes[t], this);
      }
      n(t) {
        return ((this.name = t), this);
      }
      c(t) {
        return (this.children.push(t), this);
      }
      a(t, r) {
        return (r != null && (this.attributes[t] = r), this);
      }
      cc(t, r, n = r) {
        if (t[r] != null) {
          let s = aa.of(r, t[r]).withName(n);
          this.c(s);
        }
      }
      l(t, r, n, s) {
        t[r] != null &&
          s().map((i) => {
            (i.withName(n), this.c(i));
          });
      }
      lc(t, r, n, s) {
        if (t[r] != null) {
          let o = s(),
            i = new aa(n);
          (o.map((a) => {
            i.c(a);
          }),
            this.c(i));
        }
      }
      toString() {
        let t = !!this.children.length,
          r = `<${this.name}`,
          n = this.attributes;
        for (let s of Object.keys(n)) {
          let o = n[s];
          o != null && (r += ` ${s}="${A_("" + o)}"`);
        }
        return (r += t
          ? `>${this.children.map((s) => s.toString()).join("")}</${this.name}>`
          : "/>");
      }
    },
    jO = C_();
});
var O_,
  D_,
  M_,
  nn,
  ua = b(() => {
    O_ = v(la());
    et();
    we();
    ((D_ = v(Y())), (M_ = v(Oe())));
    Er();
    nn = class extends He {
      settings;
      stringDeserializer;
      constructor(t) {
        (super(), (this.settings = t), (this.stringDeserializer = new Vr(t)));
      }
      setSerdeContext(t) {
        ((this.serdeContext = t), this.stringDeserializer.setSerdeContext(t));
      }
      read(t, r, n) {
        let s = L.of(t),
          o = s.getMemberSchemas();
        if (
          s.isStructSchema() &&
          s.isMemberSchema() &&
          !!Object.values(o).find((l) => !!l.getMemberTraits().eventPayload)
        ) {
          let l = {},
            p = Object.keys(o)[0];
          return (
            o[p].isBlobSchema() ? (l[p] = r) : (l[p] = this.read(o[p], r)),
            l
          );
        }
        let a = (this.serdeContext?.utf8Encoder ?? M_.toUtf8)(r),
          d = this.parseXml(a);
        return this.readSchema(t, n ? d[n] : d);
      }
      readSchema(t, r) {
        let n = L.of(t);
        if (n.isUnitSchema()) return;
        let s = n.getMergedTraits();
        if (n.isListSchema() && !Array.isArray(r))
          return this.readSchema(n, [r]);
        if (r == null) return r;
        if (typeof r == "object") {
          let o = !!s.sparse,
            i = !!s.xmlFlattened;
          if (n.isListSchema()) {
            let d = n.getValueSchema(),
              l = [],
              p = d.getMergedTraits().xmlName ?? "member",
              m = i ? r : (r[0] ?? r)[p],
              g = Array.isArray(m) ? m : [m];
            for (let h of g) (h != null || o) && l.push(this.readSchema(d, h));
            return l;
          }
          let a = {};
          if (n.isMapSchema()) {
            let d = n.getKeySchema(),
              l = n.getValueSchema(),
              p;
            i
              ? (p = Array.isArray(r) ? r : [r])
              : (p = Array.isArray(r.entry) ? r.entry : [r.entry]);
            let m = d.getMergedTraits().xmlName ?? "key",
              g = l.getMergedTraits().xmlName ?? "value";
            for (let h of p) {
              let E = h[m],
                C = h[g];
              (C != null || o) && (a[E] = this.readSchema(l, C));
            }
            return a;
          }
          if (n.isStructSchema()) {
            for (let [d, l] of n.structIterator()) {
              let p = l.getMergedTraits(),
                m = p.httpPayload
                  ? (p.xmlName ?? l.getName())
                  : (l.getMemberTraits().xmlName ?? d);
              r[m] != null && (a[d] = this.readSchema(l, r[m]));
            }
            return a;
          }
          if (n.isDocumentSchema()) return r;
          throw new Error(
            `@aws-sdk/core/protocols - xml deserializer unhandled schema type for ${n.getName(!0)}`,
          );
        }
        return n.isListSchema()
          ? []
          : n.isMapSchema() || n.isStructSchema()
            ? {}
            : this.stringDeserializer.read(n, r);
      }
      parseXml(t) {
        if (t.length) {
          let r;
          try {
            r = (0, O_.parseXML)(t);
          } catch (i) {
            throw (
              i &&
                typeof i == "object" &&
                Object.defineProperty(i, "$responseBodyText", { value: t }),
              i
            );
          }
          let n = "#text",
            s = Object.keys(r)[0],
            o = r[s];
          return (
            o[n] && ((o[s] = o[n]), delete o[n]),
            (0, D_.getValueFromTextNode)(o)
          );
        }
        return {};
      }
    };
  });
var k_,
  F_,
  fa,
  L_ = b(() => {
    et();
    we();
    Ke();
    ((k_ = v(Y())), (F_ = v(De())));
    Er();
    fa = class extends He {
      settings;
      buffer;
      constructor(t) {
        (super(), (this.settings = t));
      }
      write(t, r, n = "") {
        this.buffer === void 0 && (this.buffer = "");
        let s = L.of(t);
        if ((n && !n.endsWith(".") && (n += "."), s.isBlobSchema()))
          (typeof r == "string" || r instanceof Uint8Array) &&
            (this.writeKey(n),
            this.writeValue(
              (this.serdeContext?.base64Encoder ?? F_.toBase64)(r),
            ));
        else if (
          s.isBooleanSchema() ||
          s.isNumericSchema() ||
          s.isStringSchema()
        )
          r != null
            ? (this.writeKey(n), this.writeValue(String(r)))
            : s.isIdempotencyToken() &&
              (this.writeKey(n), this.writeValue((0, xt.v4)()));
        else if (s.isBigIntegerSchema())
          r != null && (this.writeKey(n), this.writeValue(String(r)));
        else if (s.isBigDecimalSchema())
          r != null &&
            (this.writeKey(n),
            this.writeValue(r instanceof Ee ? r.string : String(r)));
        else if (s.isTimestampSchema()) {
          if (r instanceof Date)
            switch ((this.writeKey(n), Ze(s, this.settings))) {
              case 5:
                this.writeValue(r.toISOString().replace(".000Z", "Z"));
                break;
              case 6:
                this.writeValue((0, k_.dateToUtcString)(r));
                break;
              case 7:
                this.writeValue(String(r.getTime() / 1e3));
                break;
            }
        } else {
          if (s.isDocumentSchema())
            throw new Error(
              `@aws-sdk/core/protocols - QuerySerializer unsupported document type ${s.getName(!0)}`,
            );
          if (s.isListSchema()) {
            if (Array.isArray(r))
              if (r.length === 0)
                this.settings.serializeEmptyLists &&
                  (this.writeKey(n), this.writeValue(""));
              else {
                let o = s.getValueSchema(),
                  i =
                    this.settings.flattenLists ||
                    s.getMergedTraits().xmlFlattened,
                  a = 1;
                for (let d of r) {
                  if (d == null) continue;
                  let l = this.getKey("member", o.getMergedTraits().xmlName),
                    p = i ? `${n}${a}` : `${n}${l}.${a}`;
                  (this.write(o, d, p), ++a);
                }
              }
          } else if (s.isMapSchema()) {
            if (r && typeof r == "object") {
              let o = s.getKeySchema(),
                i = s.getValueSchema(),
                a = s.getMergedTraits().xmlFlattened,
                d = 1;
              for (let [l, p] of Object.entries(r)) {
                if (p == null) continue;
                let m = this.getKey("key", o.getMergedTraits().xmlName),
                  g = a ? `${n}${d}.${m}` : `${n}entry.${d}.${m}`,
                  h = this.getKey("value", i.getMergedTraits().xmlName),
                  E = a ? `${n}${d}.${h}` : `${n}entry.${d}.${h}`;
                (this.write(o, l, g), this.write(i, p, E), ++d);
              }
            }
          } else if (s.isStructSchema()) {
            if (r && typeof r == "object")
              for (let [o, i] of s.structIterator()) {
                if (r[o] == null && !i.isIdempotencyToken()) continue;
                let a = this.getKey(o, i.getMergedTraits().xmlName),
                  d = `${n}${a}`;
                this.write(i, r[o], d);
              }
          } else if (!s.isUnitSchema())
            throw new Error(
              `@aws-sdk/core/protocols - QuerySerializer unrecognized schema type ${s.getName(!0)}`,
            );
        }
      }
      flush() {
        if (this.buffer === void 0)
          throw new Error(
            "@aws-sdk/core/protocols - QuerySerializer cannot flush with nothing written to buffer.",
          );
        let t = this.buffer;
        return (delete this.buffer, t);
      }
      getKey(t, r) {
        let n = r ?? t;
        return this.settings.capitalizeKeys
          ? n[0].toUpperCase() + n.slice(1)
          : n;
      }
      writeKey(t) {
        (t.endsWith(".") && (t = t.slice(0, t.length - 1)),
          (this.buffer += `&${wt(t)}=`));
      }
      writeValue(t) {
        this.buffer += wt(t);
      }
    };
  });
var Us,
  Xf = b(() => {
    et();
    we();
    Mn();
    ua();
    L_();
    Us = class extends Lt {
      options;
      serializer;
      deserializer;
      mixin = new it();
      constructor(t) {
        (super({ defaultNamespace: t.defaultNamespace }), (this.options = t));
        let r = {
          timestampFormat: { useTrait: !0, default: 5 },
          httpBindings: !1,
          xmlNamespace: t.xmlNamespace,
          serviceNamespace: t.defaultNamespace,
          serializeEmptyLists: !0,
        };
        ((this.serializer = new fa(r)), (this.deserializer = new nn(r)));
      }
      getShapeId() {
        return "aws.protocols#awsQuery";
      }
      setSerdeContext(t) {
        (this.serializer.setSerdeContext(t),
          this.deserializer.setSerdeContext(t));
      }
      getPayloadCodec() {
        throw new Error("AWSQuery protocol has no payload codec.");
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n);
        (s.path.endsWith("/") || (s.path += "/"),
          Object.assign(s.headers, {
            "content-type": "application/x-www-form-urlencoded",
          }),
          (ot(t.input) === "unit" || !s.body) && (s.body = ""));
        let o = t.name.split("#")[1] ?? t.name;
        return (
          (s.body = `Action=${o}&Version=${this.options.version}` + s.body),
          s.body.endsWith("&") && (s.body = s.body.slice(-1)),
          s
        );
      }
      async deserializeResponse(t, r, n) {
        let s = this.deserializer,
          o = L.of(t.output),
          i = {};
        if (n.statusCode >= 300) {
          let m = await ht(n.body, r);
          (m.byteLength > 0 && Object.assign(i, await s.read(15, m)),
            await this.handleError(t, r, n, i, this.deserializeMetadata(n)));
        }
        for (let m in n.headers) {
          let g = n.headers[m];
          (delete n.headers[m], (n.headers[m.toLowerCase()] = g));
        }
        let a = t.name.split("#")[1] ?? t.name,
          d =
            o.isStructSchema() && this.useNestedResult()
              ? a + "Result"
              : void 0,
          l = await ht(n.body, r);
        return (
          l.byteLength > 0 && Object.assign(i, await s.read(o, l, d)),
          { $metadata: this.deserializeMetadata(n), ...i }
        );
      }
      useNestedResult() {
        return !0;
      }
      async handleError(t, r, n, s, o) {
        let i = this.loadQueryErrorCode(n, s) ?? "Unknown",
          a = this.loadQueryError(s),
          d = this.loadQueryErrorMessage(s);
        ((a.message = d),
          (a.Error = { Type: a.Type, Code: a.Code, Message: d }));
        let { errorSchema: l, errorMetadata: p } =
            await this.mixin.getErrorSchemaOrThrowBaseException(
              i,
              this.options.defaultNamespace,
              n,
              a,
              o,
              (C, I) =>
                C.find(
                  (R) => L.of(R).getMergedTraits().awsQueryError?.[0] === I,
                ),
            ),
          m = L.of(l),
          g = Te.for(l.namespace).getErrorCtor(l) ?? Error,
          h = new g(d),
          E = { Error: a.Error };
        for (let [C, I] of m.structIterator()) {
          let R = I.getMergedTraits().xmlName ?? C,
            O = a[R] ?? s[R];
          E[C] = this.deserializer.readSchema(I, O);
        }
        throw Object.assign(
          h,
          p,
          { $fault: m.getMergedTraits().error, message: d },
          E,
        );
      }
      loadQueryErrorCode(t, r) {
        let n = (r.Errors?.[0]?.Error ?? r.Errors?.Error ?? r.Error)?.Code;
        if (n !== void 0) return n;
        if (t.statusCode == 404) return "NotFound";
      }
      loadQueryError(t) {
        return t.Errors?.[0]?.Error ?? t.Errors?.Error ?? t.Error;
      }
      loadQueryErrorMessage(t) {
        let r = this.loadQueryError(t);
        return r?.message ?? r?.Message ?? t.message ?? t.Message ?? "Unknown";
      }
      getDefaultContentType() {
        return "application/x-www-form-urlencoded";
      }
    };
  });
var Qf,
  $_ = b(() => {
    Xf();
    Qf = class extends Us {
      options;
      constructor(t) {
        (super(t), (this.options = t));
        let r = {
          capitalizeKeys: !0,
          flattenLists: !0,
          serializeEmptyLists: !1,
        };
        Object.assign(this.serializer.settings, r);
      }
      useNestedResult() {
        return !1;
      }
    };
  });
var U_,
  H_,
  Hs,
  Zf,
  ep,
  tp = b(() => {
    ((U_ = v(la())), (H_ = v(Y())));
    jf();
    ((Hs = (e, t) =>
      na(e, t).then((r) => {
        if (r.length) {
          let n;
          try {
            n = (0, U_.parseXML)(r);
          } catch (a) {
            throw (
              a &&
                typeof a == "object" &&
                Object.defineProperty(a, "$responseBodyText", { value: r }),
              a
            );
          }
          let s = "#text",
            o = Object.keys(n)[0],
            i = n[o];
          return (
            i[s] && ((i[o] = i[s]), delete i[s]),
            (0, H_.getValueFromTextNode)(i)
          );
        }
        return {};
      })),
      (Zf = async (e, t) => {
        let r = await Hs(e, t);
        return (
          r.Error && (r.Error.message = r.Error.message ?? r.Error.Message),
          r
        );
      }),
      (ep = (e, t) => {
        if (t?.Error?.Code !== void 0) return t.Error.Code;
        if (t?.Code !== void 0) return t.Code;
        if (e.statusCode == 404) return "NotFound";
      }));
  });
var at,
  rp,
  pa,
  zs,
  np = b(() => {
    at = v(la());
    et();
    we();
    Ke();
    ((rp = v(Y())), (pa = v(De())));
    Er();
    zs = class extends He {
      settings;
      stringBuffer;
      byteBuffer;
      buffer;
      constructor(t) {
        (super(), (this.settings = t));
      }
      write(t, r) {
        let n = L.of(t);
        if (n.isStringSchema() && typeof r == "string") this.stringBuffer = r;
        else if (n.isBlobSchema())
          this.byteBuffer =
            "byteLength" in r
              ? r
              : (this.serdeContext?.base64Decoder ?? pa.fromBase64)(r);
        else {
          this.buffer = this.writeStruct(n, r, void 0);
          let s = n.getMergedTraits();
          s.httpPayload && !s.xmlName && this.buffer.withName(n.getName());
        }
      }
      flush() {
        if (this.byteBuffer !== void 0) {
          let r = this.byteBuffer;
          return (delete this.byteBuffer, r);
        }
        if (this.stringBuffer !== void 0) {
          let r = this.stringBuffer;
          return (delete this.stringBuffer, r);
        }
        let t = this.buffer;
        return (
          this.settings.xmlNamespace &&
            (t?.attributes?.xmlns ||
              t.addAttribute("xmlns", this.settings.xmlNamespace)),
          delete this.buffer,
          t.toString()
        );
      }
      writeStruct(t, r, n) {
        let s = t.getMergedTraits(),
          o =
            t.isMemberSchema() && !s.httpPayload
              ? (t.getMemberTraits().xmlName ?? t.getMemberName())
              : (s.xmlName ?? t.getName());
        if (!o || !t.isStructSchema())
          throw new Error(
            `@aws-sdk/core/protocols - xml serializer, cannot write struct with empty name or non-struct, schema=${t.getName(!0)}.`,
          );
        let i = at.XmlNode.of(o),
          [a, d] = this.getXmlnsAttribute(t, n);
        for (let [l, p] of t.structIterator()) {
          let m = r[l];
          if (m != null || p.isIdempotencyToken()) {
            if (p.getMergedTraits().xmlAttribute) {
              i.addAttribute(
                p.getMergedTraits().xmlName ?? l,
                this.writeSimple(p, m),
              );
              continue;
            }
            if (p.isListSchema()) this.writeList(p, m, i, d);
            else if (p.isMapSchema()) this.writeMap(p, m, i, d);
            else if (p.isStructSchema())
              i.addChildNode(this.writeStruct(p, m, d));
            else {
              let g = at.XmlNode.of(
                p.getMergedTraits().xmlName ?? p.getMemberName(),
              );
              (this.writeSimpleInto(p, m, g, d), i.addChildNode(g));
            }
          }
        }
        return (d && i.addAttribute(a, d), i);
      }
      writeList(t, r, n, s) {
        if (!t.isMemberSchema())
          throw new Error(
            `@aws-sdk/core/protocols - xml serializer, cannot write non-member list: ${t.getName(!0)}`,
          );
        let o = t.getMergedTraits(),
          i = t.getValueSchema(),
          a = i.getMergedTraits(),
          d = !!a.sparse,
          l = !!o.xmlFlattened,
          [p, m] = this.getXmlnsAttribute(t, s),
          g = (h, E) => {
            if (i.isListSchema())
              this.writeList(i, Array.isArray(E) ? E : [E], h, m);
            else if (i.isMapSchema()) this.writeMap(i, E, h, m);
            else if (i.isStructSchema()) {
              let C = this.writeStruct(i, E, m);
              h.addChildNode(
                C.withName(
                  l
                    ? (o.xmlName ?? t.getMemberName())
                    : (a.xmlName ?? "member"),
                ),
              );
            } else {
              let C = at.XmlNode.of(
                l ? (o.xmlName ?? t.getMemberName()) : (a.xmlName ?? "member"),
              );
              (this.writeSimpleInto(i, E, C, m), h.addChildNode(C));
            }
          };
        if (l) for (let h of r) (d || h != null) && g(n, h);
        else {
          let h = at.XmlNode.of(o.xmlName ?? t.getMemberName());
          m && h.addAttribute(p, m);
          for (let E of r) (d || E != null) && g(h, E);
          n.addChildNode(h);
        }
      }
      writeMap(t, r, n, s, o = !1) {
        if (!t.isMemberSchema())
          throw new Error(
            `@aws-sdk/core/protocols - xml serializer, cannot write non-member map: ${t.getName(!0)}`,
          );
        let i = t.getMergedTraits(),
          a = t.getKeySchema(),
          l = a.getMergedTraits().xmlName ?? "key",
          p = t.getValueSchema(),
          m = p.getMergedTraits(),
          g = m.xmlName ?? "value",
          h = !!m.sparse,
          E = !!i.xmlFlattened,
          [C, I] = this.getXmlnsAttribute(t, s),
          R = (O, $, j) => {
            let H = at.XmlNode.of(l, $),
              [se, Le] = this.getXmlnsAttribute(a, I);
            (Le && H.addAttribute(se, Le), O.addChildNode(H));
            let Ve = at.XmlNode.of(g);
            (p.isListSchema()
              ? this.writeList(p, j, Ve, I)
              : p.isMapSchema()
                ? this.writeMap(p, j, Ve, I, !0)
                : p.isStructSchema()
                  ? (Ve = this.writeStruct(p, j, I))
                  : this.writeSimpleInto(p, j, Ve, I),
              O.addChildNode(Ve));
          };
        if (E) {
          for (let [O, $] of Object.entries(r))
            if (h || $ != null) {
              let j = at.XmlNode.of(i.xmlName ?? t.getMemberName());
              (R(j, O, $), n.addChildNode(j));
            }
        } else {
          let O;
          o ||
            ((O = at.XmlNode.of(i.xmlName ?? t.getMemberName())),
            I && O.addAttribute(C, I),
            n.addChildNode(O));
          for (let [$, j] of Object.entries(r))
            if (h || j != null) {
              let H = at.XmlNode.of("entry");
              (R(H, $, j), (o ? n : O).addChildNode(H));
            }
        }
      }
      writeSimple(t, r) {
        if (r === null)
          throw new Error(
            "@aws-sdk/core/protocols - (XML serializer) cannot write null value.",
          );
        let n = L.of(t),
          s = null;
        if (r && typeof r == "object")
          if (n.isBlobSchema())
            s = (this.serdeContext?.base64Encoder ?? pa.toBase64)(r);
          else if (n.isTimestampSchema() && r instanceof Date)
            switch (Ze(n, this.settings)) {
              case 5:
                s = r.toISOString().replace(".000Z", "Z");
                break;
              case 6:
                s = (0, rp.dateToUtcString)(r);
                break;
              case 7:
                s = String(r.getTime() / 1e3);
                break;
              default:
                (console.warn("Missing timestamp format, using http date", r),
                  (s = (0, rp.dateToUtcString)(r)));
                break;
            }
          else {
            if (n.isBigDecimalSchema() && r)
              return r instanceof Ee ? r.string : String(r);
            throw n.isMapSchema() || n.isListSchema()
              ? new Error(
                  "@aws-sdk/core/protocols - xml serializer, cannot call _write() on List/Map schema, call writeList or writeMap() instead.",
                )
              : new Error(
                  `@aws-sdk/core/protocols - xml serializer, unhandled schema type for object value and schema: ${n.getName(!0)}`,
                );
          }
        if (
          ((n.isBooleanSchema() ||
            n.isNumericSchema() ||
            n.isBigIntegerSchema() ||
            n.isBigDecimalSchema()) &&
            (s = String(r)),
          n.isStringSchema() &&
            (r === void 0 && n.isIdempotencyToken()
              ? (s = (0, xt.v4)())
              : (s = String(r))),
          s === null)
        )
          throw new Error(`Unhandled schema-value pair ${n.getName(!0)}=${r}`);
        return s;
      }
      writeSimpleInto(t, r, n, s) {
        let o = this.writeSimple(t, r),
          i = L.of(t),
          a = new at.XmlText(o),
          [d, l] = this.getXmlnsAttribute(i, s);
        (l && n.addAttribute(d, l), n.addChildNode(a));
      }
      getXmlnsAttribute(t, r) {
        let n = t.getMergedTraits(),
          [s, o] = n.xmlNamespace ?? [];
        return o && o !== r
          ? [s ? `xmlns:${s}` : "xmlns", o]
          : [void 0, void 0];
      }
    };
  });
var js,
  sp = b(() => {
    Er();
    ua();
    np();
    js = class extends He {
      settings;
      constructor(t) {
        (super(), (this.settings = t));
      }
      createSerializer() {
        let t = new zs(this.settings);
        return (t.setSerdeContext(this.serdeContext), t);
      }
      createDeserializer() {
        let t = new nn(this.settings);
        return (t.setSerdeContext(this.serdeContext), t);
      }
    };
  });
var op,
  z_ = b(() => {
    et();
    we();
    Mn();
    tp();
    sp();
    op = class extends qr {
      codec;
      serializer;
      deserializer;
      mixin = new it();
      constructor(t) {
        super(t);
        let r = {
          timestampFormat: { useTrait: !0, default: 5 },
          httpBindings: !0,
          xmlNamespace: t.xmlNamespace,
          serviceNamespace: t.defaultNamespace,
        };
        ((this.codec = new js(r)),
          (this.serializer = new Wr(this.codec.createSerializer(), r)),
          (this.deserializer = new Gr(this.codec.createDeserializer(), r)));
      }
      getPayloadCodec() {
        return this.codec;
      }
      getShapeId() {
        return "aws.protocols#restXml";
      }
      async serializeRequest(t, r, n) {
        let s = await super.serializeRequest(t, r, n),
          o = L.of(t.input);
        if (!s.headers["content-type"]) {
          let i = this.mixin.resolveRestContentType(
            this.getDefaultContentType(),
            o,
          );
          i && (s.headers["content-type"] = i);
        }
        return (
          s.headers["content-type"] === this.getDefaultContentType() &&
            typeof s.body == "string" &&
            (s.body = '<?xml version="1.0" encoding="UTF-8"?>' + s.body),
          s
        );
      }
      async deserializeResponse(t, r, n) {
        return super.deserializeResponse(t, r, n);
      }
      async handleError(t, r, n, s, o) {
        let i = ep(n, s) ?? "Unknown",
          { errorSchema: a, errorMetadata: d } =
            await this.mixin.getErrorSchemaOrThrowBaseException(
              i,
              this.options.defaultNamespace,
              n,
              s,
              o,
            ),
          l = L.of(a),
          p =
            s.Error?.message ??
            s.Error?.Message ??
            s.message ??
            s.Message ??
            "Unknown",
          m = Te.for(a.namespace).getErrorCtor(a) ?? Error,
          g = new m(p);
        await this.deserializeHttpMessage(a, r, n, s);
        let h = {};
        for (let [E, C] of l.structIterator()) {
          let I = C.getMergedTraits().xmlName ?? E,
            R = s.Error?.[I] ?? s[I];
          h[E] = this.codec.createDeserializer().readSchema(C, R);
        }
        throw Object.assign(
          g,
          d,
          { $fault: l.getMergedTraits().error, message: p },
          h,
        );
      }
      getDefaultContentType() {
        return "application/xml";
      }
    };
  });
var j_ = b(() => {
  YE();
  XE();
  E_();
  __();
  ia();
  w_();
  oa();
  qf();
  Vf();
  x_();
  Fs();
  $_();
  Xf();
  z_();
  sp();
  ua();
  np();
  tp();
});
var Tt = {};
st(Tt, {
  AWSSDKSigV4Signer: () => Ku,
  AwsEc2QueryProtocol: () => Qf,
  AwsJson1_0Protocol: () => Gf,
  AwsJson1_1Protocol: () => Wf,
  AwsJsonRpcProtocol: () => rn,
  AwsQueryProtocol: () => Us,
  AwsRestJsonProtocol: () => Kf,
  AwsRestXmlProtocol: () => op,
  AwsSdkSigV4ASigner: () => Ps,
  AwsSdkSigV4Signer: () => Ye,
  AwsSmithyRpcV2CborProtocol: () => Pf,
  JsonCodec: () => tn,
  JsonShapeDeserializer: () => Ls,
  JsonShapeSerializer: () => $s,
  NODE_AUTH_SCHEME_PREFERENCE_OPTIONS: () => Nn,
  NODE_SIGV4A_CONFIG_OPTIONS: () => iE,
  XmlCodec: () => js,
  XmlShapeDeserializer: () => nn,
  XmlShapeSerializer: () => zs,
  _toBool: () => cO,
  _toNum: () => dO,
  _toStr: () => aO,
  awsExpectUnion: () => OO,
  emitWarningIfUnsupportedVersion: () => In,
  getBearerTokenEnvKey: () => Ui,
  loadRestJsonErrorCode: () => en,
  loadRestXmlErrorCode: () => ep,
  parseJsonBody: () => kn,
  parseJsonErrorBody: () => Bf,
  parseXmlBody: () => Hs,
  parseXmlErrorBody: () => Zf,
  resolveAWSSDKSigV4Config: () => OE,
  resolveAwsSdkSigV4AConfig: () => oE,
  resolveAwsSdkSigV4Config: () => Qr,
  setCredentialFeature: () => fr,
  setFeature: () => By,
  setTokenFeature: () => Vy,
  state: () => $i,
  validateSigningProperties: () => Rn,
});
var Ne = b(() => {
  gt();
  mf();
  j_();
});
var Ln = P((Fn) => {
  "use strict";
  var BO = (Je(), ce(vn)),
    qO = Cn(),
    VO = me(),
    Ct = (Ne(), ce(Tt)),
    G_ = void 0;
  function GO(e) {
    return e === void 0 ? !0 : typeof e == "string" && e.length <= 50;
  }
  function WO(e) {
    let t = BO.normalizeProvider(e.userAgentAppId ?? G_),
      { customUserAgent: r } = e;
    return Object.assign(e, {
      customUserAgent: typeof r == "string" ? [[r]] : r,
      userAgentAppId: async () => {
        let n = await t();
        if (!GO(n)) {
          let s =
            e.logger?.constructor?.name === "NoOpLogger" || !e.logger
              ? console
              : e.logger;
          typeof n != "string"
            ? s?.warn("userAgentAppId must be a string or undefined.")
            : n.length > 50 &&
              s?.warn(
                "The provided userAgentAppId exceeds the maximum length of 50 characters.",
              );
        }
        return n;
      },
    });
  }
  var KO = /\d{12}\.ddb/;
  async function JO(e, t, r) {
    if (
      (r.request?.headers?.["smithy-protocol"] === "rpc-v2-cbor" &&
        Ct.setFeature(e, "PROTOCOL_RPC_V2_CBOR", "M"),
      typeof t.retryStrategy == "function")
    ) {
      let o = await t.retryStrategy();
      typeof o.acquireInitialRetryToken == "function"
        ? o.constructor?.name?.includes("Adaptive")
          ? Ct.setFeature(e, "RETRY_MODE_ADAPTIVE", "F")
          : Ct.setFeature(e, "RETRY_MODE_STANDARD", "E")
        : Ct.setFeature(e, "RETRY_MODE_LEGACY", "D");
    }
    if (typeof t.accountIdEndpointMode == "function") {
      let o = e.endpointV2;
      switch (
        (String(o?.url?.hostname).match(KO) &&
          Ct.setFeature(e, "ACCOUNT_ID_ENDPOINT", "O"),
        await t.accountIdEndpointMode?.())
      ) {
        case "disabled":
          Ct.setFeature(e, "ACCOUNT_ID_MODE_DISABLED", "Q");
          break;
        case "preferred":
          Ct.setFeature(e, "ACCOUNT_ID_MODE_PREFERRED", "P");
          break;
        case "required":
          Ct.setFeature(e, "ACCOUNT_ID_MODE_REQUIRED", "R");
          break;
      }
    }
    let s = e.__smithy_context?.selectedHttpAuthScheme?.identity;
    if (s?.$source) {
      let o = s;
      o.accountId && Ct.setFeature(e, "RESOLVED_ACCOUNT_ID", "T");
      for (let [i, a] of Object.entries(o.$source ?? {}))
        Ct.setFeature(e, i, a);
    }
  }
  var B_ = "user-agent",
    ip = "x-amz-user-agent",
    q_ = " ",
    ap = "/",
    YO = /[^\!\$\%\&\'\*\+\-\.\^\_\`\|\~\d\w]/g,
    XO = /[^\!\$\%\&\'\*\+\-\.\^\_\`\|\~\d\w\#]/g,
    V_ = "-",
    QO = 1024;
  function ZO(e) {
    let t = "";
    for (let r in e) {
      let n = e[r];
      if (t.length + n.length + 1 <= QO) {
        t.length ? (t += "," + n) : (t += n);
        continue;
      }
      break;
    }
    return t;
  }
  var W_ = (e) => (t, r) => async (n) => {
      let { request: s } = n;
      if (!VO.HttpRequest.isInstance(s)) return t(n);
      let { headers: o } = s,
        i = r?.userAgent?.map(ma) || [],
        a = (await e.defaultUserAgentProvider()).map(ma);
      await JO(r, e, n);
      let d = r;
      a.push(
        `m/${ZO(Object.assign({}, r.__smithy_context?.features, d.__aws_sdk_context?.features))}`,
      );
      let l = e?.customUserAgent?.map(ma) || [],
        p = await e.userAgentAppId();
      p && a.push(ma([`app/${p}`]));
      let m = qO.getUserAgentPrefix(),
        g = (m ? [m] : []).concat([...a, ...i, ...l]).join(q_),
        h = [...a.filter((E) => E.startsWith("aws-sdk-")), ...l].join(q_);
      return (
        e.runtime !== "browser"
          ? (h && (o[ip] = o[ip] ? `${o[B_]} ${h}` : h), (o[B_] = g))
          : (o[ip] = g),
        t({ ...n, request: s })
      );
    },
    ma = (e) => {
      let t = e[0]
          .split(ap)
          .map((i) => i.replace(YO, V_))
          .join(ap),
        r = e[1]?.replace(XO, V_),
        n = t.indexOf(ap),
        s = t.substring(0, n),
        o = t.substring(n + 1);
      return (
        s === "api" && (o = o.toLowerCase()),
        [s, o, r]
          .filter((i) => i && i.length > 0)
          .reduce((i, a, d) => {
            switch (d) {
              case 0:
                return a;
              case 1:
                return `${i}/${a}`;
              default:
                return `${i}#${a}`;
            }
          }, "")
      );
    },
    K_ = {
      name: "getUserAgentMiddleware",
      step: "build",
      priority: "low",
      tags: ["SET_USER_AGENT", "USER_AGENT"],
      override: !0,
    },
    eD = (e) => ({
      applyToStack: (t) => {
        t.add(W_(e), K_);
      },
    });
  Fn.DEFAULT_UA_APP_ID = G_;
  Fn.getUserAgentMiddlewareOptions = K_;
  Fn.getUserAgentPlugin = eD;
  Fn.resolveUserAgentConfig = WO;
  Fn.userAgentMiddleware = W_;
});
var J_ = P(($n) => {
  "use strict";
  var tD = (e, t, r) => {
      if (t in e) {
        if (e[t] === "true") return !0;
        if (e[t] === "false") return !1;
        throw new Error(
          `Cannot load ${r} "${t}". Expected "true" or "false", got ${e[t]}.`,
        );
      }
    },
    rD = (e, t, r) => {
      if (!(t in e)) return;
      let n = parseInt(e[t], 10);
      if (Number.isNaN(n))
        throw new TypeError(
          `Cannot load ${r} '${t}'. Expected number, got '${e[t]}'.`,
        );
      return n;
    };
  $n.SelectorType = void 0;
  (function (e) {
    ((e.ENV = "env"), (e.CONFIG = "shared config entry"));
  })($n.SelectorType || ($n.SelectorType = {}));
  $n.booleanSelector = tD;
  $n.numberSelector = rD;
});
var It = P((Me) => {
  "use strict";
  var wr = J_(),
    ha = Ge(),
    Q_ = "AWS_USE_DUALSTACK_ENDPOINT",
    Z_ = "use_dualstack_endpoint",
    nD = !1,
    sD = {
      environmentVariableSelector: (e) =>
        wr.booleanSelector(e, Q_, wr.SelectorType.ENV),
      configFileSelector: (e) =>
        wr.booleanSelector(e, Z_, wr.SelectorType.CONFIG),
      default: !1,
    },
    ew = "AWS_USE_FIPS_ENDPOINT",
    tw = "use_fips_endpoint",
    oD = !1,
    iD = {
      environmentVariableSelector: (e) =>
        wr.booleanSelector(e, ew, wr.SelectorType.ENV),
      configFileSelector: (e) =>
        wr.booleanSelector(e, tw, wr.SelectorType.CONFIG),
      default: !1,
    },
    aD = (e) => {
      let { tls: t, endpoint: r, urlParser: n, useDualstackEndpoint: s } = e;
      return Object.assign(e, {
        tls: t ?? !0,
        endpoint: ha.normalizeProvider(typeof r == "string" ? n(r) : r),
        isCustomEndpoint: !0,
        useDualstackEndpoint: ha.normalizeProvider(s ?? !1),
      });
    },
    cD = async (e) => {
      let { tls: t = !0 } = e,
        r = await e.region();
      if (
        !new RegExp(
          /^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/,
        ).test(r)
      )
        throw new Error("Invalid region in client config");
      let s = await e.useDualstackEndpoint(),
        o = await e.useFipsEndpoint(),
        { hostname: i } =
          (await e.regionInfoProvider(r, {
            useDualstackEndpoint: s,
            useFipsEndpoint: o,
          })) ?? {};
      if (!i) throw new Error("Cannot resolve hostname from client config");
      return e.urlParser(`${t ? "https:" : "http:"}//${i}`);
    },
    dD = (e) => {
      let t = ha.normalizeProvider(e.useDualstackEndpoint ?? !1),
        { endpoint: r, useFipsEndpoint: n, urlParser: s, tls: o } = e;
      return Object.assign(e, {
        tls: o ?? !0,
        endpoint: r
          ? ha.normalizeProvider(typeof r == "string" ? s(r) : r)
          : () => cD({ ...e, useDualstackEndpoint: t, useFipsEndpoint: n }),
        isCustomEndpoint: !!r,
        useDualstackEndpoint: t,
      });
    },
    rw = "AWS_REGION",
    nw = "region",
    lD = {
      environmentVariableSelector: (e) => e[rw],
      configFileSelector: (e) => e[nw],
      default: () => {
        throw new Error("Region is missing");
      },
    },
    uD = { preferredFile: "credentials" },
    sw = (e) =>
      typeof e == "string" && (e.startsWith("fips-") || e.endsWith("-fips")),
    Y_ = (e) =>
      sw(e)
        ? ["fips-aws-global", "aws-fips"].includes(e)
          ? "us-east-1"
          : e.replace(/fips-(dkr-|prod-)?|-fips/, "")
        : e,
    fD = (e) => {
      let { region: t, useFipsEndpoint: r } = e;
      if (!t) throw new Error("Region is missing");
      return Object.assign(e, {
        region: async () => {
          if (typeof t == "string") return Y_(t);
          let n = await t();
          return Y_(n);
        },
        useFipsEndpoint: async () => {
          let n = typeof t == "string" ? t : await t();
          return sw(n)
            ? !0
            : typeof r != "function"
              ? Promise.resolve(!!r)
              : r();
        },
      });
    },
    X_ = (e = [], { useFipsEndpoint: t, useDualstackEndpoint: r }) =>
      e.find(
        ({ tags: n }) =>
          t === n.includes("fips") && r === n.includes("dualstack"),
      )?.hostname,
    pD = (e, { regionHostname: t, partitionHostname: r }) =>
      t || (r ? r.replace("{region}", e) : void 0),
    mD = (e, { partitionHash: t }) =>
      Object.keys(t || {}).find((r) => t[r].regions.includes(e)) ?? "aws",
    hD = (e, { signingRegion: t, regionRegex: r, useFipsEndpoint: n }) => {
      if (t) return t;
      if (n) {
        let s = r
            .replace("\\\\", "\\")
            .replace(/^\^/g, "\\.")
            .replace(/\$$/g, "\\."),
          o = e.match(s);
        if (o) return o[0].slice(1, -1);
      }
    },
    gD = (
      e,
      {
        useFipsEndpoint: t = !1,
        useDualstackEndpoint: r = !1,
        signingService: n,
        regionHash: s,
        partitionHash: o,
      },
    ) => {
      let i = mD(e, { partitionHash: o }),
        a = e in s ? e : (o[i]?.endpoint ?? e),
        d = { useFipsEndpoint: t, useDualstackEndpoint: r },
        l = X_(s[a]?.variants, d),
        p = X_(o[i]?.variants, d),
        m = pD(a, { regionHostname: l, partitionHostname: p });
      if (m === void 0)
        throw new Error(
          `Endpoint resolution failed for: ${{ resolvedRegion: a, useFipsEndpoint: t, useDualstackEndpoint: r }}`,
        );
      let g = hD(m, {
        signingRegion: s[a]?.signingRegion,
        regionRegex: o[i].regionRegex,
        useFipsEndpoint: t,
      });
      return {
        partition: i,
        signingService: n,
        hostname: m,
        ...(g && { signingRegion: g }),
        ...(s[a]?.signingService && { signingService: s[a].signingService }),
      };
    };
  Me.CONFIG_USE_DUALSTACK_ENDPOINT = Z_;
  Me.CONFIG_USE_FIPS_ENDPOINT = tw;
  Me.DEFAULT_USE_DUALSTACK_ENDPOINT = nD;
  Me.DEFAULT_USE_FIPS_ENDPOINT = oD;
  Me.ENV_USE_DUALSTACK_ENDPOINT = Q_;
  Me.ENV_USE_FIPS_ENDPOINT = ew;
  Me.NODE_REGION_CONFIG_FILE_OPTIONS = uD;
  Me.NODE_REGION_CONFIG_OPTIONS = lD;
  Me.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS = sD;
  Me.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS = iD;
  Me.REGION_ENV_NAME = rw;
  Me.REGION_INI_NAME = nw;
  Me.getRegionInfo = gD;
  Me.resolveCustomEndpointsConfig = aD;
  Me.resolveEndpointsConfig = dD;
  Me.resolveRegionConfig = fD;
});
var Bs = P((ga) => {
  "use strict";
  var SD = me(),
    ow = "content-length";
  function iw(e) {
    return (t) => async (r) => {
      let n = r.request;
      if (SD.HttpRequest.isInstance(n)) {
        let { body: s, headers: o } = n;
        if (
          s &&
          Object.keys(o)
            .map((i) => i.toLowerCase())
            .indexOf(ow) === -1
        )
          try {
            let i = e(s);
            n.headers = { ...n.headers, [ow]: String(i) };
          } catch {}
      }
      return t({ ...r, request: n });
    };
  }
  var aw = {
      step: "build",
      tags: ["SET_CONTENT_LENGTH", "CONTENT_LENGTH"],
      name: "contentLengthMiddleware",
      override: !0,
    },
    yD = (e) => ({
      applyToStack: (t) => {
        t.add(iw(e.bodyLengthChecker), aw);
      },
    });
  ga.contentLengthMiddleware = iw;
  ga.contentLengthMiddlewareOptions = aw;
  ga.getContentLengthPlugin = yD;
});
var dp = P((Sa) => {
  "use strict";
  Object.defineProperty(Sa, "__esModule", { value: !0 });
  Sa.getHomeDir = void 0;
  var ED = require("os"),
    _D = require("path"),
    cp = {},
    wD = () =>
      process && process.geteuid ? `${process.geteuid()}` : "DEFAULT",
    bD = () => {
      let {
        HOME: e,
        USERPROFILE: t,
        HOMEPATH: r,
        HOMEDRIVE: n = `C:${_D.sep}`,
      } = process.env;
      if (e) return e;
      if (t) return t;
      if (r) return `${n}${r}`;
      let s = wD();
      return (cp[s] || (cp[s] = (0, ED.homedir)()), cp[s]);
    };
  Sa.getHomeDir = bD;
});
var lp = P((ya) => {
  "use strict";
  Object.defineProperty(ya, "__esModule", { value: !0 });
  ya.getSSOTokenFilepath = void 0;
  var xD = require("crypto"),
    vD = require("path"),
    TD = dp(),
    CD = (e) => {
      let r = (0, xD.createHash)("sha1").update(e).digest("hex");
      return (0, vD.join)(
        (0, TD.getHomeDir)(),
        ".aws",
        "sso",
        "cache",
        `${r}.json`,
      );
    };
  ya.getSSOTokenFilepath = CD;
});
var cw = P((br) => {
  "use strict";
  Object.defineProperty(br, "__esModule", { value: !0 });
  br.getSSOTokenFromFile = br.tokenIntercept = void 0;
  var ID = require("fs"),
    AD = lp(),
    { readFile: RD } = ID.promises;
  br.tokenIntercept = {};
  var ND = async (e) => {
    if (br.tokenIntercept[e]) return br.tokenIntercept[e];
    let t = (0, AD.getSSOTokenFilepath)(e),
      r = await RD(t, "utf8");
    return JSON.parse(r);
  };
  br.getSSOTokenFromFile = ND;
});
var dw = P((tt) => {
  "use strict";
  Object.defineProperty(tt, "__esModule", { value: !0 });
  tt.slurpFile = tt.fileIntercept = tt.filePromisesHash = void 0;
  var PD = require("fs"),
    { readFile: OD } = PD.promises;
  tt.filePromisesHash = {};
  tt.fileIntercept = {};
  var DD = (e, t) =>
    tt.fileIntercept[e] !== void 0
      ? tt.fileIntercept[e]
      : ((!tt.filePromisesHash[e] || t?.ignoreCache) &&
          (tt.filePromisesHash[e] = OD(e, "utf8")),
        tt.filePromisesHash[e]);
  tt.slurpFile = DD;
});
var qt = P((Xe) => {
  "use strict";
  var qs = dp(),
    lw = lp(),
    up = cw(),
    Ea = require("path"),
    _a = rr(),
    Vs = dw(),
    fw = "AWS_PROFILE",
    pw = "default",
    MD = (e) => e.profile || process.env[fw] || pw,
    kD = (e) =>
      Object.entries(e)
        .filter(([t]) => {
          let r = t.indexOf(sn);
          return r === -1
            ? !1
            : Object.values(_a.IniSectionType).includes(t.substring(0, r));
        })
        .reduce(
          (t, [r, n]) => {
            let s = r.indexOf(sn),
              o =
                r.substring(0, s) === _a.IniSectionType.PROFILE
                  ? r.substring(s + 1)
                  : r;
            return ((t[o] = n), t);
          },
          { ...(e.default && { default: e.default }) },
        ),
    FD = "AWS_CONFIG_FILE",
    mw = () => process.env[FD] || Ea.join(qs.getHomeDir(), ".aws", "config"),
    LD = "AWS_SHARED_CREDENTIALS_FILE",
    $D = () =>
      process.env[LD] || Ea.join(qs.getHomeDir(), ".aws", "credentials"),
    UD = /^([\w-]+)\s(["'])?([\w-@\+\.%:/]+)\2$/,
    HD = ["__proto__", "profile __proto__"],
    fp = (e) => {
      let t = {},
        r,
        n;
      for (let s of e.split(/\r?\n/)) {
        let o = s.split(/(^|\s)[;#]/)[0].trim();
        if (o[0] === "[" && o[o.length - 1] === "]") {
          ((r = void 0), (n = void 0));
          let a = o.substring(1, o.length - 1),
            d = UD.exec(a);
          if (d) {
            let [, l, , p] = d;
            Object.values(_a.IniSectionType).includes(l) &&
              (r = [l, p].join(sn));
          } else r = a;
          if (HD.includes(a))
            throw new Error(`Found invalid profile name "${a}"`);
        } else if (r) {
          let a = o.indexOf("=");
          if (![0, -1].includes(a)) {
            let [d, l] = [o.substring(0, a).trim(), o.substring(a + 1).trim()];
            if (l === "") n = d;
            else {
              (n && s.trimStart() === s && (n = void 0), (t[r] = t[r] || {}));
              let p = n ? [n, d].join(sn) : d;
              t[r][p] = l;
            }
          }
        }
      }
      return t;
    },
    uw = () => ({}),
    sn = ".",
    hw = async (e = {}) => {
      let { filepath: t = $D(), configFilepath: r = mw() } = e,
        n = qs.getHomeDir(),
        s = "~/",
        o = t;
      t.startsWith(s) && (o = Ea.join(n, t.slice(2)));
      let i = r;
      r.startsWith(s) && (i = Ea.join(n, r.slice(2)));
      let a = await Promise.all([
        Vs.slurpFile(i, { ignoreCache: e.ignoreCache })
          .then(fp)
          .then(kD)
          .catch(uw),
        Vs.slurpFile(o, { ignoreCache: e.ignoreCache }).then(fp).catch(uw),
      ]);
      return { configFile: a[0], credentialsFile: a[1] };
    },
    zD = (e) =>
      Object.entries(e)
        .filter(([t]) => t.startsWith(_a.IniSectionType.SSO_SESSION + sn))
        .reduce(
          (t, [r, n]) => ({ ...t, [r.substring(r.indexOf(sn) + 1)]: n }),
          {},
        ),
    jD = () => ({}),
    BD = async (e = {}) =>
      Vs.slurpFile(e.configFilepath ?? mw())
        .then(fp)
        .then(zD)
        .catch(jD),
    qD = (...e) => {
      let t = {};
      for (let r of e)
        for (let [n, s] of Object.entries(r))
          t[n] !== void 0 ? Object.assign(t[n], s) : (t[n] = s);
      return t;
    },
    VD = async (e) => {
      let t = await hw(e);
      return qD(t.configFile, t.credentialsFile);
    },
    GD = {
      getFileRecord() {
        return Vs.fileIntercept;
      },
      interceptFile(e, t) {
        Vs.fileIntercept[e] = Promise.resolve(t);
      },
      getTokenRecord() {
        return up.tokenIntercept;
      },
      interceptToken(e, t) {
        up.tokenIntercept[e] = t;
      },
    };
  Object.defineProperty(Xe, "getSSOTokenFromFile", {
    enumerable: !0,
    get: function () {
      return up.getSSOTokenFromFile;
    },
  });
  Xe.CONFIG_PREFIX_SEPARATOR = sn;
  Xe.DEFAULT_PROFILE = pw;
  Xe.ENV_PROFILE = fw;
  Xe.externalDataInterceptor = GD;
  Xe.getProfileName = MD;
  Xe.loadSharedConfigFiles = hw;
  Xe.loadSsoSessionData = BD;
  Xe.parseKnownFiles = VD;
  Object.keys(qs).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Xe, e) &&
      Object.defineProperty(Xe, e, {
        enumerable: !0,
        get: function () {
          return qs[e];
        },
      });
  });
  Object.keys(lw).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Xe, e) &&
      Object.defineProperty(Xe, e, {
        enumerable: !0,
        get: function () {
          return lw[e];
        },
      });
  });
});
var xr = P((yw) => {
  "use strict";
  var Gs = qe(),
    gw = qt();
  function Sw(e) {
    try {
      let t = new Set(Array.from(e.match(/([A-Z_]){3,}/g) ?? []));
      return (
        t.delete("CONFIG"),
        t.delete("CONFIG_PREFIX_SEPARATOR"),
        t.delete("ENV"),
        [...t].join(", ")
      );
    } catch {
      return e;
    }
  }
  var WD = (e, t) => async () => {
      try {
        let r = e(process.env, t);
        if (r === void 0) throw new Error();
        return r;
      } catch (r) {
        throw new Gs.CredentialsProviderError(
          r.message || `Not found in ENV: ${Sw(e.toString())}`,
          { logger: t?.logger },
        );
      }
    },
    KD =
      (e, { preferredFile: t = "config", ...r } = {}) =>
      async () => {
        let n = gw.getProfileName(r),
          { configFile: s, credentialsFile: o } =
            await gw.loadSharedConfigFiles(r),
          i = o[n] || {},
          a = s[n] || {},
          d = t === "config" ? { ...i, ...a } : { ...a, ...i };
        try {
          let p = e(d, t === "config" ? s : o);
          if (p === void 0) throw new Error();
          return p;
        } catch (l) {
          throw new Gs.CredentialsProviderError(
            l.message ||
              `Not found in config files w/ profile [${n}]: ${Sw(e.toString())}`,
            { logger: r.logger },
          );
        }
      },
    JD = (e) => typeof e == "function",
    YD = (e) => (JD(e) ? async () => await e() : Gs.fromStatic(e)),
    XD = (
      { environmentVariableSelector: e, configFileSelector: t, default: r },
      n = {},
    ) => {
      let { signingName: s, logger: o } = n,
        i = { signingName: s, logger: o };
      return Gs.memoize(Gs.chain(WD(e, i), KD(t, n), YD(r)));
    };
  yw.loadConfig = XD;
});
var bw = P((wa) => {
  "use strict";
  Object.defineProperty(wa, "__esModule", { value: !0 });
  wa.getEndpointUrlConfig = void 0;
  var Ew = qt(),
    _w = "AWS_ENDPOINT_URL",
    ww = "endpoint_url",
    QD = (e) => ({
      environmentVariableSelector: (t) => {
        let r = e.split(" ").map((o) => o.toUpperCase()),
          n = t[[_w, ...r].join("_")];
        if (n) return n;
        let s = t[_w];
        if (s) return s;
      },
      configFileSelector: (t, r) => {
        if (r && t.services) {
          let s = r[["services", t.services].join(Ew.CONFIG_PREFIX_SEPARATOR)];
          if (s) {
            let o = e.split(" ").map((a) => a.toLowerCase()),
              i = s[[o.join("_"), ww].join(Ew.CONFIG_PREFIX_SEPARATOR)];
            if (i) return i;
          }
        }
        let n = t[ww];
        if (n) return n;
      },
      default: void 0,
    });
  wa.getEndpointUrlConfig = QD;
});
var xw = P((ba) => {
  "use strict";
  Object.defineProperty(ba, "__esModule", { value: !0 });
  ba.getEndpointFromConfig = void 0;
  var ZD = xr(),
    eM = bw(),
    tM = async (e) =>
      (0, ZD.loadConfig)((0, eM.getEndpointUrlConfig)(e ?? ""))();
  ba.getEndpointFromConfig = tM;
});
var vr = P((Vt) => {
  "use strict";
  var Tw = xw(),
    vw = lr(),
    rM = (Je(), ce(vn)),
    xa = Ge(),
    nM = sr(),
    sM = async (e) => {
      let t = e?.Bucket || "";
      if (
        (typeof e.Bucket == "string" &&
          (e.Bucket = t
            .replace(/#/g, encodeURIComponent("#"))
            .replace(/\?/g, encodeURIComponent("?"))),
        dM(t))
      ) {
        if (e.ForcePathStyle === !0)
          throw new Error(
            "Path-style addressing cannot be used with ARN buckets",
          );
      } else
        (!cM(t) ||
          (t.indexOf(".") !== -1 && !String(e.Endpoint).startsWith("http:")) ||
          t.toLowerCase() !== t ||
          t.length < 3) &&
          (e.ForcePathStyle = !0);
      return (
        e.DisableMultiRegionAccessPoints &&
          ((e.disableMultiRegionAccessPoints = !0), (e.DisableMRAP = !0)),
        e
      );
    },
    oM = /^[a-z0-9][a-z0-9\.\-]{1,61}[a-z0-9]$/,
    iM = /(\d+\.){3}\d+/,
    aM = /\.\./,
    cM = (e) => oM.test(e) && !iM.test(e) && !aM.test(e),
    dM = (e) => {
      let [t, r, n, , , s] = e.split(":"),
        o = t === "arn" && e.split(":").length >= 6,
        i = !!(o && r && n && s);
      if (o && !i) throw new Error(`Invalid ARN: ${e} was an invalid ARN.`);
      return i;
    },
    lM = (e, t, r) => {
      let n = async () => {
        let s = r[e] ?? r[t];
        return typeof s == "function" ? s() : s;
      };
      return e === "credentialScope" || t === "CredentialScope"
        ? async () => {
            let s =
              typeof r.credentials == "function"
                ? await r.credentials()
                : r.credentials;
            return s?.credentialScope ?? s?.CredentialScope;
          }
        : e === "accountId" || t === "AccountId"
          ? async () => {
              let s =
                typeof r.credentials == "function"
                  ? await r.credentials()
                  : r.credentials;
              return s?.accountId ?? s?.AccountId;
            }
          : e === "endpoint" || t === "endpoint"
            ? async () => {
                if (r.isCustomEndpoint === !1) return;
                let s = await n();
                if (s && typeof s == "object") {
                  if ("url" in s) return s.url.href;
                  if ("hostname" in s) {
                    let { protocol: o, hostname: i, port: a, path: d } = s;
                    return `${o}//${i}${a ? ":" + a : ""}${d}`;
                  }
                }
                return s;
              }
            : n;
    },
    pp = (e) =>
      typeof e == "object"
        ? "url" in e
          ? vw.parseUrl(e.url)
          : e
        : vw.parseUrl(e),
    Cw = async (e, t, r, n) => {
      if (!r.isCustomEndpoint) {
        let i;
        (r.serviceConfiguredEndpoint
          ? (i = await r.serviceConfiguredEndpoint())
          : (i = await Tw.getEndpointFromConfig(r.serviceId)),
          i &&
            ((r.endpoint = () => Promise.resolve(pp(i))),
            (r.isCustomEndpoint = !0)));
      }
      let s = await Iw(e, t, r);
      if (typeof r.endpointProvider != "function")
        throw new Error("config.endpointProvider is not set.");
      return r.endpointProvider(s, n);
    },
    Iw = async (e, t, r) => {
      let n = {},
        s = t?.getEndpointParameterInstructions?.() || {};
      for (let [o, i] of Object.entries(s))
        switch (i.type) {
          case "staticContextParams":
            n[o] = i.value;
            break;
          case "contextParams":
            n[o] = e[i.name];
            break;
          case "clientContextParams":
          case "builtInParams":
            n[o] = await lM(i.name, o, r)();
            break;
          case "operationContextParams":
            n[o] = i.get(e);
            break;
          default:
            throw new Error(
              "Unrecognized endpoint parameter instruction: " +
                JSON.stringify(i),
            );
        }
      return (
        Object.keys(s).length === 0 && Object.assign(n, r),
        String(r.serviceId).toLowerCase() === "s3" && (await sM(n)),
        n
      );
    },
    Aw =
      ({ config: e, instructions: t }) =>
      (r, n) =>
      async (s) => {
        e.isCustomEndpoint && rM.setFeature(n, "ENDPOINT_OVERRIDE", "N");
        let o = await Cw(
          s.input,
          {
            getEndpointParameterInstructions() {
              return t;
            },
          },
          { ...e },
          n,
        );
        ((n.endpointV2 = o), (n.authSchemes = o.properties?.authSchemes));
        let i = n.authSchemes?.[0];
        if (i) {
          ((n.signing_region = i.signingRegion),
            (n.signing_service = i.signingName));
          let d =
            xa.getSmithyContext(n)?.selectedHttpAuthScheme?.httpAuthOption;
          d &&
            (d.signingProperties = Object.assign(
              d.signingProperties || {},
              {
                signing_region: i.signingRegion,
                signingRegion: i.signingRegion,
                signing_service: i.signingName,
                signingName: i.signingName,
                signingRegionSet: i.signingRegionSet,
              },
              i.properties,
            ));
        }
        return r({ ...s });
      },
    Rw = {
      step: "serialize",
      tags: ["ENDPOINT_PARAMETERS", "ENDPOINT_V2", "ENDPOINT"],
      name: "endpointV2Middleware",
      override: !0,
      relation: "before",
      toMiddleware: nM.serializerMiddlewareOption.name,
    },
    uM = (e, t) => ({
      applyToStack: (r) => {
        r.addRelativeTo(Aw({ config: e, instructions: t }), Rw);
      },
    }),
    fM = (e) => {
      let t = e.tls ?? !0,
        { endpoint: r, useDualstackEndpoint: n, useFipsEndpoint: s } = e,
        o =
          r != null ? async () => pp(await xa.normalizeProvider(r)()) : void 0,
        a = Object.assign(e, {
          endpoint: o,
          tls: t,
          isCustomEndpoint: !!r,
          useDualstackEndpoint: xa.normalizeProvider(n ?? !1),
          useFipsEndpoint: xa.normalizeProvider(s ?? !1),
        }),
        d;
      return (
        (a.serviceConfiguredEndpoint = async () => (
          e.serviceId && !d && (d = Tw.getEndpointFromConfig(e.serviceId)),
          d
        )),
        a
      );
    },
    pM = (e) => {
      let { endpoint: t } = e;
      return (
        t === void 0 &&
          (e.endpoint = async () => {
            throw new Error(
              "@smithy/middleware-endpoint: (default endpointRuleSet) endpoint is not set - you must configure an endpoint.",
            );
          }),
        e
      );
    };
  Vt.endpointMiddleware = Aw;
  Vt.endpointMiddlewareOptions = Rw;
  Vt.getEndpointFromInstructions = Cw;
  Vt.getEndpointPlugin = uM;
  Vt.resolveEndpointConfig = fM;
  Vt.resolveEndpointRequiredConfig = pM;
  Vt.resolveParams = Iw;
  Vt.toEndpointV1 = pp;
});
var hp = P((Tr) => {
  "use strict";
  var mM = [
      "AuthFailure",
      "InvalidSignatureException",
      "RequestExpired",
      "RequestInTheFuture",
      "RequestTimeTooSkewed",
      "SignatureDoesNotMatch",
    ],
    hM = [
      "BandwidthLimitExceeded",
      "EC2ThrottledException",
      "LimitExceededException",
      "PriorRequestNotComplete",
      "ProvisionedThroughputExceededException",
      "RequestLimitExceeded",
      "RequestThrottled",
      "RequestThrottledException",
      "SlowDown",
      "ThrottledException",
      "Throttling",
      "ThrottlingException",
      "TooManyRequestsException",
      "TransactionInProgressException",
    ],
    gM = ["TimeoutError", "RequestTimeout", "RequestTimeoutException"],
    SM = [500, 502, 503, 504],
    yM = ["ECONNRESET", "ECONNREFUSED", "EPIPE", "ETIMEDOUT"],
    EM = ["EHOSTUNREACH", "ENETUNREACH", "ENOTFOUND"],
    Nw = (e) => e?.$retryable !== void 0,
    _M = (e) => mM.includes(e.name),
    Pw = (e) => e.$metadata?.clockSkewCorrected,
    Ow = (e) => {
      let t = new Set([
        "Failed to fetch",
        "NetworkError when attempting to fetch resource",
        "The Internet connection appears to be offline",
        "Load failed",
        "Network request failed",
      ]);
      return e && e instanceof TypeError ? t.has(e.message) : !1;
    },
    wM = (e) =>
      e.$metadata?.httpStatusCode === 429 ||
      hM.includes(e.name) ||
      e.$retryable?.throttling == !0,
    mp = (e, t = 0) =>
      Nw(e) ||
      Pw(e) ||
      gM.includes(e.name) ||
      yM.includes(e?.code || "") ||
      EM.includes(e?.code || "") ||
      SM.includes(e.$metadata?.httpStatusCode || 0) ||
      Ow(e) ||
      (e.cause !== void 0 && t <= 10 && mp(e.cause, t + 1)),
    bM = (e) => {
      if (e.$metadata?.httpStatusCode !== void 0) {
        let t = e.$metadata.httpStatusCode;
        return 500 <= t && t <= 599 && !mp(e);
      }
      return !1;
    };
  Tr.isBrowserNetworkError = Ow;
  Tr.isClockSkewCorrectedError = Pw;
  Tr.isClockSkewError = _M;
  Tr.isRetryableByTrait = Nw;
  Tr.isServerError = bM;
  Tr.isThrottlingError = wM;
  Tr.isTransientError = mp;
});
var Un = P((be) => {
  "use strict";
  var xM = hp();
  be.RETRY_MODES = void 0;
  (function (e) {
    ((e.STANDARD = "standard"), (e.ADAPTIVE = "adaptive"));
  })(be.RETRY_MODES || (be.RETRY_MODES = {}));
  var gp = 3,
    vM = be.RETRY_MODES.STANDARD,
    va = class e {
      static setTimeoutFn = setTimeout;
      beta;
      minCapacity;
      minFillRate;
      scaleConstant;
      smooth;
      currentCapacity = 0;
      enabled = !1;
      lastMaxRate = 0;
      measuredTxRate = 0;
      requestCount = 0;
      fillRate;
      lastThrottleTime;
      lastTimestamp = 0;
      lastTxRateBucket;
      maxCapacity;
      timeWindow = 0;
      constructor(t) {
        ((this.beta = t?.beta ?? 0.7),
          (this.minCapacity = t?.minCapacity ?? 1),
          (this.minFillRate = t?.minFillRate ?? 0.5),
          (this.scaleConstant = t?.scaleConstant ?? 0.4),
          (this.smooth = t?.smooth ?? 0.8));
        let r = this.getCurrentTimeInSeconds();
        ((this.lastThrottleTime = r),
          (this.lastTxRateBucket = Math.floor(this.getCurrentTimeInSeconds())),
          (this.fillRate = this.minFillRate),
          (this.maxCapacity = this.minCapacity));
      }
      getCurrentTimeInSeconds() {
        return Date.now() / 1e3;
      }
      async getSendToken() {
        return this.acquireTokenBucket(1);
      }
      async acquireTokenBucket(t) {
        if (this.enabled) {
          if ((this.refillTokenBucket(), t > this.currentCapacity)) {
            let r = ((t - this.currentCapacity) / this.fillRate) * 1e3;
            await new Promise((n) => e.setTimeoutFn(n, r));
          }
          this.currentCapacity = this.currentCapacity - t;
        }
      }
      refillTokenBucket() {
        let t = this.getCurrentTimeInSeconds();
        if (!this.lastTimestamp) {
          this.lastTimestamp = t;
          return;
        }
        let r = (t - this.lastTimestamp) * this.fillRate;
        ((this.currentCapacity = Math.min(
          this.maxCapacity,
          this.currentCapacity + r,
        )),
          (this.lastTimestamp = t));
      }
      updateClientSendingRate(t) {
        let r;
        if ((this.updateMeasuredRate(), xM.isThrottlingError(t))) {
          let s = this.enabled
            ? Math.min(this.measuredTxRate, this.fillRate)
            : this.measuredTxRate;
          ((this.lastMaxRate = s),
            this.calculateTimeWindow(),
            (this.lastThrottleTime = this.getCurrentTimeInSeconds()),
            (r = this.cubicThrottle(s)),
            this.enableTokenBucket());
        } else
          (this.calculateTimeWindow(),
            (r = this.cubicSuccess(this.getCurrentTimeInSeconds())));
        let n = Math.min(r, 2 * this.measuredTxRate);
        this.updateTokenBucketRate(n);
      }
      calculateTimeWindow() {
        this.timeWindow = this.getPrecise(
          Math.pow(
            (this.lastMaxRate * (1 - this.beta)) / this.scaleConstant,
            1 / 3,
          ),
        );
      }
      cubicThrottle(t) {
        return this.getPrecise(t * this.beta);
      }
      cubicSuccess(t) {
        return this.getPrecise(
          this.scaleConstant *
            Math.pow(t - this.lastThrottleTime - this.timeWindow, 3) +
            this.lastMaxRate,
        );
      }
      enableTokenBucket() {
        this.enabled = !0;
      }
      updateTokenBucketRate(t) {
        (this.refillTokenBucket(),
          (this.fillRate = Math.max(t, this.minFillRate)),
          (this.maxCapacity = Math.max(t, this.minCapacity)),
          (this.currentCapacity = Math.min(
            this.currentCapacity,
            this.maxCapacity,
          )));
      }
      updateMeasuredRate() {
        let t = this.getCurrentTimeInSeconds(),
          r = Math.floor(t * 2) / 2;
        if ((this.requestCount++, r > this.lastTxRateBucket)) {
          let n = this.requestCount / (r - this.lastTxRateBucket);
          ((this.measuredTxRate = this.getPrecise(
            n * this.smooth + this.measuredTxRate * (1 - this.smooth),
          )),
            (this.requestCount = 0),
            (this.lastTxRateBucket = r));
        }
      }
      getPrecise(t) {
        return parseFloat(t.toFixed(8));
      }
    },
    Ws = 100,
    _p = 20 * 1e3,
    Mw = 500,
    Sp = 500,
    kw = 5,
    Fw = 10,
    Lw = 1,
    TM = "amz-sdk-invocation-id",
    CM = "amz-sdk-request",
    IM = () => {
      let e = Ws;
      return {
        computeNextBackoffDelay: (n) =>
          Math.floor(Math.min(_p, Math.random() * 2 ** n * e)),
        setDelayBase: (n) => {
          e = n;
        },
      };
    },
    Dw = ({ retryDelay: e, retryCount: t, retryCost: r }) => ({
      getRetryCount: () => t,
      getRetryDelay: () => Math.min(_p, e),
      getRetryCost: () => r,
    }),
    Ks = class {
      maxAttempts;
      mode = be.RETRY_MODES.STANDARD;
      capacity = Sp;
      retryBackoffStrategy = IM();
      maxAttemptsProvider;
      constructor(t) {
        ((this.maxAttempts = t),
          (this.maxAttemptsProvider =
            typeof t == "function" ? t : async () => t));
      }
      async acquireInitialRetryToken(t) {
        return Dw({ retryDelay: Ws, retryCount: 0 });
      }
      async refreshRetryTokenForRetry(t, r) {
        let n = await this.getMaxAttempts();
        if (this.shouldRetry(t, r, n)) {
          let s = r.errorType;
          this.retryBackoffStrategy.setDelayBase(s === "THROTTLING" ? Mw : Ws);
          let o = this.retryBackoffStrategy.computeNextBackoffDelay(
              t.getRetryCount(),
            ),
            i = r.retryAfterHint
              ? Math.max(r.retryAfterHint.getTime() - Date.now() || 0, o)
              : o,
            a = this.getCapacityCost(s);
          return (
            (this.capacity -= a),
            Dw({
              retryDelay: i,
              retryCount: t.getRetryCount() + 1,
              retryCost: a,
            })
          );
        }
        throw new Error("No retry token available");
      }
      recordSuccess(t) {
        this.capacity = Math.max(Sp, this.capacity + (t.getRetryCost() ?? Lw));
      }
      getCapacity() {
        return this.capacity;
      }
      async getMaxAttempts() {
        try {
          return await this.maxAttemptsProvider();
        } catch {
          return (
            console.warn(
              `Max attempts provider could not resolve. Using default of ${gp}`,
            ),
            gp
          );
        }
      }
      shouldRetry(t, r, n) {
        return (
          t.getRetryCount() + 1 < n &&
          this.capacity >= this.getCapacityCost(r.errorType) &&
          this.isRetryableError(r.errorType)
        );
      }
      getCapacityCost(t) {
        return t === "TRANSIENT" ? Fw : kw;
      }
      isRetryableError(t) {
        return t === "THROTTLING" || t === "TRANSIENT";
      }
    },
    yp = class {
      maxAttemptsProvider;
      rateLimiter;
      standardRetryStrategy;
      mode = be.RETRY_MODES.ADAPTIVE;
      constructor(t, r) {
        this.maxAttemptsProvider = t;
        let { rateLimiter: n } = r ?? {};
        ((this.rateLimiter = n ?? new va()),
          (this.standardRetryStrategy = new Ks(t)));
      }
      async acquireInitialRetryToken(t) {
        return (
          await this.rateLimiter.getSendToken(),
          this.standardRetryStrategy.acquireInitialRetryToken(t)
        );
      }
      async refreshRetryTokenForRetry(t, r) {
        return (
          this.rateLimiter.updateClientSendingRate(r),
          this.standardRetryStrategy.refreshRetryTokenForRetry(t, r)
        );
      }
      recordSuccess(t) {
        (this.rateLimiter.updateClientSendingRate({}),
          this.standardRetryStrategy.recordSuccess(t));
      }
    },
    Ep = class extends Ks {
      computeNextBackoffDelay;
      constructor(t, r = Ws) {
        (super(typeof t == "function" ? t : async () => t),
          typeof r == "number"
            ? (this.computeNextBackoffDelay = () => r)
            : (this.computeNextBackoffDelay = r));
      }
      async refreshRetryTokenForRetry(t, r) {
        let n = await super.refreshRetryTokenForRetry(t, r);
        return (
          (n.getRetryDelay = () =>
            this.computeNextBackoffDelay(n.getRetryCount())),
          n
        );
      }
    };
  be.AdaptiveRetryStrategy = yp;
  be.ConfiguredRetryStrategy = Ep;
  be.DEFAULT_MAX_ATTEMPTS = gp;
  be.DEFAULT_RETRY_DELAY_BASE = Ws;
  be.DEFAULT_RETRY_MODE = vM;
  be.DefaultRateLimiter = va;
  be.INITIAL_RETRY_TOKENS = Sp;
  be.INVOCATION_ID_HEADER = TM;
  be.MAXIMUM_RETRY_DELAY = _p;
  be.NO_RETRY_INCREMENT = Lw;
  be.REQUEST_HEADER = CM;
  be.RETRY_COST = kw;
  be.StandardRetryStrategy = Ks;
  be.THROTTLING_RETRY_DELAY_BASE = Mw;
  be.TIMEOUT_RETRY_COST = Fw;
});
var $w = P((Ta) => {
  "use strict";
  Object.defineProperty(Ta, "__esModule", { value: !0 });
  Ta.isStreamingPayload = void 0;
  var AM = require("stream"),
    RM = (e) =>
      e?.body instanceof AM.Readable ||
      (typeof ReadableStream < "u" && e?.body instanceof ReadableStream);
  Ta.isStreamingPayload = RM;
});
var Gt = P((Ae) => {
  "use strict";
  var _e = Un(),
    Hn = me(),
    Cr = hp(),
    Hw = Ri(),
    Uw = Ge(),
    NM = Y(),
    PM = $w(),
    OM = (e, t) => {
      let r = e,
        n = _e.NO_RETRY_INCREMENT,
        s = _e.RETRY_COST,
        o = _e.TIMEOUT_RETRY_COST,
        i = e,
        a = (m) => (m.name === "TimeoutError" ? o : s),
        d = (m) => a(m) <= i;
      return Object.freeze({
        hasRetryTokens: d,
        retrieveRetryTokens: (m) => {
          if (!d(m)) throw new Error("No retry token available");
          let g = a(m);
          return ((i -= g), g);
        },
        releaseRetryTokens: (m) => {
          ((i += m ?? n), (i = Math.min(i, r)));
        },
      });
    },
    zw = (e, t) =>
      Math.floor(Math.min(_e.MAXIMUM_RETRY_DELAY, Math.random() * 2 ** t * e)),
    jw = (e) =>
      e
        ? Cr.isRetryableByTrait(e) ||
          Cr.isClockSkewError(e) ||
          Cr.isThrottlingError(e) ||
          Cr.isTransientError(e)
        : !1,
    Bw = (e) =>
      e instanceof Error
        ? e
        : e instanceof Object
          ? Object.assign(new Error(), e)
          : typeof e == "string"
            ? new Error(e)
            : new Error(`AWS SDK error wrapper for ${e}`),
    Ca = class {
      maxAttemptsProvider;
      retryDecider;
      delayDecider;
      retryQuota;
      mode = _e.RETRY_MODES.STANDARD;
      constructor(t, r) {
        ((this.maxAttemptsProvider = t),
          (this.retryDecider = r?.retryDecider ?? jw),
          (this.delayDecider = r?.delayDecider ?? zw),
          (this.retryQuota = r?.retryQuota ?? OM(_e.INITIAL_RETRY_TOKENS)));
      }
      shouldRetry(t, r, n) {
        return (
          r < n && this.retryDecider(t) && this.retryQuota.hasRetryTokens(t)
        );
      }
      async getMaxAttempts() {
        let t;
        try {
          t = await this.maxAttemptsProvider();
        } catch {
          t = _e.DEFAULT_MAX_ATTEMPTS;
        }
        return t;
      }
      async retry(t, r, n) {
        let s,
          o = 0,
          i = 0,
          a = await this.getMaxAttempts(),
          { request: d } = r;
        for (
          Hn.HttpRequest.isInstance(d) &&
          (d.headers[_e.INVOCATION_ID_HEADER] = Hw.v4());
          ;

        )
          try {
            (Hn.HttpRequest.isInstance(d) &&
              (d.headers[_e.REQUEST_HEADER] = `attempt=${o + 1}; max=${a}`),
              n?.beforeRequest && (await n.beforeRequest()));
            let { response: l, output: p } = await t(r);
            return (
              n?.afterRequest && n.afterRequest(l),
              this.retryQuota.releaseRetryTokens(s),
              (p.$metadata.attempts = o + 1),
              (p.$metadata.totalRetryDelay = i),
              { response: l, output: p }
            );
          } catch (l) {
            let p = Bw(l);
            if ((o++, this.shouldRetry(p, o, a))) {
              s = this.retryQuota.retrieveRetryTokens(p);
              let m = this.delayDecider(
                  Cr.isThrottlingError(p)
                    ? _e.THROTTLING_RETRY_DELAY_BASE
                    : _e.DEFAULT_RETRY_DELAY_BASE,
                  o,
                ),
                g = DM(p.$response),
                h = Math.max(g || 0, m);
              ((i += h), await new Promise((E) => setTimeout(E, h)));
              continue;
            }
            throw (
              p.$metadata || (p.$metadata = {}),
              (p.$metadata.attempts = o),
              (p.$metadata.totalRetryDelay = i),
              p
            );
          }
      }
    },
    DM = (e) => {
      if (!Hn.HttpResponse.isInstance(e)) return;
      let t = Object.keys(e.headers).find(
        (o) => o.toLowerCase() === "retry-after",
      );
      if (!t) return;
      let r = e.headers[t],
        n = Number(r);
      return Number.isNaN(n) ? new Date(r).getTime() - Date.now() : n * 1e3;
    },
    wp = class extends Ca {
      rateLimiter;
      constructor(t, r) {
        let { rateLimiter: n, ...s } = r ?? {};
        (super(t, s),
          (this.rateLimiter = n ?? new _e.DefaultRateLimiter()),
          (this.mode = _e.RETRY_MODES.ADAPTIVE));
      }
      async retry(t, r) {
        return super.retry(t, r, {
          beforeRequest: async () => this.rateLimiter.getSendToken(),
          afterRequest: (n) => {
            this.rateLimiter.updateClientSendingRate(n);
          },
        });
      }
    },
    bp = "AWS_MAX_ATTEMPTS",
    xp = "max_attempts",
    MM = {
      environmentVariableSelector: (e) => {
        let t = e[bp];
        if (!t) return;
        let r = parseInt(t);
        if (Number.isNaN(r))
          throw new Error(
            `Environment variable ${bp} mast be a number, got "${t}"`,
          );
        return r;
      },
      configFileSelector: (e) => {
        let t = e[xp];
        if (!t) return;
        let r = parseInt(t);
        if (Number.isNaN(r))
          throw new Error(
            `Shared config file entry ${xp} mast be a number, got "${t}"`,
          );
        return r;
      },
      default: _e.DEFAULT_MAX_ATTEMPTS,
    },
    kM = (e) => {
      let { retryStrategy: t, retryMode: r, maxAttempts: n } = e,
        s = Uw.normalizeProvider(n ?? _e.DEFAULT_MAX_ATTEMPTS);
      return Object.assign(e, {
        maxAttempts: s,
        retryStrategy: async () =>
          t ||
          ((await Uw.normalizeProvider(r)()) === _e.RETRY_MODES.ADAPTIVE
            ? new _e.AdaptiveRetryStrategy(s)
            : new _e.StandardRetryStrategy(s)),
      });
    },
    qw = "AWS_RETRY_MODE",
    Vw = "retry_mode",
    FM = {
      environmentVariableSelector: (e) => e[qw],
      configFileSelector: (e) => e[Vw],
      default: _e.DEFAULT_RETRY_MODE,
    },
    Gw = () => (e) => async (t) => {
      let { request: r } = t;
      return (
        Hn.HttpRequest.isInstance(r) &&
          (delete r.headers[_e.INVOCATION_ID_HEADER],
          delete r.headers[_e.REQUEST_HEADER]),
        e(t)
      );
    },
    Ww = {
      name: "omitRetryHeadersMiddleware",
      tags: ["RETRY", "HEADERS", "OMIT_RETRY_HEADERS"],
      relation: "before",
      toMiddleware: "awsAuthMiddleware",
      override: !0,
    },
    LM = (e) => ({
      applyToStack: (t) => {
        t.addRelativeTo(Gw(), Ww);
      },
    }),
    Kw = (e) => (t, r) => async (n) => {
      let s = await e.retryStrategy(),
        o = await e.maxAttempts();
      if ($M(s)) {
        s = s;
        let i = await s.acquireInitialRetryToken(r.partition_id),
          a = new Error(),
          d = 0,
          l = 0,
          { request: p } = n,
          m = Hn.HttpRequest.isInstance(p);
        for (m && (p.headers[_e.INVOCATION_ID_HEADER] = Hw.v4()); ; )
          try {
            m && (p.headers[_e.REQUEST_HEADER] = `attempt=${d + 1}; max=${o}`);
            let { response: g, output: h } = await t(n);
            return (
              s.recordSuccess(i),
              (h.$metadata.attempts = d + 1),
              (h.$metadata.totalRetryDelay = l),
              { response: g, output: h }
            );
          } catch (g) {
            let h = UM(g);
            if (((a = Bw(g)), m && PM.isStreamingPayload(p)))
              throw (
                (r.logger instanceof NM.NoOpLogger ? console : r.logger)?.warn(
                  "An error was encountered in a non-retryable streaming request.",
                ),
                a
              );
            try {
              i = await s.refreshRetryTokenForRetry(i, h);
            } catch {
              throw (
                a.$metadata || (a.$metadata = {}),
                (a.$metadata.attempts = d + 1),
                (a.$metadata.totalRetryDelay = l),
                a
              );
            }
            d = i.getRetryCount();
            let E = i.getRetryDelay();
            ((l += E), await new Promise((C) => setTimeout(C, E)));
          }
      } else
        return (
          (s = s),
          s?.mode &&
            (r.userAgent = [
              ...(r.userAgent || []),
              ["cfg/retry-mode", s.mode],
            ]),
          s.retry(t, n)
        );
    },
    $M = (e) =>
      typeof e.acquireInitialRetryToken < "u" &&
      typeof e.refreshRetryTokenForRetry < "u" &&
      typeof e.recordSuccess < "u",
    UM = (e) => {
      let t = { error: e, errorType: HM(e) },
        r = Yw(e.$response);
      return (r && (t.retryAfterHint = r), t);
    },
    HM = (e) =>
      Cr.isThrottlingError(e)
        ? "THROTTLING"
        : Cr.isTransientError(e)
          ? "TRANSIENT"
          : Cr.isServerError(e)
            ? "SERVER_ERROR"
            : "CLIENT_ERROR",
    Jw = {
      name: "retryMiddleware",
      tags: ["RETRY"],
      step: "finalizeRequest",
      priority: "high",
      override: !0,
    },
    zM = (e) => ({
      applyToStack: (t) => {
        t.add(Kw(e), Jw);
      },
    }),
    Yw = (e) => {
      if (!Hn.HttpResponse.isInstance(e)) return;
      let t = Object.keys(e.headers).find(
        (o) => o.toLowerCase() === "retry-after",
      );
      if (!t) return;
      let r = e.headers[t],
        n = Number(r);
      return Number.isNaN(n) ? new Date(r) : new Date(n * 1e3);
    };
  Ae.AdaptiveRetryStrategy = wp;
  Ae.CONFIG_MAX_ATTEMPTS = xp;
  Ae.CONFIG_RETRY_MODE = Vw;
  Ae.ENV_MAX_ATTEMPTS = bp;
  Ae.ENV_RETRY_MODE = qw;
  Ae.NODE_MAX_ATTEMPT_CONFIG_OPTIONS = MM;
  Ae.NODE_RETRY_MODE_CONFIG_OPTIONS = FM;
  Ae.StandardRetryStrategy = Ca;
  Ae.defaultDelayDecider = zw;
  Ae.defaultRetryDecider = jw;
  Ae.getOmitRetryHeadersPlugin = LM;
  Ae.getRetryAfterHint = Yw;
  Ae.getRetryPlugin = zM;
  Ae.omitRetryHeadersMiddleware = Gw;
  Ae.omitRetryHeadersMiddlewareOptions = Ww;
  Ae.resolveRetryConfig = kM;
  Ae.retryMiddleware = Kw;
  Ae.retryMiddlewareOptions = Jw;
});
var Tp = P((Ir) => {
  "use strict";
  Object.defineProperty(Ir, "__esModule", { value: !0 });
  Ir.resolveHttpAuthSchemeConfig =
    Ir.defaultSFNHttpAuthSchemeProvider =
    Ir.defaultSFNHttpAuthSchemeParametersProvider =
      void 0;
  var jM = (Ne(), ce(Tt)),
    vp = Ge(),
    BM = async (e, t, r) => ({
      operation: (0, vp.getSmithyContext)(t).operation,
      region:
        (await (0, vp.normalizeProvider)(e.region)()) ||
        (() => {
          throw new Error(
            "expected `region` to be configured for `aws.auth#sigv4`",
          );
        })(),
    });
  Ir.defaultSFNHttpAuthSchemeParametersProvider = BM;
  function qM(e) {
    return {
      schemeId: "aws.auth#sigv4",
      signingProperties: { name: "states", region: e.region },
      propertiesExtractor: (t, r) => ({
        signingProperties: { config: t, context: r },
      }),
    };
  }
  var VM = (e) => {
    let t = [];
    switch (e.operation) {
      default:
        t.push(qM(e));
    }
    return t;
  };
  Ir.defaultSFNHttpAuthSchemeProvider = VM;
  var GM = (e) => {
    let t = (0, jM.resolveAwsSdkSigV4Config)(e);
    return Object.assign(t, {
      authSchemePreference: (0, vp.normalizeProvider)(
        e.authSchemePreference ?? [],
      ),
    });
  };
  Ir.resolveHttpAuthSchemeConfig = GM;
});
var Xw = P((P3, WM) => {
  WM.exports = {
    name: "@aws-sdk/client-sfn",
    description:
      "AWS SDK for JavaScript Sfn Client for Node.js, Browser and React Native",
    version: "3.906.0",
    scripts: {
      build: "concurrently 'yarn:build:cjs' 'yarn:build:es' 'yarn:build:types'",
      "build:cjs": "node ../../scripts/compilation/inline client-sfn",
      "build:es": "tsc -p tsconfig.es.json",
      "build:include:deps":
        "lerna run --scope $npm_package_name --include-dependencies build",
      "build:types": "tsc -p tsconfig.types.json",
      "build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
      clean: "rimraf ./dist-* && rimraf *.tsbuildinfo",
      "extract:docs": "api-extractor run --local",
      "generate:client":
        "node ../../scripts/generate-clients/single-service --solo sfn",
    },
    main: "./dist-cjs/index.js",
    types: "./dist-types/index.d.ts",
    module: "./dist-es/index.js",
    sideEffects: !1,
    dependencies: {
      "@aws-crypto/sha256-browser": "5.2.0",
      "@aws-crypto/sha256-js": "5.2.0",
      "@aws-sdk/core": "3.906.0",
      "@aws-sdk/credential-provider-node": "3.906.0",
      "@aws-sdk/middleware-host-header": "3.901.0",
      "@aws-sdk/middleware-logger": "3.901.0",
      "@aws-sdk/middleware-recursion-detection": "3.901.0",
      "@aws-sdk/middleware-user-agent": "3.906.0",
      "@aws-sdk/region-config-resolver": "3.901.0",
      "@aws-sdk/types": "3.901.0",
      "@aws-sdk/util-endpoints": "3.901.0",
      "@aws-sdk/util-user-agent-browser": "3.901.0",
      "@aws-sdk/util-user-agent-node": "3.906.0",
      "@smithy/config-resolver": "^4.3.0",
      "@smithy/core": "^3.14.0",
      "@smithy/fetch-http-handler": "^5.3.0",
      "@smithy/hash-node": "^4.2.0",
      "@smithy/invalid-dependency": "^4.2.0",
      "@smithy/middleware-content-length": "^4.2.0",
      "@smithy/middleware-endpoint": "^4.3.0",
      "@smithy/middleware-retry": "^4.4.0",
      "@smithy/middleware-serde": "^4.2.0",
      "@smithy/middleware-stack": "^4.2.0",
      "@smithy/node-config-provider": "^4.3.0",
      "@smithy/node-http-handler": "^4.3.0",
      "@smithy/protocol-http": "^5.3.0",
      "@smithy/smithy-client": "^4.7.0",
      "@smithy/types": "^4.6.0",
      "@smithy/url-parser": "^4.2.0",
      "@smithy/util-base64": "^4.2.0",
      "@smithy/util-body-length-browser": "^4.2.0",
      "@smithy/util-body-length-node": "^4.2.0",
      "@smithy/util-defaults-mode-browser": "^4.2.0",
      "@smithy/util-defaults-mode-node": "^4.2.0",
      "@smithy/util-endpoints": "^3.2.0",
      "@smithy/util-middleware": "^4.2.0",
      "@smithy/util-retry": "^4.2.0",
      "@smithy/util-utf8": "^4.2.0",
      "@smithy/uuid": "^1.1.0",
      tslib: "^2.6.2",
    },
    devDependencies: {
      "@tsconfig/node18": "18.2.4",
      "@types/node": "^18.19.69",
      concurrently: "7.0.0",
      "downlevel-dts": "0.10.1",
      rimraf: "3.0.2",
      typescript: "~5.8.3",
    },
    engines: { node: ">=18.0.0" },
    typesVersions: { "<4.0": { "dist-types/*": ["dist-types/ts3.4/*"] } },
    files: ["dist-*/**"],
    author: {
      name: "AWS SDK for JavaScript Team",
      url: "https://aws.amazon.com/javascript/",
    },
    license: "Apache-2.0",
    browser: { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.browser" },
    "react-native": {
      "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.native",
    },
    homepage:
      "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-sfn",
    repository: {
      type: "git",
      url: "https://github.com/aws/aws-sdk-js-v3.git",
      directory: "clients/client-sfn",
    },
  };
});
var Cp = P((Ar) => {
  "use strict";
  var KM = (gt(), ce(pr)),
    JM = qe(),
    Qw = "AWS_ACCESS_KEY_ID",
    Zw = "AWS_SECRET_ACCESS_KEY",
    eb = "AWS_SESSION_TOKEN",
    tb = "AWS_CREDENTIAL_EXPIRATION",
    rb = "AWS_CREDENTIAL_SCOPE",
    nb = "AWS_ACCOUNT_ID",
    YM = (e) => async () => {
      e?.logger?.debug("@aws-sdk/credential-provider-env - fromEnv");
      let t = process.env[Qw],
        r = process.env[Zw],
        n = process.env[eb],
        s = process.env[tb],
        o = process.env[rb],
        i = process.env[nb];
      if (t && r) {
        let a = {
          accessKeyId: t,
          secretAccessKey: r,
          ...(n && { sessionToken: n }),
          ...(s && { expiration: new Date(s) }),
          ...(o && { credentialScope: o }),
          ...(i && { accountId: i }),
        };
        return (KM.setCredentialFeature(a, "CREDENTIALS_ENV_VARS", "g"), a);
      }
      throw new JM.CredentialsProviderError(
        "Unable to find environment variable credentials.",
        { logger: e?.logger },
      );
    };
  Ar.ENV_ACCOUNT_ID = nb;
  Ar.ENV_CREDENTIAL_SCOPE = rb;
  Ar.ENV_EXPIRATION = tb;
  Ar.ENV_KEY = Qw;
  Ar.ENV_SECRET = Zw;
  Ar.ENV_SESSION = eb;
  Ar.fromEnv = YM;
});
var Ys = P((ze) => {
  "use strict";
  var At = qe(),
    XM = require("url"),
    QM = require("buffer"),
    ZM = require("http"),
    Pp = xr(),
    ek = lr();
  function Js(e) {
    return new Promise((t, r) => {
      let n = ZM.request({
        method: "GET",
        ...e,
        hostname: e.hostname?.replace(/^\[(.+)\]$/, "$1"),
      });
      (n.on("error", (s) => {
        (r(
          Object.assign(
            new At.ProviderError(
              "Unable to connect to instance metadata service",
            ),
            s,
          ),
        ),
          n.destroy());
      }),
        n.on("timeout", () => {
          (r(
            new At.ProviderError("TimeoutError from instance metadata service"),
          ),
            n.destroy());
        }),
        n.on("response", (s) => {
          let { statusCode: o = 400 } = s;
          (o < 200 || 300 <= o) &&
            (r(
              Object.assign(
                new At.ProviderError(
                  "Error response received from instance metadata service",
                ),
                { statusCode: o },
              ),
            ),
            n.destroy());
          let i = [];
          (s.on("data", (a) => {
            i.push(a);
          }),
            s.on("end", () => {
              (t(QM.Buffer.concat(i)), n.destroy());
            }));
        }),
        n.end());
    });
  }
  var ab = (e) =>
      !!e &&
      typeof e == "object" &&
      typeof e.AccessKeyId == "string" &&
      typeof e.SecretAccessKey == "string" &&
      typeof e.Token == "string" &&
      typeof e.Expiration == "string",
    cb = (e) => ({
      accessKeyId: e.AccessKeyId,
      secretAccessKey: e.SecretAccessKey,
      sessionToken: e.Token,
      expiration: new Date(e.Expiration),
      ...(e.AccountId && { accountId: e.AccountId }),
    }),
    db = 1e3,
    lb = 0,
    Op = ({ maxRetries: e = lb, timeout: t = db }) => ({
      maxRetries: e,
      timeout: t,
    }),
    Ap = (e, t) => {
      let r = e();
      for (let n = 0; n < t; n++) r = r.catch(e);
      return r;
    },
    Ia = "AWS_CONTAINER_CREDENTIALS_FULL_URI",
    Aa = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI",
    Rp = "AWS_CONTAINER_AUTHORIZATION_TOKEN",
    tk = (e = {}) => {
      let { timeout: t, maxRetries: r } = Op(e);
      return () =>
        Ap(async () => {
          let n = await ik({ logger: e.logger }),
            s = JSON.parse(await rk(t, n));
          if (!ab(s))
            throw new At.CredentialsProviderError(
              "Invalid response received from instance metadata service.",
              { logger: e.logger },
            );
          return cb(s);
        }, r);
    },
    rk = async (e, t) => (
      process.env[Rp] &&
        (t.headers = { ...t.headers, Authorization: process.env[Rp] }),
      (await Js({ ...t, timeout: e })).toString()
    ),
    nk = "169.254.170.2",
    sk = { localhost: !0, "127.0.0.1": !0 },
    ok = { "http:": !0, "https:": !0 },
    ik = async ({ logger: e }) => {
      if (process.env[Aa]) return { hostname: nk, path: process.env[Aa] };
      if (process.env[Ia]) {
        let t = XM.parse(process.env[Ia]);
        if (!t.hostname || !(t.hostname in sk))
          throw new At.CredentialsProviderError(
            `${t.hostname} is not a valid container metadata service hostname`,
            { tryNextLink: !1, logger: e },
          );
        if (!t.protocol || !(t.protocol in ok))
          throw new At.CredentialsProviderError(
            `${t.protocol} is not a valid container metadata service protocol`,
            { tryNextLink: !1, logger: e },
          );
        return { ...t, port: t.port ? parseInt(t.port, 10) : void 0 };
      }
      throw new At.CredentialsProviderError(
        `The container metadata credential provider cannot be used unless the ${Aa} or ${Ia} environment variable is set`,
        { tryNextLink: !1, logger: e },
      );
    },
    Np = class e extends At.CredentialsProviderError {
      tryNextLink;
      name = "InstanceMetadataV1FallbackError";
      constructor(t, r = !0) {
        (super(t, r),
          (this.tryNextLink = r),
          Object.setPrototypeOf(this, e.prototype));
      }
    };
  ze.Endpoint = void 0;
  (function (e) {
    ((e.IPv4 = "http://169.254.169.254"), (e.IPv6 = "http://[fd00:ec2::254]"));
  })(ze.Endpoint || (ze.Endpoint = {}));
  var ak = "AWS_EC2_METADATA_SERVICE_ENDPOINT",
    ck = "ec2_metadata_service_endpoint",
    dk = {
      environmentVariableSelector: (e) => e[ak],
      configFileSelector: (e) => e[ck],
      default: void 0,
    },
    zn;
  (function (e) {
    ((e.IPv4 = "IPv4"), (e.IPv6 = "IPv6"));
  })(zn || (zn = {}));
  var lk = "AWS_EC2_METADATA_SERVICE_ENDPOINT_MODE",
    uk = "ec2_metadata_service_endpoint_mode",
    fk = {
      environmentVariableSelector: (e) => e[lk],
      configFileSelector: (e) => e[uk],
      default: zn.IPv4,
    },
    ub = async () => ek.parseUrl((await pk()) || (await mk())),
    pk = async () => Pp.loadConfig(dk)(),
    mk = async () => {
      let e = await Pp.loadConfig(fk)();
      switch (e) {
        case zn.IPv4:
          return ze.Endpoint.IPv4;
        case zn.IPv6:
          return ze.Endpoint.IPv6;
        default:
          throw new Error(
            `Unsupported endpoint mode: ${e}. Select from ${Object.values(zn)}`,
          );
      }
    },
    hk = 300,
    gk = 300,
    Sk =
      "https://docs.aws.amazon.com/sdkref/latest/guide/feature-static-credentials.html",
    sb = (e, t) => {
      let r = hk + Math.floor(Math.random() * gk),
        n = new Date(Date.now() + r * 1e3);
      t.warn(
        `Attempting credential expiration extension due to a credential service availability issue. A refresh of these credentials will be attempted after ${new Date(n)}.
For more information, please visit: ` + Sk,
      );
      let s = e.originalExpiration ?? e.expiration;
      return { ...e, ...(s ? { originalExpiration: s } : {}), expiration: n };
    },
    yk = (e, t = {}) => {
      let r = t?.logger || console,
        n;
      return async () => {
        let s;
        try {
          ((s = await e()),
            s.expiration &&
              s.expiration.getTime() < Date.now() &&
              (s = sb(s, r)));
        } catch (o) {
          if (n) (r.warn("Credential renew failed: ", o), (s = sb(n, r)));
          else throw o;
        }
        return ((n = s), s);
      };
    },
    fb = "/latest/meta-data/iam/security-credentials/",
    Ek = "/latest/api/token",
    Ip = "AWS_EC2_METADATA_V1_DISABLED",
    ob = "ec2_metadata_v1_disabled",
    ib = "x-aws-ec2-metadata-token",
    _k = (e = {}) => yk(wk(e), { logger: e.logger }),
    wk = (e = {}) => {
      let t = !1,
        { logger: r, profile: n } = e,
        { timeout: s, maxRetries: o } = Op(e),
        i = async (a, d) => {
          if (t || d.headers?.[ib] == null) {
            let m = !1,
              g = !1,
              h = await Pp.loadConfig(
                {
                  environmentVariableSelector: (E) => {
                    let C = E[Ip];
                    if (((g = !!C && C !== "false"), C === void 0))
                      throw new At.CredentialsProviderError(
                        `${Ip} not set in env, checking config file next.`,
                        { logger: e.logger },
                      );
                    return g;
                  },
                  configFileSelector: (E) => {
                    let C = E[ob];
                    return ((m = !!C && C !== "false"), m);
                  },
                  default: !1,
                },
                { profile: n },
              )();
            if (e.ec2MetadataV1Disabled || h) {
              let E = [];
              throw (
                e.ec2MetadataV1Disabled &&
                  E.push(
                    "credential provider initialization (runtime option ec2MetadataV1Disabled)",
                  ),
                m && E.push(`config file profile (${ob})`),
                g && E.push(`process environment variable (${Ip})`),
                new Np(
                  `AWS EC2 Metadata v1 fallback has been blocked by AWS SDK configuration in the following: [${E.join(", ")}].`,
                )
              );
            }
          }
          let p = (
            await Ap(async () => {
              let m;
              try {
                m = await xk(d);
              } catch (g) {
                throw (g.statusCode === 401 && (t = !1), g);
              }
              return m;
            }, a)
          ).trim();
          return Ap(async () => {
            let m;
            try {
              m = await vk(p, d, e);
            } catch (g) {
              throw (g.statusCode === 401 && (t = !1), g);
            }
            return m;
          }, a);
        };
      return async () => {
        let a = await ub();
        if (t)
          return (
            r?.debug(
              "AWS SDK Instance Metadata",
              "using v1 fallback (no token fetch)",
            ),
            i(o, { ...a, timeout: s })
          );
        {
          let d;
          try {
            d = (await bk({ ...a, timeout: s })).toString();
          } catch (l) {
            if (l?.statusCode === 400)
              throw Object.assign(l, {
                message: "EC2 Metadata token request returned error",
              });
            return (
              (l.message === "TimeoutError" ||
                [403, 404, 405].includes(l.statusCode)) &&
                (t = !0),
              r?.debug(
                "AWS SDK Instance Metadata",
                "using v1 fallback (initial)",
              ),
              i(o, { ...a, timeout: s })
            );
          }
          return i(o, { ...a, headers: { [ib]: d }, timeout: s });
        }
      };
    },
    bk = async (e) =>
      Js({
        ...e,
        path: Ek,
        method: "PUT",
        headers: { "x-aws-ec2-metadata-token-ttl-seconds": "21600" },
      }),
    xk = async (e) => (await Js({ ...e, path: fb })).toString(),
    vk = async (e, t, r) => {
      let n = JSON.parse((await Js({ ...t, path: fb + e })).toString());
      if (!ab(n))
        throw new At.CredentialsProviderError(
          "Invalid response received from instance metadata service.",
          { logger: r.logger },
        );
      return cb(n);
    };
  ze.DEFAULT_MAX_RETRIES = lb;
  ze.DEFAULT_TIMEOUT = db;
  ze.ENV_CMDS_AUTH_TOKEN = Rp;
  ze.ENV_CMDS_FULL_URI = Ia;
  ze.ENV_CMDS_RELATIVE_URI = Aa;
  ze.fromContainerMetadata = tk;
  ze.fromInstanceMetadata = _k;
  ze.getInstanceMetadataEndpoint = ub;
  ze.httpRequest = Js;
  ze.providerConfigFromInit = Op;
});
var pb = P((Ra) => {
  "use strict";
  Object.defineProperty(Ra, "__esModule", { value: !0 });
  Ra.checkUrl = void 0;
  var Tk = qe(),
    Ck = "169.254.170.2",
    Ik = "169.254.170.23",
    Ak = "[fd00:ec2::23]",
    Rk = (e, t) => {
      if (
        e.protocol !== "https:" &&
        !(e.hostname === Ck || e.hostname === Ik || e.hostname === Ak)
      ) {
        if (e.hostname.includes("[")) {
          if (
            e.hostname === "[::1]" ||
            e.hostname === "[0000:0000:0000:0000:0000:0000:0000:0001]"
          )
            return;
        } else {
          if (e.hostname === "localhost") return;
          let r = e.hostname.split("."),
            n = (s) => {
              let o = parseInt(s, 10);
              return 0 <= o && o <= 255;
            };
          if (r[0] === "127" && n(r[1]) && n(r[2]) && n(r[3]) && r.length === 4)
            return;
        }
        throw new Tk.CredentialsProviderError(
          `URL not accepted. It must either be HTTPS or match one of the following:
  - loopback CIDR 127.0.0.0/8 or [::1/128]
  - ECS container host 169.254.170.2
  - EKS container host 169.254.170.23 or [fd00:ec2::23]`,
          { logger: t },
        );
      }
    };
  Ra.checkUrl = Rk;
});
var mb = P((Na) => {
  "use strict";
  Object.defineProperty(Na, "__esModule", { value: !0 });
  Na.createGetRequest = Dk;
  Na.getCredentials = Mk;
  var Dp = qe(),
    Nk = me(),
    Pk = Y(),
    Ok = mi();
  function Dk(e) {
    return new Nk.HttpRequest({
      protocol: e.protocol,
      hostname: e.hostname,
      port: Number(e.port),
      path: e.pathname,
      query: Array.from(e.searchParams.entries()).reduce(
        (t, [r, n]) => ((t[r] = n), t),
        {},
      ),
      fragment: e.hash,
    });
  }
  async function Mk(e, t) {
    let n = await (0, Ok.sdkStreamMixin)(e.body).transformToString();
    if (e.statusCode === 200) {
      let s = JSON.parse(n);
      if (
        typeof s.AccessKeyId != "string" ||
        typeof s.SecretAccessKey != "string" ||
        typeof s.Token != "string" ||
        typeof s.Expiration != "string"
      )
        throw new Dp.CredentialsProviderError(
          "HTTP credential provider response not of the required format, an object matching: { AccessKeyId: string, SecretAccessKey: string, Token: string, Expiration: string(rfc3339) }",
          { logger: t },
        );
      return {
        accessKeyId: s.AccessKeyId,
        secretAccessKey: s.SecretAccessKey,
        sessionToken: s.Token,
        expiration: (0, Pk.parseRfc3339DateTime)(s.Expiration),
      };
    }
    if (e.statusCode >= 400 && e.statusCode < 500) {
      let s = {};
      try {
        s = JSON.parse(n);
      } catch {}
      throw Object.assign(
        new Dp.CredentialsProviderError(
          `Server responded with status: ${e.statusCode}`,
          { logger: t },
        ),
        { Code: s.Code, Message: s.Message },
      );
    }
    throw new Dp.CredentialsProviderError(
      `Server responded with status: ${e.statusCode}`,
      { logger: t },
    );
  }
});
var hb = P((Pa) => {
  "use strict";
  Object.defineProperty(Pa, "__esModule", { value: !0 });
  Pa.retryWrapper = void 0;
  var kk = (e, t, r) => async () => {
    for (let n = 0; n < t; ++n)
      try {
        return await e();
      } catch {
        await new Promise((o) => setTimeout(o, r));
      }
    return await e();
  };
  Pa.retryWrapper = kk;
});
var yb = P((Oa) => {
  "use strict";
  Object.defineProperty(Oa, "__esModule", { value: !0 });
  Oa.fromHttp = void 0;
  var Fk = (vs(), ce(xs)),
    Lk = (gt(), ce(pr)),
    $k = zr(),
    gb = qe(),
    Uk = Fk.__importDefault(require("fs/promises")),
    Hk = pb(),
    Sb = mb(),
    zk = hb(),
    jk = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI",
    Bk = "http://169.254.170.2",
    qk = "AWS_CONTAINER_CREDENTIALS_FULL_URI",
    Vk = "AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE",
    Gk = "AWS_CONTAINER_AUTHORIZATION_TOKEN",
    Wk = (e = {}) => {
      e.logger?.debug("@aws-sdk/credential-provider-http - fromHttp");
      let t,
        r = e.awsContainerCredentialsRelativeUri ?? process.env[jk],
        n = e.awsContainerCredentialsFullUri ?? process.env[qk],
        s = e.awsContainerAuthorizationToken ?? process.env[Gk],
        o = e.awsContainerAuthorizationTokenFile ?? process.env[Vk],
        i =
          e.logger?.constructor?.name === "NoOpLogger" || !e.logger?.warn
            ? console.warn
            : e.logger.warn.bind(e.logger);
      if (
        (r &&
          n &&
          (i(
            "@aws-sdk/credential-provider-http: you have set both awsContainerCredentialsRelativeUri and awsContainerCredentialsFullUri.",
          ),
          i("awsContainerCredentialsFullUri will take precedence.")),
        s &&
          o &&
          (i(
            "@aws-sdk/credential-provider-http: you have set both awsContainerAuthorizationToken and awsContainerAuthorizationTokenFile.",
          ),
          i("awsContainerAuthorizationToken will take precedence.")),
        n)
      )
        t = n;
      else if (r) t = `${Bk}${r}`;
      else
        throw new gb.CredentialsProviderError(
          `No HTTP credential provider host provided.
Set AWS_CONTAINER_CREDENTIALS_FULL_URI or AWS_CONTAINER_CREDENTIALS_RELATIVE_URI.`,
          { logger: e.logger },
        );
      let a = new URL(t);
      (0, Hk.checkUrl)(a, e.logger);
      let d = $k.NodeHttpHandler.create({
        requestTimeout: e.timeout ?? 1e3,
        connectionTimeout: e.timeout ?? 1e3,
      });
      return (0, zk.retryWrapper)(
        async () => {
          let l = (0, Sb.createGetRequest)(a);
          s
            ? (l.headers.Authorization = s)
            : o &&
              (l.headers.Authorization = (
                await Uk.default.readFile(o)
              ).toString());
          try {
            let p = await d.handle(l);
            return (0, Sb.getCredentials)(p.response).then((m) =>
              (0, Lk.setCredentialFeature)(m, "CREDENTIALS_HTTP", "z"),
            );
          } catch (p) {
            throw new gb.CredentialsProviderError(String(p), {
              logger: e.logger,
            });
          }
        },
        e.maxRetries ?? 3,
        e.timeout ?? 1e3,
      );
    };
  Oa.fromHttp = Wk;
});
var Mp = P((Da) => {
  "use strict";
  Object.defineProperty(Da, "__esModule", { value: !0 });
  Da.fromHttp = void 0;
  var Kk = yb();
  Object.defineProperty(Da, "fromHttp", {
    enumerable: !0,
    get: function () {
      return Kk.fromHttp;
    },
  });
});
function Jk(e) {
  return {
    schemeId: "aws.auth#sigv4",
    signingProperties: { name: "sso-oauth", region: e.region },
    propertiesExtractor: (t, r) => ({
      signingProperties: { config: t, context: r },
    }),
  };
}
function Yk(e) {
  return { schemeId: "smithy.api#noAuth" };
}
var Xs,
  Eb,
  _b,
  wb,
  kp = b(() => {
    Ne();
    ((Xs = v(Ge())),
      (Eb = async (e, t, r) => ({
        operation: (0, Xs.getSmithyContext)(t).operation,
        region:
          (await (0, Xs.normalizeProvider)(e.region)()) ||
          (() => {
            throw new Error(
              "expected `region` to be configured for `aws.auth#sigv4`",
            );
          })(),
      })));
    ((_b = (e) => {
      let t = [];
      switch (e.operation) {
        case "CreateToken": {
          t.push(Yk(e));
          break;
        }
        default:
          t.push(Jk(e));
      }
      return t;
    }),
      (wb = (e) => {
        let t = Qr(e);
        return Object.assign(t, {
          authSchemePreference: (0, Xs.normalizeProvider)(
            e.authSchemePreference ?? [],
          ),
        });
      }));
  });
var bb,
  xb,
  Fp = b(() => {
    ((bb = (e) =>
      Object.assign(e, {
        useDualstackEndpoint: e.useDualstackEndpoint ?? !1,
        useFipsEndpoint: e.useFipsEndpoint ?? !1,
        defaultSigningName: "sso-oauth",
      })),
      (xb = {
        UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
        Endpoint: { type: "builtInParams", name: "endpoint" },
        Region: { type: "builtInParams", name: "region" },
        UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
      }));
  });
var Ma,
  Lp = b(() => {
    Ma = {
      name: "@aws-sdk/nested-clients",
      version: "3.906.0",
      description: "Nested clients for AWS SDK packages.",
      main: "./dist-cjs/index.js",
      module: "./dist-es/index.js",
      types: "./dist-types/index.d.ts",
      scripts: {
        build:
          "yarn lint && concurrently 'yarn:build:cjs' 'yarn:build:es' 'yarn:build:types'",
        "build:cjs": "node ../../scripts/compilation/inline nested-clients",
        "build:es": "tsc -p tsconfig.es.json",
        "build:include:deps":
          "lerna run --scope $npm_package_name --include-dependencies build",
        "build:types": "tsc -p tsconfig.types.json",
        "build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
        clean: "rimraf ./dist-* && rimraf *.tsbuildinfo",
        lint: "node ../../scripts/validation/submodules-linter.js --pkg nested-clients",
        test: "yarn g:vitest run",
        "test:watch": "yarn g:vitest watch",
      },
      engines: { node: ">=18.0.0" },
      sideEffects: !1,
      author: {
        name: "AWS SDK for JavaScript Team",
        url: "https://aws.amazon.com/javascript/",
      },
      license: "Apache-2.0",
      dependencies: {
        "@aws-crypto/sha256-browser": "5.2.0",
        "@aws-crypto/sha256-js": "5.2.0",
        "@aws-sdk/core": "3.906.0",
        "@aws-sdk/middleware-host-header": "3.901.0",
        "@aws-sdk/middleware-logger": "3.901.0",
        "@aws-sdk/middleware-recursion-detection": "3.901.0",
        "@aws-sdk/middleware-user-agent": "3.906.0",
        "@aws-sdk/region-config-resolver": "3.901.0",
        "@aws-sdk/types": "3.901.0",
        "@aws-sdk/util-endpoints": "3.901.0",
        "@aws-sdk/util-user-agent-browser": "3.901.0",
        "@aws-sdk/util-user-agent-node": "3.906.0",
        "@smithy/config-resolver": "^4.3.0",
        "@smithy/core": "^3.14.0",
        "@smithy/fetch-http-handler": "^5.3.0",
        "@smithy/hash-node": "^4.2.0",
        "@smithy/invalid-dependency": "^4.2.0",
        "@smithy/middleware-content-length": "^4.2.0",
        "@smithy/middleware-endpoint": "^4.3.0",
        "@smithy/middleware-retry": "^4.4.0",
        "@smithy/middleware-serde": "^4.2.0",
        "@smithy/middleware-stack": "^4.2.0",
        "@smithy/node-config-provider": "^4.3.0",
        "@smithy/node-http-handler": "^4.3.0",
        "@smithy/protocol-http": "^5.3.0",
        "@smithy/smithy-client": "^4.7.0",
        "@smithy/types": "^4.6.0",
        "@smithy/url-parser": "^4.2.0",
        "@smithy/util-base64": "^4.2.0",
        "@smithy/util-body-length-browser": "^4.2.0",
        "@smithy/util-body-length-node": "^4.2.0",
        "@smithy/util-defaults-mode-browser": "^4.2.0",
        "@smithy/util-defaults-mode-node": "^4.2.0",
        "@smithy/util-endpoints": "^3.2.0",
        "@smithy/util-middleware": "^4.2.0",
        "@smithy/util-retry": "^4.2.0",
        "@smithy/util-utf8": "^4.2.0",
        tslib: "^2.6.2",
      },
      devDependencies: {
        concurrently: "7.0.0",
        "downlevel-dts": "0.10.1",
        rimraf: "3.0.2",
        typescript: "~5.8.3",
      },
      typesVersions: { "<4.0": { "dist-types/*": ["dist-types/ts3.4/*"] } },
      files: [
        "./sso-oidc.d.ts",
        "./sso-oidc.js",
        "./sts.d.ts",
        "./sts.js",
        "dist-*/**",
      ],
      browser: {
        "./dist-es/submodules/sso-oidc/runtimeConfig":
          "./dist-es/submodules/sso-oidc/runtimeConfig.browser",
        "./dist-es/submodules/sts/runtimeConfig":
          "./dist-es/submodules/sts/runtimeConfig.browser",
      },
      "react-native": {},
      homepage:
        "https://github.com/aws/aws-sdk-js-v3/tree/main/packages/nested-clients",
      repository: {
        type: "git",
        url: "https://github.com/aws/aws-sdk-js-v3.git",
        directory: "packages/nested-clients",
      },
      exports: {
        "./sso-oidc": {
          types: "./dist-types/submodules/sso-oidc/index.d.ts",
          module: "./dist-es/submodules/sso-oidc/index.js",
          node: "./dist-cjs/submodules/sso-oidc/index.js",
          import: "./dist-es/submodules/sso-oidc/index.js",
          require: "./dist-cjs/submodules/sso-oidc/index.js",
        },
        "./sts": {
          types: "./dist-types/submodules/sts/index.d.ts",
          module: "./dist-es/submodules/sts/index.js",
          node: "./dist-cjs/submodules/sts/index.js",
          import: "./dist-es/submodules/sts/index.js",
          require: "./dist-cjs/submodules/sts/index.js",
        },
      },
    };
  });
var Qs = P((on) => {
  "use strict";
  var vb = require("os"),
    $p = require("process"),
    Qk = Ln(),
    Tb = { isCrtAvailable: !1 },
    Zk = () => (Tb.isCrtAvailable ? ["md/crt-avail"] : null),
    Cb =
      ({ serviceId: e, clientVersion: t }) =>
      async (r) => {
        let n = [
            ["aws-sdk-js", t],
            ["ua", "2.1"],
            [`os/${vb.platform()}`, vb.release()],
            ["lang/js"],
            ["md/nodejs", `${$p.versions.node}`],
          ],
          s = Zk();
        (s && n.push(s),
          e && n.push([`api/${e}`, t]),
          $p.env.AWS_EXECUTION_ENV &&
            n.push([`exec-env/${$p.env.AWS_EXECUTION_ENV}`]));
        let o = await r?.userAgentAppId?.();
        return o ? [...n, [`app/${o}`]] : [...n];
      },
    eF = Cb,
    Ib = "AWS_SDK_UA_APP_ID",
    Ab = "sdk_ua_app_id",
    tF = "sdk-ua-app-id",
    rF = {
      environmentVariableSelector: (e) => e[Ib],
      configFileSelector: (e) => e[Ab] ?? e[tF],
      default: Qk.DEFAULT_UA_APP_ID,
    };
  on.NODE_APP_ID_CONFIG_OPTIONS = rF;
  on.UA_APP_ID_ENV_NAME = Ib;
  on.UA_APP_ID_INI_NAME = Ab;
  on.createDefaultUserAgentProvider = Cb;
  on.crtAvailability = Tb;
  on.defaultUserAgent = eF;
});
var Zs = P((Pb) => {
  "use strict";
  var Up = gn(),
    nF = Oe(),
    sF = require("buffer"),
    Rb = require("crypto"),
    Hp = class {
      algorithmIdentifier;
      secret;
      hash;
      constructor(t, r) {
        ((this.algorithmIdentifier = t), (this.secret = r), this.reset());
      }
      update(t, r) {
        this.hash.update(nF.toUint8Array(Nb(t, r)));
      }
      digest() {
        return Promise.resolve(this.hash.digest());
      }
      reset() {
        this.hash = this.secret
          ? Rb.createHmac(this.algorithmIdentifier, Nb(this.secret))
          : Rb.createHash(this.algorithmIdentifier);
      }
    };
  function Nb(e, t) {
    return sF.Buffer.isBuffer(e)
      ? e
      : typeof e == "string"
        ? Up.fromString(e, t)
        : ArrayBuffer.isView(e)
          ? Up.fromArrayBuffer(e.buffer, e.byteOffset, e.byteLength)
          : Up.fromArrayBuffer(e);
  }
  Pb.Hash = Hp;
});
var eo = P((Ob) => {
  "use strict";
  var zp = require("node:fs"),
    oF = (e) => {
      if (!e) return 0;
      if (typeof e == "string") return Buffer.byteLength(e);
      if (typeof e.byteLength == "number") return e.byteLength;
      if (typeof e.size == "number") return e.size;
      if (typeof e.start == "number" && typeof e.end == "number")
        return e.end + 1 - e.start;
      if (e instanceof zp.ReadStream) {
        if (e.path != null) return zp.lstatSync(e.path).size;
        if (typeof e.fd == "number") return zp.fstatSync(e.fd).size;
      }
      throw new Error(`Body Length computation failed for ${e}`);
    };
  Ob.calculateBodyLength = oF;
});
var jb,
  dt,
  Db,
  to,
  jn,
  Bn,
  Wt,
  jp,
  Bp,
  Mb,
  kb,
  Fb,
  Bb,
  qb,
  ct,
  Lb,
  Vb,
  $b,
  Ub,
  Hb,
  zb,
  iF,
  Gb,
  Wb = b(() => {
    ((jb = "required"),
      (dt = "argv"),
      (Db = "isSet"),
      (to = "booleanEquals"),
      (jn = "error"),
      (Bn = "endpoint"),
      (Wt = "tree"),
      (jp = "PartitionResult"),
      (Bp = "getAttr"),
      (Mb = { [jb]: !1, type: "String" }),
      (kb = { [jb]: !0, default: !1, type: "Boolean" }),
      (Fb = { ref: "Endpoint" }),
      (Bb = { fn: to, [dt]: [{ ref: "UseFIPS" }, !0] }),
      (qb = { fn: to, [dt]: [{ ref: "UseDualStack" }, !0] }),
      (ct = {}),
      (Lb = { fn: Bp, [dt]: [{ ref: jp }, "supportsFIPS"] }),
      (Vb = { ref: jp }),
      ($b = {
        fn: to,
        [dt]: [!0, { fn: Bp, [dt]: [Vb, "supportsDualStack"] }],
      }),
      (Ub = [Bb]),
      (Hb = [qb]),
      (zb = [{ ref: "Region" }]),
      (iF = {
        version: "1.0",
        parameters: { Region: Mb, UseDualStack: kb, UseFIPS: kb, Endpoint: Mb },
        rules: [
          {
            conditions: [{ fn: Db, [dt]: [Fb] }],
            rules: [
              {
                conditions: Ub,
                error:
                  "Invalid Configuration: FIPS and custom endpoint are not supported",
                type: jn,
              },
              {
                conditions: Hb,
                error:
                  "Invalid Configuration: Dualstack and custom endpoint are not supported",
                type: jn,
              },
              { endpoint: { url: Fb, properties: ct, headers: ct }, type: Bn },
            ],
            type: Wt,
          },
          {
            conditions: [{ fn: Db, [dt]: zb }],
            rules: [
              {
                conditions: [{ fn: "aws.partition", [dt]: zb, assign: jp }],
                rules: [
                  {
                    conditions: [Bb, qb],
                    rules: [
                      {
                        conditions: [{ fn: to, [dt]: [!0, Lb] }, $b],
                        rules: [
                          {
                            endpoint: {
                              url: "https://oidc-fips.{Region}.{PartitionResult#dualStackDnsSuffix}",
                              properties: ct,
                              headers: ct,
                            },
                            type: Bn,
                          },
                        ],
                        type: Wt,
                      },
                      {
                        error:
                          "FIPS and DualStack are enabled, but this partition does not support one or both",
                        type: jn,
                      },
                    ],
                    type: Wt,
                  },
                  {
                    conditions: Ub,
                    rules: [
                      {
                        conditions: [{ fn: to, [dt]: [Lb, !0] }],
                        rules: [
                          {
                            conditions: [
                              {
                                fn: "stringEquals",
                                [dt]: [
                                  { fn: Bp, [dt]: [Vb, "name"] },
                                  "aws-us-gov",
                                ],
                              },
                            ],
                            endpoint: {
                              url: "https://oidc.{Region}.amazonaws.com",
                              properties: ct,
                              headers: ct,
                            },
                            type: Bn,
                          },
                          {
                            endpoint: {
                              url: "https://oidc-fips.{Region}.{PartitionResult#dnsSuffix}",
                              properties: ct,
                              headers: ct,
                            },
                            type: Bn,
                          },
                        ],
                        type: Wt,
                      },
                      {
                        error:
                          "FIPS is enabled but this partition does not support FIPS",
                        type: jn,
                      },
                    ],
                    type: Wt,
                  },
                  {
                    conditions: Hb,
                    rules: [
                      {
                        conditions: [$b],
                        rules: [
                          {
                            endpoint: {
                              url: "https://oidc.{Region}.{PartitionResult#dualStackDnsSuffix}",
                              properties: ct,
                              headers: ct,
                            },
                            type: Bn,
                          },
                        ],
                        type: Wt,
                      },
                      {
                        error:
                          "DualStack is enabled but this partition does not support DualStack",
                        type: jn,
                      },
                    ],
                    type: Wt,
                  },
                  {
                    endpoint: {
                      url: "https://oidc.{Region}.{PartitionResult#dnsSuffix}",
                      properties: ct,
                      headers: ct,
                    },
                    type: Bn,
                  },
                ],
                type: Wt,
              },
            ],
            type: Wt,
          },
          { error: "Invalid Configuration: Missing Region", type: jn },
        ],
      }),
      (Gb = iF));
  });
var Kb,
  qn,
  aF,
  Jb,
  Yb = b(() => {
    ((Kb = v(Cn())), (qn = v(Tn())));
    Wb();
    ((aF = new qn.EndpointCache({
      size: 50,
      params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
    })),
      (Jb = (e, t = {}) =>
        aF.get(e, () =>
          (0, qn.resolveEndpoint)(Gb, { endpointParams: e, logger: t.logger }),
        )));
    qn.customEndpointFunctions.aws = Kb.awsEndpointFunctions;
  });
var Xb,
  Qb,
  ka,
  Fa,
  Zb,
  ex = b(() => {
    Ne();
    Je();
    ((Xb = v(Y())), (Qb = v(lr())), (ka = v(De())), (Fa = v(Oe())));
    kp();
    Yb();
    Zb = (e) => ({
      apiVersion: "2019-06-10",
      base64Decoder: e?.base64Decoder ?? ka.fromBase64,
      base64Encoder: e?.base64Encoder ?? ka.toBase64,
      disableHostPrefix: e?.disableHostPrefix ?? !1,
      endpointProvider: e?.endpointProvider ?? Jb,
      extensions: e?.extensions ?? [],
      httpAuthSchemeProvider: e?.httpAuthSchemeProvider ?? _b,
      httpAuthSchemes: e?.httpAuthSchemes ?? [
        {
          schemeId: "aws.auth#sigv4",
          identityProvider: (t) => t.getIdentityProvider("aws.auth#sigv4"),
          signer: new Ye(),
        },
        {
          schemeId: "smithy.api#noAuth",
          identityProvider: (t) =>
            t.getIdentityProvider("smithy.api#noAuth") || (async () => ({})),
          signer: new $t(),
        },
      ],
      logger: e?.logger ?? new Xb.NoOpLogger(),
      serviceId: e?.serviceId ?? "SSO OIDC",
      urlParser: e?.urlParser ?? Qb.parseUrl,
      utf8Decoder: e?.utf8Decoder ?? Fa.fromUtf8,
      utf8Encoder: e?.utf8Encoder ?? Fa.toUtf8,
    });
  });
var ro = P((sx) => {
  "use strict";
  var cF = It(),
    tx = xr(),
    dF = qe(),
    lF = "AWS_EXECUTION_ENV",
    rx = "AWS_REGION",
    nx = "AWS_DEFAULT_REGION",
    uF = "AWS_EC2_METADATA_DISABLED",
    fF = ["in-region", "cross-region", "mobile", "standard", "legacy"],
    pF = "/latest/meta-data/placement/region",
    mF = "AWS_DEFAULTS_MODE",
    hF = "defaults_mode",
    gF = {
      environmentVariableSelector: (e) => e[mF],
      configFileSelector: (e) => e[hF],
      default: "legacy",
    },
    SF = ({
      region: e = tx.loadConfig(cF.NODE_REGION_CONFIG_OPTIONS),
      defaultsMode: t = tx.loadConfig(gF),
    } = {}) =>
      dF.memoize(async () => {
        let r = typeof t == "function" ? await t() : t;
        switch (r?.toLowerCase()) {
          case "auto":
            return yF(e);
          case "in-region":
          case "cross-region":
          case "mobile":
          case "standard":
          case "legacy":
            return Promise.resolve(r?.toLocaleLowerCase());
          case void 0:
            return Promise.resolve("legacy");
          default:
            throw new Error(
              `Invalid parameter for "defaultsMode", expect ${fF.join(", ")}, got ${r}`,
            );
        }
      }),
    yF = async (e) => {
      if (e) {
        let t = typeof e == "function" ? await e() : e,
          r = await EF();
        return r ? (t === r ? "in-region" : "cross-region") : "standard";
      }
      return "standard";
    },
    EF = async () => {
      if (process.env[lF] && (process.env[rx] || process.env[nx]))
        return process.env[rx] ?? process.env[nx];
      if (!process.env[uF])
        try {
          let { getInstanceMetadataEndpoint: e, httpRequest: t } =
              await Promise.resolve().then(() => v(Ys())),
            r = await e();
          return (await t({ ...r, path: pF })).toString();
        } catch {}
    };
  sx.resolveDefaultsModeConfig = SF;
});
var La,
  Nr,
  ox,
  $a,
  Rr,
  Ua,
  ix,
  ax,
  cx,
  dx,
  lx,
  ux,
  fx = b(() => {
    Lp();
    Ne();
    ((La = v(Qs())),
      (Nr = v(It())),
      (ox = v(Zs())),
      ($a = v(Gt())),
      (Rr = v(xr())),
      (Ua = v(zr())),
      (ix = v(eo())),
      (ax = v(Un())));
    ex();
    ((cx = v(Y())),
      (dx = v(ro())),
      (lx = v(Y())),
      (ux = (e) => {
        (0, lx.emitWarningIfUnsupportedVersion)(process.version);
        let t = (0, dx.resolveDefaultsModeConfig)(e),
          r = () => t().then(cx.loadConfigsForDefaultMode),
          n = Zb(e);
        In(process.version);
        let s = { profile: e?.profile, logger: n.logger };
        return {
          ...n,
          ...e,
          runtime: "node",
          defaultsMode: t,
          authSchemePreference:
            e?.authSchemePreference ?? (0, Rr.loadConfig)(Nn, s),
          bodyLengthChecker: e?.bodyLengthChecker ?? ix.calculateBodyLength,
          defaultUserAgentProvider:
            e?.defaultUserAgentProvider ??
            (0, La.createDefaultUserAgentProvider)({
              serviceId: n.serviceId,
              clientVersion: Ma.version,
            }),
          maxAttempts:
            e?.maxAttempts ??
            (0, Rr.loadConfig)($a.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, e),
          region:
            e?.region ??
            (0, Rr.loadConfig)(Nr.NODE_REGION_CONFIG_OPTIONS, {
              ...Nr.NODE_REGION_CONFIG_FILE_OPTIONS,
              ...s,
            }),
          requestHandler: Ua.NodeHttpHandler.create(e?.requestHandler ?? r),
          retryMode:
            e?.retryMode ??
            (0, Rr.loadConfig)(
              {
                ...$a.NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () =>
                  (await r()).retryMode || ax.DEFAULT_RETRY_MODE,
              },
              e,
            ),
          sha256: e?.sha256 ?? ox.Hash.bind(null, "sha256"),
          streamCollector: e?.streamCollector ?? Ua.streamCollector,
          useDualstackEndpoint:
            e?.useDualstackEndpoint ??
            (0, Rr.loadConfig)(
              Nr.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS,
              s,
            ),
          useFipsEndpoint:
            e?.useFipsEndpoint ??
            (0, Rr.loadConfig)(Nr.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, s),
          userAgentAppId:
            e?.userAgentAppId ??
            (0, Rr.loadConfig)(La.NODE_APP_ID_CONFIG_OPTIONS, s),
        };
      }));
  });
var no = P((oW, yx) => {
  "use strict";
  var Ha = Object.defineProperty,
    _F = Object.getOwnPropertyDescriptor,
    wF = Object.getOwnPropertyNames,
    bF = Object.prototype.hasOwnProperty,
    Rt = (e, t) => Ha(e, "name", { value: t, configurable: !0 }),
    xF = (e, t) => {
      for (var r in t) Ha(e, r, { get: t[r], enumerable: !0 });
    },
    vF = (e, t, r, n) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let s of wF(t))
          !bF.call(e, s) &&
            s !== r &&
            Ha(e, s, {
              get: () => t[s],
              enumerable: !(n = _F(t, s)) || n.enumerable,
            });
      return e;
    },
    TF = (e) => vF(Ha({}, "__esModule", { value: !0 }), e),
    mx = {};
  xF(mx, {
    NODE_REGION_CONFIG_FILE_OPTIONS: () => RF,
    NODE_REGION_CONFIG_OPTIONS: () => AF,
    REGION_ENV_NAME: () => hx,
    REGION_INI_NAME: () => gx,
    getAwsRegionExtensionConfiguration: () => CF,
    resolveAwsRegionExtensionConfiguration: () => IF,
    resolveRegionConfig: () => NF,
  });
  yx.exports = TF(mx);
  var CF = Rt(
      (e) => ({
        setRegion(t) {
          e.region = t;
        },
        region() {
          return e.region;
        },
      }),
      "getAwsRegionExtensionConfiguration",
    ),
    IF = Rt(
      (e) => ({ region: e.region() }),
      "resolveAwsRegionExtensionConfiguration",
    ),
    hx = "AWS_REGION",
    gx = "region",
    AF = {
      environmentVariableSelector: Rt(
        (e) => e[hx],
        "environmentVariableSelector",
      ),
      configFileSelector: Rt((e) => e[gx], "configFileSelector"),
      default: Rt(() => {
        throw new Error("Region is missing");
      }, "default"),
    },
    RF = { preferredFile: "credentials" },
    Sx = Rt(
      (e) =>
        typeof e == "string" && (e.startsWith("fips-") || e.endsWith("-fips")),
      "isFipsRegion",
    ),
    px = Rt(
      (e) =>
        Sx(e)
          ? ["fips-aws-global", "aws-fips"].includes(e)
            ? "us-east-1"
            : e.replace(/fips-(dkr-|prod-)?|-fips/, "")
          : e,
      "getRealRegion",
    ),
    NF = Rt((e) => {
      let { region: t, useFipsEndpoint: r } = e;
      if (!t) throw new Error("Region is missing");
      return Object.assign(e, {
        region: Rt(async () => {
          if (typeof t == "string") return px(t);
          let n = await t();
          return px(n);
        }, "region"),
        useFipsEndpoint: Rt(async () => {
          let n = typeof t == "string" ? t : await t();
          return Sx(n)
            ? !0
            : typeof r != "function"
              ? Promise.resolve(!!r)
              : r();
        }, "useFipsEndpoint"),
      });
    }, "resolveRegionConfig");
});
var Ex,
  _x,
  wx = b(() => {
    ((Ex = (e) => {
      let t = e.httpAuthSchemes,
        r = e.httpAuthSchemeProvider,
        n = e.credentials;
      return {
        setHttpAuthScheme(s) {
          let o = t.findIndex((i) => i.schemeId === s.schemeId);
          o === -1 ? t.push(s) : t.splice(o, 1, s);
        },
        httpAuthSchemes() {
          return t;
        },
        setHttpAuthSchemeProvider(s) {
          r = s;
        },
        httpAuthSchemeProvider() {
          return r;
        },
        setCredentials(s) {
          n = s;
        },
        credentials() {
          return n;
        },
      };
    }),
      (_x = (e) => ({
        httpAuthSchemes: e.httpAuthSchemes(),
        httpAuthSchemeProvider: e.httpAuthSchemeProvider(),
        credentials: e.credentials(),
      })));
  });
var za,
  ja,
  Ba,
  bx,
  xx = b(() => {
    ((za = v(no())), (ja = v(me())), (Ba = v(Y())));
    wx();
    bx = (e, t) => {
      let r = Object.assign(
        (0, za.getAwsRegionExtensionConfiguration)(e),
        (0, Ba.getDefaultExtensionConfiguration)(e),
        (0, ja.getHttpHandlerExtensionConfiguration)(e),
        Ex(e),
      );
      return (
        t.forEach((n) => n.configure(r)),
        Object.assign(
          e,
          (0, za.resolveAwsRegionExtensionConfiguration)(r),
          (0, Ba.resolveDefaultRuntimeConfig)(r),
          (0, ja.resolveHttpHandlerRuntimeConfig)(r),
          _x(r),
        )
      );
    };
  });
var qa,
  vx,
  Tx,
  Va,
  Cx,
  Ix,
  Ax,
  Ga,
  qp,
  so,
  Vp = b(() => {
    ((qa = v(cs())),
      (vx = v(ds())),
      (Tx = v(ls())),
      (Va = v(Ln())),
      (Cx = v(It())));
    Je();
    ((Ix = v(Bs())), (Ax = v(vr())), (Ga = v(Gt())), (qp = v(Y())));
    kp();
    Fp();
    fx();
    xx();
    so = class extends qp.Client {
      config;
      constructor(...[t]) {
        let r = ux(t || {});
        (super(r), (this.initConfig = r));
        let n = bb(r),
          s = (0, Va.resolveUserAgentConfig)(n),
          o = (0, Ga.resolveRetryConfig)(s),
          i = (0, Cx.resolveRegionConfig)(o),
          a = (0, qa.resolveHostHeaderConfig)(i),
          d = (0, Ax.resolveEndpointConfig)(a),
          l = wb(d),
          p = bx(l, t?.extensions || []);
        ((this.config = p),
          this.middlewareStack.use((0, Va.getUserAgentPlugin)(this.config)),
          this.middlewareStack.use((0, Ga.getRetryPlugin)(this.config)),
          this.middlewareStack.use((0, Ix.getContentLengthPlugin)(this.config)),
          this.middlewareStack.use((0, qa.getHostHeaderPlugin)(this.config)),
          this.middlewareStack.use((0, vx.getLoggerPlugin)(this.config)),
          this.middlewareStack.use(
            (0, Tx.getRecursionDetectionPlugin)(this.config),
          ),
          this.middlewareStack.use(
            fs(this.config, {
              httpAuthSchemeParametersProvider: Eb,
              identityProviderConfigProvider: async (m) =>
                new Kr({ "aws.auth#sigv4": m.credentials }),
            }),
          ),
          this.middlewareStack.use(ps(this.config)));
      }
      destroy() {
        super.destroy();
      }
    };
  });
var Rx,
  Pe,
  Wa = b(() => {
    ((Rx = v(Y())),
      (Pe = class e extends Rx.ServiceException {
        constructor(t) {
          (super(t), Object.setPrototypeOf(this, e.prototype));
        }
      }));
  });
var an,
  PF,
  oo,
  io,
  Gp,
  Wp,
  ao,
  co,
  lo,
  uo,
  OF,
  fo,
  po,
  mo,
  ho,
  go,
  Ka = b(() => {
    an = v(Y());
    Wa();
    ((PF = { KMS_ACCESS_DENIED: "KMS_AccessDeniedException" }),
      (oo = class e extends Pe {
        name = "AccessDeniedException";
        $fault = "client";
        error;
        reason;
        error_description;
        constructor(t) {
          (super({ name: "AccessDeniedException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.reason = t.reason),
            (this.error_description = t.error_description));
        }
      }),
      (io = class e extends Pe {
        name = "AuthorizationPendingException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({
            name: "AuthorizationPendingException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (Gp = (e) => ({
        ...e,
        ...(e.clientSecret && { clientSecret: an.SENSITIVE_STRING }),
        ...(e.refreshToken && { refreshToken: an.SENSITIVE_STRING }),
        ...(e.codeVerifier && { codeVerifier: an.SENSITIVE_STRING }),
      })),
      (Wp = (e) => ({
        ...e,
        ...(e.accessToken && { accessToken: an.SENSITIVE_STRING }),
        ...(e.refreshToken && { refreshToken: an.SENSITIVE_STRING }),
        ...(e.idToken && { idToken: an.SENSITIVE_STRING }),
      })),
      (ao = class e extends Pe {
        name = "ExpiredTokenException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({ name: "ExpiredTokenException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (co = class e extends Pe {
        name = "InternalServerException";
        $fault = "server";
        error;
        error_description;
        constructor(t) {
          (super({ name: "InternalServerException", $fault: "server", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (lo = class e extends Pe {
        name = "InvalidClientException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({ name: "InvalidClientException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (uo = class e extends Pe {
        name = "InvalidGrantException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({ name: "InvalidGrantException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (OF = {
        KMS_DISABLED_KEY: "KMS_DisabledException",
        KMS_INVALID_KEY_USAGE: "KMS_InvalidKeyUsageException",
        KMS_INVALID_STATE: "KMS_InvalidStateException",
        KMS_KEY_NOT_FOUND: "KMS_NotFoundException",
      }),
      (fo = class e extends Pe {
        name = "InvalidRequestException";
        $fault = "client";
        error;
        reason;
        error_description;
        constructor(t) {
          (super({ name: "InvalidRequestException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.reason = t.reason),
            (this.error_description = t.error_description));
        }
      }),
      (po = class e extends Pe {
        name = "InvalidScopeException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({ name: "InvalidScopeException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (mo = class e extends Pe {
        name = "SlowDownException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({ name: "SlowDownException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (ho = class e extends Pe {
        name = "UnauthorizedClientException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({
            name: "UnauthorizedClientException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }),
      (go = class e extends Pe {
        name = "UnsupportedGrantTypeException";
        $fault = "client";
        error;
        error_description;
        constructor(t) {
          (super({
            name: "UnsupportedGrantTypeException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype),
            (this.error = t.error),
            (this.error_description = t.error_description));
        }
      }));
  });
var D,
  Nx,
  Px,
  DF,
  MF,
  kF,
  FF,
  LF,
  $F,
  UF,
  HF,
  zF,
  jF,
  BF,
  qF,
  VF,
  lt,
  Ox = b(() => {
    Ne();
    Je();
    D = v(Y());
    Ka();
    Wa();
    ((Nx = async (e, t) => {
      let r = Is(e, t),
        n = { "content-type": "application/json" };
      r.bp("/token");
      let s;
      return (
        (s = JSON.stringify(
          (0, D.take)(e, {
            clientId: [],
            clientSecret: [],
            code: [],
            codeVerifier: [],
            deviceCode: [],
            grantType: [],
            redirectUri: [],
            refreshToken: [],
            scope: (o) => (0, D._json)(o),
          }),
        )),
        r.m("POST").h(n).b(s),
        r.build()
      );
    }),
      (Px = async (e, t) => {
        if (e.statusCode !== 200 && e.statusCode >= 300) return DF(e, t);
        let r = (0, D.map)({ $metadata: lt(e) }),
          n = (0, D.expectNonNull)(
            (0, D.expectObject)(await kn(e.body, t)),
            "body",
          ),
          s = (0, D.take)(n, {
            accessToken: D.expectString,
            expiresIn: D.expectInt32,
            idToken: D.expectString,
            refreshToken: D.expectString,
            tokenType: D.expectString,
          });
        return (Object.assign(r, s), r);
      }),
      (DF = async (e, t) => {
        let r = { ...e, body: await Bf(e.body, t) },
          n = en(e, r.body);
        switch (n) {
          case "AccessDeniedException":
          case "com.amazonaws.ssooidc#AccessDeniedException":
            throw await kF(r, t);
          case "AuthorizationPendingException":
          case "com.amazonaws.ssooidc#AuthorizationPendingException":
            throw await FF(r, t);
          case "ExpiredTokenException":
          case "com.amazonaws.ssooidc#ExpiredTokenException":
            throw await LF(r, t);
          case "InternalServerException":
          case "com.amazonaws.ssooidc#InternalServerException":
            throw await $F(r, t);
          case "InvalidClientException":
          case "com.amazonaws.ssooidc#InvalidClientException":
            throw await UF(r, t);
          case "InvalidGrantException":
          case "com.amazonaws.ssooidc#InvalidGrantException":
            throw await HF(r, t);
          case "InvalidRequestException":
          case "com.amazonaws.ssooidc#InvalidRequestException":
            throw await zF(r, t);
          case "InvalidScopeException":
          case "com.amazonaws.ssooidc#InvalidScopeException":
            throw await jF(r, t);
          case "SlowDownException":
          case "com.amazonaws.ssooidc#SlowDownException":
            throw await BF(r, t);
          case "UnauthorizedClientException":
          case "com.amazonaws.ssooidc#UnauthorizedClientException":
            throw await qF(r, t);
          case "UnsupportedGrantTypeException":
          case "com.amazonaws.ssooidc#UnsupportedGrantTypeException":
            throw await VF(r, t);
          default:
            let s = r.body;
            return MF({ output: e, parsedBody: s, errorCode: n });
        }
      }),
      (MF = (0, D.withBaseException)(Pe)),
      (kF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
            reason: D.expectString,
          });
        Object.assign(r, s);
        let o = new oo({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (FF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new io({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (LF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new ao({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      ($F = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new co({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (UF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new lo({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (HF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new uo({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (zF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
            reason: D.expectString,
          });
        Object.assign(r, s);
        let o = new fo({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (jF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new po({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (BF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new mo({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (qF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new ho({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (VF = async (e, t) => {
        let r = (0, D.map)({}),
          n = e.body,
          s = (0, D.take)(n, {
            error: D.expectString,
            error_description: D.expectString,
          });
        Object.assign(r, s);
        let o = new go({ $metadata: lt(e), ...r });
        return (0, D.decorateServiceException)(o, e.body);
      }),
      (lt = (e) => ({
        httpStatusCode: e.statusCode,
        requestId:
          e.headers["x-amzn-requestid"] ??
          e.headers["x-amzn-request-id"] ??
          e.headers["x-amz-request-id"],
        extendedRequestId: e.headers["x-amz-id-2"],
        cfId: e.headers["x-amz-cf-id"],
      })));
  });
var Dx,
  Mx,
  Kp,
  So,
  Jp = b(() => {
    ((Dx = v(vr())), (Mx = v(sr())), (Kp = v(Y())));
    Fp();
    Ka();
    Ox();
    So = class extends (
      Kp.Command.classBuilder()
        .ep(xb)
        .m(function (t, r, n, s) {
          return [
            (0, Mx.getSerdePlugin)(n, this.serialize, this.deserialize),
            (0, Dx.getEndpointPlugin)(n, t.getEndpointParameterInstructions()),
          ];
        })
        .s("AWSSSOOIDCService", "CreateToken", {})
        .n("SSOOIDCClient", "CreateTokenCommand")
        .f(Gp, Wp)
        .ser(Nx)
        .de(Px)
        .build()
    ) {};
  });
var kx,
  GF,
  Ja,
  Fx = b(() => {
    kx = v(Y());
    Jp();
    Vp();
    ((GF = { CreateTokenCommand: So }), (Ja = class extends so {}));
    (0, kx.createAggregatedClient)(GF, Ja);
  });
var Lx = b(() => {
  Jp();
});
var $x = b(() => {
  Ka();
});
var Yp = {};
st(Yp, {
  $Command: () => Kp.Command,
  AccessDeniedException: () => oo,
  AccessDeniedExceptionReason: () => PF,
  AuthorizationPendingException: () => io,
  CreateTokenCommand: () => So,
  CreateTokenRequestFilterSensitiveLog: () => Gp,
  CreateTokenResponseFilterSensitiveLog: () => Wp,
  ExpiredTokenException: () => ao,
  InternalServerException: () => co,
  InvalidClientException: () => lo,
  InvalidGrantException: () => uo,
  InvalidRequestException: () => fo,
  InvalidRequestExceptionReason: () => OF,
  InvalidScopeException: () => po,
  SSOOIDC: () => Ja,
  SSOOIDCClient: () => so,
  SSOOIDCServiceException: () => Pe,
  SlowDownException: () => mo,
  UnauthorizedClientException: () => ho,
  UnsupportedGrantTypeException: () => go,
  __Client: () => qp.Client,
});
var Xp = b(() => {
  Vp();
  Fx();
  Lx();
  $x();
  Wa();
});
var jx = P((Eo) => {
  "use strict";
  var WF = (gt(), ce(pr)),
    KF = (mf(), ce(kE)),
    rt = qe(),
    yo = qt(),
    JF = require("fs"),
    YF =
      ({ logger: e, signingName: t } = {}) =>
      async () => {
        if ((e?.debug?.("@aws-sdk/token-providers - fromEnvSigningName"), !t))
          throw new rt.TokenProviderError(
            "Please pass 'signingName' to compute environment variable key",
            { logger: e },
          );
        let r = KF.getBearerTokenEnvKey(t);
        if (!(r in process.env))
          throw new rt.TokenProviderError(
            `Token not present in '${r}' environment variable`,
            { logger: e },
          );
        let n = { token: process.env[r] };
        return (WF.setTokenFeature(n, "BEARER_SERVICE_ENV_VARS", "3"), n);
      },
    XF = 300 * 1e3,
    Qp =
      "To refresh this SSO session run 'aws sso login' with the corresponding profile.",
    QF = async (e, t = {}) => {
      let { SSOOIDCClient: r } = await Promise.resolve().then(() => (Xp(), Yp));
      return new r(
        Object.assign({}, t.clientConfig ?? {}, {
          region: e ?? t.clientConfig?.region,
          logger: t.clientConfig?.logger ?? t.parentClientConfig?.logger,
        }),
      );
    },
    ZF = async (e, t, r = {}) => {
      let { CreateTokenCommand: n } = await Promise.resolve().then(
        () => (Xp(), Yp),
      );
      return (await QF(t, r)).send(
        new n({
          clientId: e.clientId,
          clientSecret: e.clientSecret,
          refreshToken: e.refreshToken,
          grantType: "refresh_token",
        }),
      );
    },
    Ux = (e) => {
      if (e.expiration && e.expiration.getTime() < Date.now())
        throw new rt.TokenProviderError(`Token is expired. ${Qp}`, !1);
    },
    cn = (e, t, r = !1) => {
      if (typeof t > "u")
        throw new rt.TokenProviderError(
          `Value not present for '${e}' in SSO Token${r ? ". Cannot refresh" : ""}. ${Qp}`,
          !1,
        );
    },
    { writeFile: e1 } = JF.promises,
    t1 = (e, t) => {
      let r = yo.getSSOTokenFilepath(e),
        n = JSON.stringify(t, null, 2);
      return e1(r, n);
    },
    Hx = new Date(0),
    zx =
      (e = {}) =>
      async ({ callerClientConfig: t } = {}) => {
        let r = { ...e, parentClientConfig: { ...t, ...e.parentClientConfig } };
        r.logger?.debug("@aws-sdk/token-providers - fromSso");
        let n = await yo.parseKnownFiles(r),
          s = yo.getProfileName({ profile: r.profile ?? t?.profile }),
          o = n[s];
        if (o) {
          if (!o.sso_session)
            throw new rt.TokenProviderError(
              `Profile '${s}' is missing required property 'sso_session'.`,
            );
        } else
          throw new rt.TokenProviderError(
            `Profile '${s}' could not be found in shared credentials file.`,
            !1,
          );
        let i = o.sso_session,
          d = (await yo.loadSsoSessionData(r))[i];
        if (!d)
          throw new rt.TokenProviderError(
            `Sso session '${i}' could not be found in shared credentials file.`,
            !1,
          );
        for (let E of ["sso_start_url", "sso_region"])
          if (!d[E])
            throw new rt.TokenProviderError(
              `Sso session '${i}' is missing required property '${E}'.`,
              !1,
            );
        d.sso_start_url;
        let l = d.sso_region,
          p;
        try {
          p = await yo.getSSOTokenFromFile(i);
        } catch {
          throw new rt.TokenProviderError(
            `The SSO session token associated with profile=${s} was not found or is invalid. ${Qp}`,
            !1,
          );
        }
        (cn("accessToken", p.accessToken), cn("expiresAt", p.expiresAt));
        let { accessToken: m, expiresAt: g } = p,
          h = { token: m, expiration: new Date(g) };
        if (h.expiration.getTime() - Date.now() > XF) return h;
        if (Date.now() - Hx.getTime() < 30 * 1e3) return (Ux(h), h);
        (cn("clientId", p.clientId, !0),
          cn("clientSecret", p.clientSecret, !0),
          cn("refreshToken", p.refreshToken, !0));
        try {
          Hx.setTime(Date.now());
          let E = await ZF(p, l, r);
          (cn("accessToken", E.accessToken), cn("expiresIn", E.expiresIn));
          let C = new Date(Date.now() + E.expiresIn * 1e3);
          try {
            await t1(i, {
              ...p,
              accessToken: E.accessToken,
              expiresAt: C.toISOString(),
              refreshToken: E.refreshToken,
            });
          } catch {}
          return { token: E.accessToken, expiration: C };
        } catch {
          return (Ux(h), h);
        }
      },
    r1 =
      ({ token: e, logger: t }) =>
      async () => {
        if ((t?.debug("@aws-sdk/token-providers - fromStatic"), !e || !e.token))
          throw new rt.TokenProviderError(
            "Please pass a valid token to fromStatic",
            !1,
          );
        return e;
      },
    n1 = (e = {}) =>
      rt.memoize(
        rt.chain(zx(e), async () => {
          throw new rt.TokenProviderError(
            "Could not load token from any providers",
            !1,
          );
        }),
        (t) =>
          t.expiration !== void 0 && t.expiration.getTime() - Date.now() < 3e5,
        (t) => t.expiration !== void 0,
      );
  Eo.fromEnvSigningName = YF;
  Eo.fromSso = zx;
  Eo.fromStatic = r1;
  Eo.nodeProvider = n1;
});
var em = P((Pr) => {
  "use strict";
  Object.defineProperty(Pr, "__esModule", { value: !0 });
  Pr.resolveHttpAuthSchemeConfig =
    Pr.defaultSSOHttpAuthSchemeProvider =
    Pr.defaultSSOHttpAuthSchemeParametersProvider =
      void 0;
  var s1 = (Ne(), ce(Tt)),
    Zp = Ge(),
    o1 = async (e, t, r) => ({
      operation: (0, Zp.getSmithyContext)(t).operation,
      region:
        (await (0, Zp.normalizeProvider)(e.region)()) ||
        (() => {
          throw new Error(
            "expected `region` to be configured for `aws.auth#sigv4`",
          );
        })(),
    });
  Pr.defaultSSOHttpAuthSchemeParametersProvider = o1;
  function i1(e) {
    return {
      schemeId: "aws.auth#sigv4",
      signingProperties: { name: "awsssoportal", region: e.region },
      propertiesExtractor: (t, r) => ({
        signingProperties: { config: t, context: r },
      }),
    };
  }
  function Ya(e) {
    return { schemeId: "smithy.api#noAuth" };
  }
  var a1 = (e) => {
    let t = [];
    switch (e.operation) {
      case "GetRoleCredentials": {
        t.push(Ya(e));
        break;
      }
      case "ListAccountRoles": {
        t.push(Ya(e));
        break;
      }
      case "ListAccounts": {
        t.push(Ya(e));
        break;
      }
      case "Logout": {
        t.push(Ya(e));
        break;
      }
      default:
        t.push(i1(e));
    }
    return t;
  };
  Pr.defaultSSOHttpAuthSchemeProvider = a1;
  var c1 = (e) => {
    let t = (0, s1.resolveAwsSdkSigV4Config)(e);
    return Object.assign(t, {
      authSchemePreference: (0, Zp.normalizeProvider)(
        e.authSchemePreference ?? [],
      ),
    });
  };
  Pr.resolveHttpAuthSchemeConfig = c1;
});
var Bx = P((zW, d1) => {
  d1.exports = {
    name: "@aws-sdk/client-sso",
    description:
      "AWS SDK for JavaScript Sso Client for Node.js, Browser and React Native",
    version: "3.906.0",
    scripts: {
      build: "concurrently 'yarn:build:cjs' 'yarn:build:es' 'yarn:build:types'",
      "build:cjs": "node ../../scripts/compilation/inline client-sso",
      "build:es": "tsc -p tsconfig.es.json",
      "build:include:deps":
        "lerna run --scope $npm_package_name --include-dependencies build",
      "build:types": "tsc -p tsconfig.types.json",
      "build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
      clean: "rimraf ./dist-* && rimraf *.tsbuildinfo",
      "extract:docs": "api-extractor run --local",
      "generate:client":
        "node ../../scripts/generate-clients/single-service --solo sso",
    },
    main: "./dist-cjs/index.js",
    types: "./dist-types/index.d.ts",
    module: "./dist-es/index.js",
    sideEffects: !1,
    dependencies: {
      "@aws-crypto/sha256-browser": "5.2.0",
      "@aws-crypto/sha256-js": "5.2.0",
      "@aws-sdk/core": "3.906.0",
      "@aws-sdk/middleware-host-header": "3.901.0",
      "@aws-sdk/middleware-logger": "3.901.0",
      "@aws-sdk/middleware-recursion-detection": "3.901.0",
      "@aws-sdk/middleware-user-agent": "3.906.0",
      "@aws-sdk/region-config-resolver": "3.901.0",
      "@aws-sdk/types": "3.901.0",
      "@aws-sdk/util-endpoints": "3.901.0",
      "@aws-sdk/util-user-agent-browser": "3.901.0",
      "@aws-sdk/util-user-agent-node": "3.906.0",
      "@smithy/config-resolver": "^4.3.0",
      "@smithy/core": "^3.14.0",
      "@smithy/fetch-http-handler": "^5.3.0",
      "@smithy/hash-node": "^4.2.0",
      "@smithy/invalid-dependency": "^4.2.0",
      "@smithy/middleware-content-length": "^4.2.0",
      "@smithy/middleware-endpoint": "^4.3.0",
      "@smithy/middleware-retry": "^4.4.0",
      "@smithy/middleware-serde": "^4.2.0",
      "@smithy/middleware-stack": "^4.2.0",
      "@smithy/node-config-provider": "^4.3.0",
      "@smithy/node-http-handler": "^4.3.0",
      "@smithy/protocol-http": "^5.3.0",
      "@smithy/smithy-client": "^4.7.0",
      "@smithy/types": "^4.6.0",
      "@smithy/url-parser": "^4.2.0",
      "@smithy/util-base64": "^4.2.0",
      "@smithy/util-body-length-browser": "^4.2.0",
      "@smithy/util-body-length-node": "^4.2.0",
      "@smithy/util-defaults-mode-browser": "^4.2.0",
      "@smithy/util-defaults-mode-node": "^4.2.0",
      "@smithy/util-endpoints": "^3.2.0",
      "@smithy/util-middleware": "^4.2.0",
      "@smithy/util-retry": "^4.2.0",
      "@smithy/util-utf8": "^4.2.0",
      tslib: "^2.6.2",
    },
    devDependencies: {
      "@tsconfig/node18": "18.2.4",
      "@types/node": "^18.19.69",
      concurrently: "7.0.0",
      "downlevel-dts": "0.10.1",
      rimraf: "3.0.2",
      typescript: "~5.8.3",
    },
    engines: { node: ">=18.0.0" },
    typesVersions: { "<4.0": { "dist-types/*": ["dist-types/ts3.4/*"] } },
    files: ["dist-*/**"],
    author: {
      name: "AWS SDK for JavaScript Team",
      url: "https://aws.amazon.com/javascript/",
    },
    license: "Apache-2.0",
    browser: { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.browser" },
    "react-native": {
      "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.native",
    },
    homepage:
      "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-sso",
    repository: {
      type: "git",
      url: "https://github.com/aws/aws-sdk-js-v3.git",
      directory: "clients/client-sso",
    },
  };
});
var sv = P((Xa) => {
  "use strict";
  Object.defineProperty(Xa, "__esModule", { value: !0 });
  Xa.ruleSet = void 0;
  var ev = "required",
    ft = "fn",
    pt = "argv",
    Wn = "ref",
    qx = !0,
    Vx = "isSet",
    _o = "booleanEquals",
    Vn = "error",
    Gn = "endpoint",
    Kt = "tree",
    tm = "PartitionResult",
    rm = "getAttr",
    Gx = { [ev]: !1, type: "String" },
    Wx = { [ev]: !0, default: !1, type: "Boolean" },
    Kx = { [Wn]: "Endpoint" },
    tv = { [ft]: _o, [pt]: [{ [Wn]: "UseFIPS" }, !0] },
    rv = { [ft]: _o, [pt]: [{ [Wn]: "UseDualStack" }, !0] },
    ut = {},
    Jx = { [ft]: rm, [pt]: [{ [Wn]: tm }, "supportsFIPS"] },
    nv = { [Wn]: tm },
    Yx = {
      [ft]: _o,
      [pt]: [!0, { [ft]: rm, [pt]: [nv, "supportsDualStack"] }],
    },
    Xx = [tv],
    Qx = [rv],
    Zx = [{ [Wn]: "Region" }],
    l1 = {
      version: "1.0",
      parameters: { Region: Gx, UseDualStack: Wx, UseFIPS: Wx, Endpoint: Gx },
      rules: [
        {
          conditions: [{ [ft]: Vx, [pt]: [Kx] }],
          rules: [
            {
              conditions: Xx,
              error:
                "Invalid Configuration: FIPS and custom endpoint are not supported",
              type: Vn,
            },
            {
              conditions: Qx,
              error:
                "Invalid Configuration: Dualstack and custom endpoint are not supported",
              type: Vn,
            },
            { endpoint: { url: Kx, properties: ut, headers: ut }, type: Gn },
          ],
          type: Kt,
        },
        {
          conditions: [{ [ft]: Vx, [pt]: Zx }],
          rules: [
            {
              conditions: [{ [ft]: "aws.partition", [pt]: Zx, assign: tm }],
              rules: [
                {
                  conditions: [tv, rv],
                  rules: [
                    {
                      conditions: [{ [ft]: _o, [pt]: [qx, Jx] }, Yx],
                      rules: [
                        {
                          endpoint: {
                            url: "https://portal.sso-fips.{Region}.{PartitionResult#dualStackDnsSuffix}",
                            properties: ut,
                            headers: ut,
                          },
                          type: Gn,
                        },
                      ],
                      type: Kt,
                    },
                    {
                      error:
                        "FIPS and DualStack are enabled, but this partition does not support one or both",
                      type: Vn,
                    },
                  ],
                  type: Kt,
                },
                {
                  conditions: Xx,
                  rules: [
                    {
                      conditions: [{ [ft]: _o, [pt]: [Jx, qx] }],
                      rules: [
                        {
                          conditions: [
                            {
                              [ft]: "stringEquals",
                              [pt]: [
                                { [ft]: rm, [pt]: [nv, "name"] },
                                "aws-us-gov",
                              ],
                            },
                          ],
                          endpoint: {
                            url: "https://portal.sso.{Region}.amazonaws.com",
                            properties: ut,
                            headers: ut,
                          },
                          type: Gn,
                        },
                        {
                          endpoint: {
                            url: "https://portal.sso-fips.{Region}.{PartitionResult#dnsSuffix}",
                            properties: ut,
                            headers: ut,
                          },
                          type: Gn,
                        },
                      ],
                      type: Kt,
                    },
                    {
                      error:
                        "FIPS is enabled but this partition does not support FIPS",
                      type: Vn,
                    },
                  ],
                  type: Kt,
                },
                {
                  conditions: Qx,
                  rules: [
                    {
                      conditions: [Yx],
                      rules: [
                        {
                          endpoint: {
                            url: "https://portal.sso.{Region}.{PartitionResult#dualStackDnsSuffix}",
                            properties: ut,
                            headers: ut,
                          },
                          type: Gn,
                        },
                      ],
                      type: Kt,
                    },
                    {
                      error:
                        "DualStack is enabled but this partition does not support DualStack",
                      type: Vn,
                    },
                  ],
                  type: Kt,
                },
                {
                  endpoint: {
                    url: "https://portal.sso.{Region}.{PartitionResult#dnsSuffix}",
                    properties: ut,
                    headers: ut,
                  },
                  type: Gn,
                },
              ],
              type: Kt,
            },
          ],
          type: Kt,
        },
        { error: "Invalid Configuration: Missing Region", type: Vn },
      ],
    };
  Xa.ruleSet = l1;
});
var ov = P((Qa) => {
  "use strict";
  Object.defineProperty(Qa, "__esModule", { value: !0 });
  Qa.defaultEndpointResolver = void 0;
  var u1 = Cn(),
    nm = Tn(),
    f1 = sv(),
    p1 = new nm.EndpointCache({
      size: 50,
      params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
    }),
    m1 = (e, t = {}) =>
      p1.get(e, () =>
        (0, nm.resolveEndpoint)(f1.ruleSet, {
          endpointParams: e,
          logger: t.logger,
        }),
      );
  Qa.defaultEndpointResolver = m1;
  nm.customEndpointFunctions.aws = u1.awsEndpointFunctions;
});
var cv = P((Za) => {
  "use strict";
  Object.defineProperty(Za, "__esModule", { value: !0 });
  Za.getRuntimeConfig = void 0;
  var h1 = (Ne(), ce(Tt)),
    g1 = (Je(), ce(vn)),
    S1 = Y(),
    y1 = lr(),
    iv = De(),
    av = Oe(),
    E1 = em(),
    _1 = ov(),
    w1 = (e) => ({
      apiVersion: "2019-06-10",
      base64Decoder: e?.base64Decoder ?? iv.fromBase64,
      base64Encoder: e?.base64Encoder ?? iv.toBase64,
      disableHostPrefix: e?.disableHostPrefix ?? !1,
      endpointProvider: e?.endpointProvider ?? _1.defaultEndpointResolver,
      extensions: e?.extensions ?? [],
      httpAuthSchemeProvider:
        e?.httpAuthSchemeProvider ?? E1.defaultSSOHttpAuthSchemeProvider,
      httpAuthSchemes: e?.httpAuthSchemes ?? [
        {
          schemeId: "aws.auth#sigv4",
          identityProvider: (t) => t.getIdentityProvider("aws.auth#sigv4"),
          signer: new h1.AwsSdkSigV4Signer(),
        },
        {
          schemeId: "smithy.api#noAuth",
          identityProvider: (t) =>
            t.getIdentityProvider("smithy.api#noAuth") || (async () => ({})),
          signer: new g1.NoAuthSigner(),
        },
      ],
      logger: e?.logger ?? new S1.NoOpLogger(),
      serviceId: e?.serviceId ?? "SSO",
      urlParser: e?.urlParser ?? y1.parseUrl,
      utf8Decoder: e?.utf8Decoder ?? av.fromUtf8,
      utf8Encoder: e?.utf8Encoder ?? av.toUtf8,
    });
  Za.getRuntimeConfig = w1;
});
var pv = P((tc) => {
  "use strict";
  Object.defineProperty(tc, "__esModule", { value: !0 });
  tc.getRuntimeConfig = void 0;
  var b1 = (vs(), ce(xs)),
    x1 = b1.__importDefault(Bx()),
    dv = (Ne(), ce(Tt)),
    lv = Qs(),
    ec = It(),
    v1 = Zs(),
    uv = Gt(),
    dn = xr(),
    fv = zr(),
    T1 = eo(),
    C1 = Un(),
    I1 = cv(),
    A1 = Y(),
    R1 = ro(),
    N1 = Y(),
    P1 = (e) => {
      (0, N1.emitWarningIfUnsupportedVersion)(process.version);
      let t = (0, R1.resolveDefaultsModeConfig)(e),
        r = () => t().then(A1.loadConfigsForDefaultMode),
        n = (0, I1.getRuntimeConfig)(e);
      (0, dv.emitWarningIfUnsupportedVersion)(process.version);
      let s = { profile: e?.profile, logger: n.logger };
      return {
        ...n,
        ...e,
        runtime: "node",
        defaultsMode: t,
        authSchemePreference:
          e?.authSchemePreference ??
          (0, dn.loadConfig)(dv.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, s),
        bodyLengthChecker: e?.bodyLengthChecker ?? T1.calculateBodyLength,
        defaultUserAgentProvider:
          e?.defaultUserAgentProvider ??
          (0, lv.createDefaultUserAgentProvider)({
            serviceId: n.serviceId,
            clientVersion: x1.default.version,
          }),
        maxAttempts:
          e?.maxAttempts ??
          (0, dn.loadConfig)(uv.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, e),
        region:
          e?.region ??
          (0, dn.loadConfig)(ec.NODE_REGION_CONFIG_OPTIONS, {
            ...ec.NODE_REGION_CONFIG_FILE_OPTIONS,
            ...s,
          }),
        requestHandler: fv.NodeHttpHandler.create(e?.requestHandler ?? r),
        retryMode:
          e?.retryMode ??
          (0, dn.loadConfig)(
            {
              ...uv.NODE_RETRY_MODE_CONFIG_OPTIONS,
              default: async () =>
                (await r()).retryMode || C1.DEFAULT_RETRY_MODE,
            },
            e,
          ),
        sha256: e?.sha256 ?? v1.Hash.bind(null, "sha256"),
        streamCollector: e?.streamCollector ?? fv.streamCollector,
        useDualstackEndpoint:
          e?.useDualstackEndpoint ??
          (0, dn.loadConfig)(ec.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, s),
        useFipsEndpoint:
          e?.useFipsEndpoint ??
          (0, dn.loadConfig)(ec.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, s),
        userAgentAppId:
          e?.userAgentAppId ??
          (0, dn.loadConfig)(lv.NODE_APP_ID_CONFIG_OPTIONS, s),
      };
    };
  tc.getRuntimeConfig = P1;
});
var Ov = P((xe) => {
  "use strict";
  var mv = cs(),
    O1 = ds(),
    D1 = ls(),
    hv = Ln(),
    M1 = It(),
    Jt = (Je(), ce(vn)),
    k1 = Bs(),
    vo = vr(),
    gv = Gt(),
    F = Y(),
    Sv = em(),
    F1 = pv(),
    yv = no(),
    Ev = me(),
    dc = sr(),
    wo = (Ne(), ce(Tt)),
    L1 = (e) =>
      Object.assign(e, {
        useDualstackEndpoint: e.useDualstackEndpoint ?? !1,
        useFipsEndpoint: e.useFipsEndpoint ?? !1,
        defaultSigningName: "awsssoportal",
      }),
    lc = {
      UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
      Endpoint: { type: "builtInParams", name: "endpoint" },
      Region: { type: "builtInParams", name: "region" },
      UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
    },
    $1 = (e) => {
      let t = e.httpAuthSchemes,
        r = e.httpAuthSchemeProvider,
        n = e.credentials;
      return {
        setHttpAuthScheme(s) {
          let o = t.findIndex((i) => i.schemeId === s.schemeId);
          o === -1 ? t.push(s) : t.splice(o, 1, s);
        },
        httpAuthSchemes() {
          return t;
        },
        setHttpAuthSchemeProvider(s) {
          r = s;
        },
        httpAuthSchemeProvider() {
          return r;
        },
        setCredentials(s) {
          n = s;
        },
        credentials() {
          return n;
        },
      };
    },
    U1 = (e) => ({
      httpAuthSchemes: e.httpAuthSchemes(),
      httpAuthSchemeProvider: e.httpAuthSchemeProvider(),
      credentials: e.credentials(),
    }),
    H1 = (e, t) => {
      let r = Object.assign(
        yv.getAwsRegionExtensionConfiguration(e),
        F.getDefaultExtensionConfiguration(e),
        Ev.getHttpHandlerExtensionConfiguration(e),
        $1(e),
      );
      return (
        t.forEach((n) => n.configure(r)),
        Object.assign(
          e,
          yv.resolveAwsRegionExtensionConfiguration(r),
          F.resolveDefaultRuntimeConfig(r),
          Ev.resolveHttpHandlerRuntimeConfig(r),
          U1(r),
        )
      );
    },
    Kn = class extends F.Client {
      config;
      constructor(...[t]) {
        let r = F1.getRuntimeConfig(t || {});
        (super(r), (this.initConfig = r));
        let n = L1(r),
          s = hv.resolveUserAgentConfig(n),
          o = gv.resolveRetryConfig(s),
          i = M1.resolveRegionConfig(o),
          a = mv.resolveHostHeaderConfig(i),
          d = vo.resolveEndpointConfig(a),
          l = Sv.resolveHttpAuthSchemeConfig(d),
          p = H1(l, t?.extensions || []);
        ((this.config = p),
          this.middlewareStack.use(hv.getUserAgentPlugin(this.config)),
          this.middlewareStack.use(gv.getRetryPlugin(this.config)),
          this.middlewareStack.use(k1.getContentLengthPlugin(this.config)),
          this.middlewareStack.use(mv.getHostHeaderPlugin(this.config)),
          this.middlewareStack.use(O1.getLoggerPlugin(this.config)),
          this.middlewareStack.use(D1.getRecursionDetectionPlugin(this.config)),
          this.middlewareStack.use(
            Jt.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
              httpAuthSchemeParametersProvider:
                Sv.defaultSSOHttpAuthSchemeParametersProvider,
              identityProviderConfigProvider: async (m) =>
                new Jt.DefaultIdentityProviderConfig({
                  "aws.auth#sigv4": m.credentials,
                }),
            }),
          ),
          this.middlewareStack.use(Jt.getHttpSigningPlugin(this.config)));
      }
      destroy() {
        super.destroy();
      }
    },
    Or = class e extends F.ServiceException {
      constructor(t) {
        (super(t), Object.setPrototypeOf(this, e.prototype));
      }
    },
    rc = class e extends Or {
      name = "InvalidRequestException";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidRequestException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    nc = class e extends Or {
      name = "ResourceNotFoundException";
      $fault = "client";
      constructor(t) {
        (super({ name: "ResourceNotFoundException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    sc = class e extends Or {
      name = "TooManyRequestsException";
      $fault = "client";
      constructor(t) {
        (super({ name: "TooManyRequestsException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    oc = class e extends Or {
      name = "UnauthorizedException";
      $fault = "client";
      constructor(t) {
        (super({ name: "UnauthorizedException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    _v = (e) => ({
      ...e,
      ...(e.accessToken && { accessToken: F.SENSITIVE_STRING }),
    }),
    wv = (e) => ({
      ...e,
      ...(e.secretAccessKey && { secretAccessKey: F.SENSITIVE_STRING }),
      ...(e.sessionToken && { sessionToken: F.SENSITIVE_STRING }),
    }),
    bv = (e) => ({
      ...e,
      ...(e.roleCredentials && { roleCredentials: wv(e.roleCredentials) }),
    }),
    xv = (e) => ({
      ...e,
      ...(e.accessToken && { accessToken: F.SENSITIVE_STRING }),
    }),
    vv = (e) => ({
      ...e,
      ...(e.accessToken && { accessToken: F.SENSITIVE_STRING }),
    }),
    Tv = (e) => ({
      ...e,
      ...(e.accessToken && { accessToken: F.SENSITIVE_STRING }),
    }),
    z1 = async (e, t) => {
      let r = Jt.requestBuilder(e, t),
        n = F.map({}, F.isSerializableHeaderValue, { [pc]: e[fc] });
      r.bp("/federation/credentials");
      let s = F.map({
        [tL]: [, F.expectNonNull(e[eL], "roleName")],
        [Iv]: [, F.expectNonNull(e[Cv], "accountId")],
      });
      return (
        r
          .m("GET")
          .h(n)
          .q(s)
          .b(void 0),
        r.build()
      );
    },
    j1 = async (e, t) => {
      let r = Jt.requestBuilder(e, t),
        n = F.map({}, F.isSerializableHeaderValue, { [pc]: e[fc] });
      r.bp("/assignment/roles");
      let s = F.map({
        [Pv]: [, e[Nv]],
        [Rv]: [() => e.maxResults !== void 0, () => e[Av].toString()],
        [Iv]: [, F.expectNonNull(e[Cv], "accountId")],
      });
      return (
        r
          .m("GET")
          .h(n)
          .q(s)
          .b(void 0),
        r.build()
      );
    },
    B1 = async (e, t) => {
      let r = Jt.requestBuilder(e, t),
        n = F.map({}, F.isSerializableHeaderValue, { [pc]: e[fc] });
      r.bp("/assignment/accounts");
      let s = F.map({
        [Pv]: [, e[Nv]],
        [Rv]: [() => e.maxResults !== void 0, () => e[Av].toString()],
      });
      return (
        r
          .m("GET")
          .h(n)
          .q(s)
          .b(void 0),
        r.build()
      );
    },
    q1 = async (e, t) => {
      let r = Jt.requestBuilder(e, t),
        n = F.map({}, F.isSerializableHeaderValue, { [pc]: e[fc] });
      return (
        r.bp("/logout"),
        r
          .m("POST")
          .h(n)
          .b(void 0),
        r.build()
      );
    },
    V1 = async (e, t) => {
      if (e.statusCode !== 200 && e.statusCode >= 300) return uc(e, t);
      let r = F.map({ $metadata: Dr(e) }),
        n = F.expectNonNull(
          F.expectObject(await wo.parseJsonBody(e.body, t)),
          "body",
        ),
        s = F.take(n, { roleCredentials: F._json });
      return (Object.assign(r, s), r);
    },
    G1 = async (e, t) => {
      if (e.statusCode !== 200 && e.statusCode >= 300) return uc(e, t);
      let r = F.map({ $metadata: Dr(e) }),
        n = F.expectNonNull(
          F.expectObject(await wo.parseJsonBody(e.body, t)),
          "body",
        ),
        s = F.take(n, { nextToken: F.expectString, roleList: F._json });
      return (Object.assign(r, s), r);
    },
    W1 = async (e, t) => {
      if (e.statusCode !== 200 && e.statusCode >= 300) return uc(e, t);
      let r = F.map({ $metadata: Dr(e) }),
        n = F.expectNonNull(
          F.expectObject(await wo.parseJsonBody(e.body, t)),
          "body",
        ),
        s = F.take(n, { accountList: F._json, nextToken: F.expectString });
      return (Object.assign(r, s), r);
    },
    K1 = async (e, t) => {
      if (e.statusCode !== 200 && e.statusCode >= 300) return uc(e, t);
      let r = F.map({ $metadata: Dr(e) });
      return (await F.collectBody(e.body, t), r);
    },
    uc = async (e, t) => {
      let r = { ...e, body: await wo.parseJsonErrorBody(e.body, t) },
        n = wo.loadRestJsonErrorCode(e, r.body);
      switch (n) {
        case "InvalidRequestException":
        case "com.amazonaws.sso#InvalidRequestException":
          throw await Y1(r);
        case "ResourceNotFoundException":
        case "com.amazonaws.sso#ResourceNotFoundException":
          throw await X1(r);
        case "TooManyRequestsException":
        case "com.amazonaws.sso#TooManyRequestsException":
          throw await Q1(r);
        case "UnauthorizedException":
        case "com.amazonaws.sso#UnauthorizedException":
          throw await Z1(r);
        default:
          let s = r.body;
          return J1({ output: e, parsedBody: s, errorCode: n });
      }
    },
    J1 = F.withBaseException(Or),
    Y1 = async (e, t) => {
      let r = F.map({}),
        n = e.body,
        s = F.take(n, { message: F.expectString });
      Object.assign(r, s);
      let o = new rc({ $metadata: Dr(e), ...r });
      return F.decorateServiceException(o, e.body);
    },
    X1 = async (e, t) => {
      let r = F.map({}),
        n = e.body,
        s = F.take(n, { message: F.expectString });
      Object.assign(r, s);
      let o = new nc({ $metadata: Dr(e), ...r });
      return F.decorateServiceException(o, e.body);
    },
    Q1 = async (e, t) => {
      let r = F.map({}),
        n = e.body,
        s = F.take(n, { message: F.expectString });
      Object.assign(r, s);
      let o = new sc({ $metadata: Dr(e), ...r });
      return F.decorateServiceException(o, e.body);
    },
    Z1 = async (e, t) => {
      let r = F.map({}),
        n = e.body,
        s = F.take(n, { message: F.expectString });
      Object.assign(r, s);
      let o = new oc({ $metadata: Dr(e), ...r });
      return F.decorateServiceException(o, e.body);
    },
    Dr = (e) => ({
      httpStatusCode: e.statusCode,
      requestId:
        e.headers["x-amzn-requestid"] ??
        e.headers["x-amzn-request-id"] ??
        e.headers["x-amz-request-id"],
      extendedRequestId: e.headers["x-amz-id-2"],
      cfId: e.headers["x-amz-cf-id"],
    }),
    Cv = "accountId",
    fc = "accessToken",
    Iv = "account_id",
    Av = "maxResults",
    Rv = "max_result",
    Nv = "nextToken",
    Pv = "next_token",
    eL = "roleName",
    tL = "role_name",
    pc = "x-amz-sso_bearer_token",
    ic = class extends F.Command.classBuilder()
      .ep(lc)
      .m(function (t, r, n, s) {
        return [
          dc.getSerdePlugin(n, this.serialize, this.deserialize),
          vo.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("SWBPortalService", "GetRoleCredentials", {})
      .n("SSOClient", "GetRoleCredentialsCommand")
      .f(_v, bv)
      .ser(z1)
      .de(V1)
      .build() {},
    bo = class extends F.Command.classBuilder()
      .ep(lc)
      .m(function (t, r, n, s) {
        return [
          dc.getSerdePlugin(n, this.serialize, this.deserialize),
          vo.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("SWBPortalService", "ListAccountRoles", {})
      .n("SSOClient", "ListAccountRolesCommand")
      .f(xv, void 0)
      .ser(j1)
      .de(G1)
      .build() {},
    xo = class extends F.Command.classBuilder()
      .ep(lc)
      .m(function (t, r, n, s) {
        return [
          dc.getSerdePlugin(n, this.serialize, this.deserialize),
          vo.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("SWBPortalService", "ListAccounts", {})
      .n("SSOClient", "ListAccountsCommand")
      .f(vv, void 0)
      .ser(B1)
      .de(W1)
      .build() {},
    ac = class extends F.Command.classBuilder()
      .ep(lc)
      .m(function (t, r, n, s) {
        return [
          dc.getSerdePlugin(n, this.serialize, this.deserialize),
          vo.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("SWBPortalService", "Logout", {})
      .n("SSOClient", "LogoutCommand")
      .f(Tv, void 0)
      .ser(q1)
      .de(K1)
      .build() {},
    rL = {
      GetRoleCredentialsCommand: ic,
      ListAccountRolesCommand: bo,
      ListAccountsCommand: xo,
      LogoutCommand: ac,
    },
    cc = class extends Kn {};
  F.createAggregatedClient(rL, cc);
  var nL = Jt.createPaginator(Kn, bo, "nextToken", "nextToken", "maxResults"),
    sL = Jt.createPaginator(Kn, xo, "nextToken", "nextToken", "maxResults");
  Object.defineProperty(xe, "$Command", {
    enumerable: !0,
    get: function () {
      return F.Command;
    },
  });
  Object.defineProperty(xe, "__Client", {
    enumerable: !0,
    get: function () {
      return F.Client;
    },
  });
  xe.GetRoleCredentialsCommand = ic;
  xe.GetRoleCredentialsRequestFilterSensitiveLog = _v;
  xe.GetRoleCredentialsResponseFilterSensitiveLog = bv;
  xe.InvalidRequestException = rc;
  xe.ListAccountRolesCommand = bo;
  xe.ListAccountRolesRequestFilterSensitiveLog = xv;
  xe.ListAccountsCommand = xo;
  xe.ListAccountsRequestFilterSensitiveLog = vv;
  xe.LogoutCommand = ac;
  xe.LogoutRequestFilterSensitiveLog = Tv;
  xe.ResourceNotFoundException = nc;
  xe.RoleCredentialsFilterSensitiveLog = wv;
  xe.SSO = cc;
  xe.SSOClient = Kn;
  xe.SSOServiceException = Or;
  xe.TooManyRequestsException = sc;
  xe.UnauthorizedException = oc;
  xe.paginateListAccountRoles = nL;
  xe.paginateListAccounts = sL;
});
var Mv = P((sm) => {
  "use strict";
  var Dv = Ov();
  Object.defineProperty(sm, "GetRoleCredentialsCommand", {
    enumerable: !0,
    get: function () {
      return Dv.GetRoleCredentialsCommand;
    },
  });
  Object.defineProperty(sm, "SSOClient", {
    enumerable: !0,
    get: function () {
      return Dv.SSOClient;
    },
  });
});
var om = P((hc) => {
  "use strict";
  var St = qe(),
    mc = qt(),
    kv = (gt(), ce(pr)),
    oL = jx(),
    Lv = (e) =>
      e &&
      (typeof e.sso_start_url == "string" ||
        typeof e.sso_account_id == "string" ||
        typeof e.sso_session == "string" ||
        typeof e.sso_region == "string" ||
        typeof e.sso_role_name == "string"),
    To = !1,
    Fv = async ({
      ssoStartUrl: e,
      ssoSession: t,
      ssoAccountId: r,
      ssoRegion: n,
      ssoRoleName: s,
      ssoClient: o,
      clientConfig: i,
      parentClientConfig: a,
      profile: d,
      filepath: l,
      configFilepath: p,
      ignoreCache: m,
      logger: g,
    }) => {
      let h,
        E =
          "To refresh this SSO session run aws sso login with the corresponding profile.";
      if (t)
        try {
          let ve = await oL.fromSso({
            profile: d,
            filepath: l,
            configFilepath: p,
            ignoreCache: m,
          })();
          h = {
            accessToken: ve.token,
            expiresAt: new Date(ve.expiration).toISOString(),
          };
        } catch (ve) {
          throw new St.CredentialsProviderError(ve.message, {
            tryNextLink: To,
            logger: g,
          });
        }
      else
        try {
          h = await mc.getSSOTokenFromFile(e);
        } catch {
          throw new St.CredentialsProviderError(
            `The SSO session associated with this profile is invalid. ${E}`,
            { tryNextLink: To, logger: g },
          );
        }
      if (new Date(h.expiresAt).getTime() - Date.now() <= 0)
        throw new St.CredentialsProviderError(
          `The SSO session associated with this profile has expired. ${E}`,
          { tryNextLink: To, logger: g },
        );
      let { accessToken: C } = h,
        { SSOClient: I, GetRoleCredentialsCommand: R } =
          await Promise.resolve().then(function () {
            return Mv();
          }),
        O =
          o ||
          new I(
            Object.assign({}, i ?? {}, {
              logger: i?.logger ?? a?.logger,
              region: i?.region ?? n,
            }),
          ),
        $;
      try {
        $ = await O.send(new R({ accountId: r, roleName: s, accessToken: C }));
      } catch (ve) {
        throw new St.CredentialsProviderError(ve, {
          tryNextLink: To,
          logger: g,
        });
      }
      let {
        roleCredentials: {
          accessKeyId: j,
          secretAccessKey: H,
          sessionToken: se,
          expiration: Le,
          credentialScope: Ve,
          accountId: ge,
        } = {},
      } = $;
      if (!j || !H || !se || !Le)
        throw new St.CredentialsProviderError(
          "SSO returns an invalid temporary credential.",
          { tryNextLink: To, logger: g },
        );
      let ue = {
        accessKeyId: j,
        secretAccessKey: H,
        sessionToken: se,
        expiration: new Date(Le),
        ...(Ve && { credentialScope: Ve }),
        ...(ge && { accountId: ge }),
      };
      return (
        t
          ? kv.setCredentialFeature(ue, "CREDENTIALS_SSO", "s")
          : kv.setCredentialFeature(ue, "CREDENTIALS_SSO_LEGACY", "u"),
        ue
      );
    },
    $v = (e, t) => {
      let {
        sso_start_url: r,
        sso_account_id: n,
        sso_region: s,
        sso_role_name: o,
      } = e;
      if (!r || !n || !s || !o)
        throw new St.CredentialsProviderError(
          `Profile is configured with invalid SSO credentials. Required parameters "sso_account_id", "sso_region", "sso_role_name", "sso_start_url". Got ${Object.keys(e).join(", ")}
Reference: https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sso.html`,
          { tryNextLink: !1, logger: t },
        );
      return e;
    },
    iL =
      (e = {}) =>
      async ({ callerClientConfig: t } = {}) => {
        e.logger?.debug("@aws-sdk/credential-provider-sso - fromSSO");
        let {
            ssoStartUrl: r,
            ssoAccountId: n,
            ssoRegion: s,
            ssoRoleName: o,
            ssoSession: i,
          } = e,
          { ssoClient: a } = e,
          d = mc.getProfileName({ profile: e.profile ?? t?.profile });
        if (!r && !n && !s && !o && !i) {
          let p = (await mc.parseKnownFiles(e))[d];
          if (!p)
            throw new St.CredentialsProviderError(
              `Profile ${d} was not found.`,
              { logger: e.logger },
            );
          if (!Lv(p))
            throw new St.CredentialsProviderError(
              `Profile ${d} is not configured with SSO credentials.`,
              { logger: e.logger },
            );
          if (p?.sso_session) {
            let R = (await mc.loadSsoSessionData(e))[p.sso_session],
              O = ` configurations in profile ${d} and sso-session ${p.sso_session}`;
            if (s && s !== R.sso_region)
              throw new St.CredentialsProviderError(
                "Conflicting SSO region" + O,
                { tryNextLink: !1, logger: e.logger },
              );
            if (r && r !== R.sso_start_url)
              throw new St.CredentialsProviderError(
                "Conflicting SSO start_url" + O,
                { tryNextLink: !1, logger: e.logger },
              );
            ((p.sso_region = R.sso_region),
              (p.sso_start_url = R.sso_start_url));
          }
          let {
            sso_start_url: m,
            sso_account_id: g,
            sso_region: h,
            sso_role_name: E,
            sso_session: C,
          } = $v(p, e.logger);
          return Fv({
            ssoStartUrl: m,
            ssoSession: C,
            ssoAccountId: g,
            ssoRegion: h,
            ssoRoleName: E,
            ssoClient: a,
            clientConfig: e.clientConfig,
            parentClientConfig: e.parentClientConfig,
            profile: d,
            filepath: e.filepath,
            configFilepath: e.configFilepath,
            ignoreCache: e.ignoreCache,
            logger: e.logger,
          });
        } else {
          if (!r || !n || !s || !o)
            throw new St.CredentialsProviderError(
              'Incomplete configuration. The fromSSO() argument hash must include "ssoStartUrl", "ssoAccountId", "ssoRegion", "ssoRoleName"',
              { tryNextLink: !1, logger: e.logger },
            );
          return Fv({
            ssoStartUrl: r,
            ssoSession: i,
            ssoAccountId: n,
            ssoRegion: s,
            ssoRoleName: o,
            ssoClient: a,
            clientConfig: e.clientConfig,
            parentClientConfig: e.parentClientConfig,
            profile: d,
            filepath: e.filepath,
            configFilepath: e.configFilepath,
            ignoreCache: e.ignoreCache,
            logger: e.logger,
          });
        }
      };
  hc.fromSSO = iL;
  hc.isSsoProfile = Lv;
  hc.validateSsoProfile = $v;
});
function aL(e) {
  return {
    schemeId: "aws.auth#sigv4",
    signingProperties: { name: "sts", region: e.region },
    propertiesExtractor: (t, r) => ({
      signingProperties: { config: t, context: r },
    }),
  };
}
function cL(e) {
  return { schemeId: "smithy.api#noAuth" };
}
var Co,
  Uv,
  Hv,
  dL,
  zv,
  im = b(() => {
    Ne();
    Co = v(Ge());
    Io();
    Uv = async (e, t, r) => ({
      operation: (0, Co.getSmithyContext)(t).operation,
      region:
        (await (0, Co.normalizeProvider)(e.region)()) ||
        (() => {
          throw new Error(
            "expected `region` to be configured for `aws.auth#sigv4`",
          );
        })(),
    });
    ((Hv = (e) => {
      let t = [];
      switch (e.operation) {
        case "AssumeRoleWithWebIdentity": {
          t.push(cL(e));
          break;
        }
        default:
          t.push(aL(e));
      }
      return t;
    }),
      (dL = (e) => Object.assign(e, { stsClientCtor: Nt })),
      (zv = (e) => {
        let t = dL(e),
          r = Qr(t);
        return Object.assign(r, {
          authSchemePreference: (0, Co.normalizeProvider)(
            e.authSchemePreference ?? [],
          ),
        });
      }));
  });
var jv,
  gc,
  Sc = b(() => {
    ((jv = (e) =>
      Object.assign(e, {
        useDualstackEndpoint: e.useDualstackEndpoint ?? !1,
        useFipsEndpoint: e.useFipsEndpoint ?? !1,
        useGlobalEndpoint: e.useGlobalEndpoint ?? !1,
        defaultSigningName: "sts",
      })),
      (gc = {
        UseGlobalEndpoint: { type: "builtInParams", name: "useGlobalEndpoint" },
        UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
        Endpoint: { type: "builtInParams", name: "endpoint" },
        Region: { type: "builtInParams", name: "region" },
        UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
      }));
  });
var Zv,
  V,
  ae,
  Mr,
  ke,
  eT,
  tT,
  Se,
  Bv,
  Pt,
  Jn,
  cm,
  qv,
  am,
  rT,
  Vv,
  Fe,
  Gv,
  nT,
  sT,
  je,
  nt,
  Wv,
  oT,
  iT,
  Kv,
  aT,
  Jv,
  Yv,
  Xv,
  Qv,
  lL,
  cT,
  dT = b(() => {
    ((Zv = "required"),
      (V = "type"),
      (ae = "argv"),
      (Mr = "booleanEquals"),
      (ke = "stringEquals"),
      (eT = "sigv4"),
      (tT = "us-east-1"),
      (Se = "endpoint"),
      (Bv = "https://sts.{Region}.{PartitionResult#dnsSuffix}"),
      (Pt = "tree"),
      (Jn = "error"),
      (cm = "getAttr"),
      (qv = { [Zv]: !1, [V]: "String" }),
      (am = { [Zv]: !0, default: !1, [V]: "Boolean" }),
      (rT = { ref: "Endpoint" }),
      (Vv = { fn: "isSet", [ae]: [{ ref: "Region" }] }),
      (Fe = { ref: "Region" }),
      (Gv = { fn: "aws.partition", [ae]: [Fe], assign: "PartitionResult" }),
      (nT = { ref: "UseFIPS" }),
      (sT = { ref: "UseDualStack" }),
      (je = {
        url: "https://sts.amazonaws.com",
        properties: {
          authSchemes: [{ name: eT, signingName: "sts", signingRegion: tT }],
        },
        headers: {},
      }),
      (nt = {}),
      (Wv = {
        conditions: [{ fn: ke, [ae]: [Fe, "aws-global"] }],
        [Se]: je,
        [V]: Se,
      }),
      (oT = { fn: Mr, [ae]: [nT, !0] }),
      (iT = { fn: Mr, [ae]: [sT, !0] }),
      (Kv = { fn: cm, [ae]: [{ ref: "PartitionResult" }, "supportsFIPS"] }),
      (aT = { ref: "PartitionResult" }),
      (Jv = {
        fn: Mr,
        [ae]: [!0, { fn: cm, [ae]: [aT, "supportsDualStack"] }],
      }),
      (Yv = [{ fn: "isSet", [ae]: [rT] }]),
      (Xv = [oT]),
      (Qv = [iT]),
      (lL = {
        version: "1.0",
        parameters: {
          Region: qv,
          UseDualStack: am,
          UseFIPS: am,
          Endpoint: qv,
          UseGlobalEndpoint: am,
        },
        rules: [
          {
            conditions: [
              { fn: Mr, [ae]: [{ ref: "UseGlobalEndpoint" }, !0] },
              { fn: "not", [ae]: Yv },
              Vv,
              Gv,
              { fn: Mr, [ae]: [nT, !1] },
              { fn: Mr, [ae]: [sT, !1] },
            ],
            rules: [
              {
                conditions: [{ fn: ke, [ae]: [Fe, "ap-northeast-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "ap-south-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "ap-southeast-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "ap-southeast-2"] }],
                endpoint: je,
                [V]: Se,
              },
              Wv,
              {
                conditions: [{ fn: ke, [ae]: [Fe, "ca-central-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "eu-central-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "eu-north-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "eu-west-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "eu-west-2"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "eu-west-3"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "sa-east-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, tT] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "us-east-2"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "us-west-1"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                conditions: [{ fn: ke, [ae]: [Fe, "us-west-2"] }],
                endpoint: je,
                [V]: Se,
              },
              {
                endpoint: {
                  url: Bv,
                  properties: {
                    authSchemes: [
                      {
                        name: eT,
                        signingName: "sts",
                        signingRegion: "{Region}",
                      },
                    ],
                  },
                  headers: nt,
                },
                [V]: Se,
              },
            ],
            [V]: Pt,
          },
          {
            conditions: Yv,
            rules: [
              {
                conditions: Xv,
                error:
                  "Invalid Configuration: FIPS and custom endpoint are not supported",
                [V]: Jn,
              },
              {
                conditions: Qv,
                error:
                  "Invalid Configuration: Dualstack and custom endpoint are not supported",
                [V]: Jn,
              },
              { endpoint: { url: rT, properties: nt, headers: nt }, [V]: Se },
            ],
            [V]: Pt,
          },
          {
            conditions: [Vv],
            rules: [
              {
                conditions: [Gv],
                rules: [
                  {
                    conditions: [oT, iT],
                    rules: [
                      {
                        conditions: [{ fn: Mr, [ae]: [!0, Kv] }, Jv],
                        rules: [
                          {
                            endpoint: {
                              url: "https://sts-fips.{Region}.{PartitionResult#dualStackDnsSuffix}",
                              properties: nt,
                              headers: nt,
                            },
                            [V]: Se,
                          },
                        ],
                        [V]: Pt,
                      },
                      {
                        error:
                          "FIPS and DualStack are enabled, but this partition does not support one or both",
                        [V]: Jn,
                      },
                    ],
                    [V]: Pt,
                  },
                  {
                    conditions: Xv,
                    rules: [
                      {
                        conditions: [{ fn: Mr, [ae]: [Kv, !0] }],
                        rules: [
                          {
                            conditions: [
                              {
                                fn: ke,
                                [ae]: [
                                  { fn: cm, [ae]: [aT, "name"] },
                                  "aws-us-gov",
                                ],
                              },
                            ],
                            endpoint: {
                              url: "https://sts.{Region}.amazonaws.com",
                              properties: nt,
                              headers: nt,
                            },
                            [V]: Se,
                          },
                          {
                            endpoint: {
                              url: "https://sts-fips.{Region}.{PartitionResult#dnsSuffix}",
                              properties: nt,
                              headers: nt,
                            },
                            [V]: Se,
                          },
                        ],
                        [V]: Pt,
                      },
                      {
                        error:
                          "FIPS is enabled but this partition does not support FIPS",
                        [V]: Jn,
                      },
                    ],
                    [V]: Pt,
                  },
                  {
                    conditions: Qv,
                    rules: [
                      {
                        conditions: [Jv],
                        rules: [
                          {
                            endpoint: {
                              url: "https://sts.{Region}.{PartitionResult#dualStackDnsSuffix}",
                              properties: nt,
                              headers: nt,
                            },
                            [V]: Se,
                          },
                        ],
                        [V]: Pt,
                      },
                      {
                        error:
                          "DualStack is enabled but this partition does not support DualStack",
                        [V]: Jn,
                      },
                    ],
                    [V]: Pt,
                  },
                  Wv,
                  {
                    endpoint: { url: Bv, properties: nt, headers: nt },
                    [V]: Se,
                  },
                ],
                [V]: Pt,
              },
            ],
            [V]: Pt,
          },
          { error: "Invalid Configuration: Missing Region", [V]: Jn },
        ],
      }),
      (cT = lL));
  });
var lT,
  Yn,
  uL,
  uT,
  fT = b(() => {
    ((lT = v(Cn())), (Yn = v(Tn())));
    dT();
    ((uL = new Yn.EndpointCache({
      size: 50,
      params: [
        "Endpoint",
        "Region",
        "UseDualStack",
        "UseFIPS",
        "UseGlobalEndpoint",
      ],
    })),
      (uT = (e, t = {}) =>
        uL.get(e, () =>
          (0, Yn.resolveEndpoint)(cT, { endpointParams: e, logger: t.logger }),
        )));
    Yn.customEndpointFunctions.aws = lT.awsEndpointFunctions;
  });
var pT,
  mT,
  yc,
  Ec,
  hT,
  gT = b(() => {
    Ne();
    Je();
    ((pT = v(Y())), (mT = v(lr())), (yc = v(De())), (Ec = v(Oe())));
    im();
    fT();
    hT = (e) => ({
      apiVersion: "2011-06-15",
      base64Decoder: e?.base64Decoder ?? yc.fromBase64,
      base64Encoder: e?.base64Encoder ?? yc.toBase64,
      disableHostPrefix: e?.disableHostPrefix ?? !1,
      endpointProvider: e?.endpointProvider ?? uT,
      extensions: e?.extensions ?? [],
      httpAuthSchemeProvider: e?.httpAuthSchemeProvider ?? Hv,
      httpAuthSchemes: e?.httpAuthSchemes ?? [
        {
          schemeId: "aws.auth#sigv4",
          identityProvider: (t) => t.getIdentityProvider("aws.auth#sigv4"),
          signer: new Ye(),
        },
        {
          schemeId: "smithy.api#noAuth",
          identityProvider: (t) =>
            t.getIdentityProvider("smithy.api#noAuth") || (async () => ({})),
          signer: new $t(),
        },
      ],
      logger: e?.logger ?? new pT.NoOpLogger(),
      serviceId: e?.serviceId ?? "STS",
      urlParser: e?.urlParser ?? mT.parseUrl,
      utf8Decoder: e?.utf8Decoder ?? Ec.fromUtf8,
      utf8Encoder: e?.utf8Encoder ?? Ec.toUtf8,
    });
  });
var _c,
  Fr,
  ST,
  wc,
  kr,
  bc,
  yT,
  ET,
  _T,
  wT,
  bT,
  xT,
  vT = b(() => {
    Lp();
    Ne();
    ((_c = v(Qs())), (Fr = v(It())));
    Je();
    ((ST = v(Zs())),
      (wc = v(Gt())),
      (kr = v(xr())),
      (bc = v(zr())),
      (yT = v(eo())),
      (ET = v(Un())));
    gT();
    ((_T = v(Y())),
      (wT = v(ro())),
      (bT = v(Y())),
      (xT = (e) => {
        (0, bT.emitWarningIfUnsupportedVersion)(process.version);
        let t = (0, wT.resolveDefaultsModeConfig)(e),
          r = () => t().then(_T.loadConfigsForDefaultMode),
          n = hT(e);
        In(process.version);
        let s = { profile: e?.profile, logger: n.logger };
        return {
          ...n,
          ...e,
          runtime: "node",
          defaultsMode: t,
          authSchemePreference:
            e?.authSchemePreference ?? (0, kr.loadConfig)(Nn, s),
          bodyLengthChecker: e?.bodyLengthChecker ?? yT.calculateBodyLength,
          defaultUserAgentProvider:
            e?.defaultUserAgentProvider ??
            (0, _c.createDefaultUserAgentProvider)({
              serviceId: n.serviceId,
              clientVersion: Ma.version,
            }),
          httpAuthSchemes: e?.httpAuthSchemes ?? [
            {
              schemeId: "aws.auth#sigv4",
              identityProvider: (o) =>
                o.getIdentityProvider("aws.auth#sigv4") ||
                (async (i) =>
                  await e.credentialDefaultProvider(i?.__config || {})()),
              signer: new Ye(),
            },
            {
              schemeId: "smithy.api#noAuth",
              identityProvider: (o) =>
                o.getIdentityProvider("smithy.api#noAuth") ||
                (async () => ({})),
              signer: new $t(),
            },
          ],
          maxAttempts:
            e?.maxAttempts ??
            (0, kr.loadConfig)(wc.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, e),
          region:
            e?.region ??
            (0, kr.loadConfig)(Fr.NODE_REGION_CONFIG_OPTIONS, {
              ...Fr.NODE_REGION_CONFIG_FILE_OPTIONS,
              ...s,
            }),
          requestHandler: bc.NodeHttpHandler.create(e?.requestHandler ?? r),
          retryMode:
            e?.retryMode ??
            (0, kr.loadConfig)(
              {
                ...wc.NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () =>
                  (await r()).retryMode || ET.DEFAULT_RETRY_MODE,
              },
              e,
            ),
          sha256: e?.sha256 ?? ST.Hash.bind(null, "sha256"),
          streamCollector: e?.streamCollector ?? bc.streamCollector,
          useDualstackEndpoint:
            e?.useDualstackEndpoint ??
            (0, kr.loadConfig)(
              Fr.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS,
              s,
            ),
          useFipsEndpoint:
            e?.useFipsEndpoint ??
            (0, kr.loadConfig)(Fr.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, s),
          userAgentAppId:
            e?.userAgentAppId ??
            (0, kr.loadConfig)(_c.NODE_APP_ID_CONFIG_OPTIONS, s),
        };
      }));
  });
var TT,
  CT,
  IT = b(() => {
    ((TT = (e) => {
      let t = e.httpAuthSchemes,
        r = e.httpAuthSchemeProvider,
        n = e.credentials;
      return {
        setHttpAuthScheme(s) {
          let o = t.findIndex((i) => i.schemeId === s.schemeId);
          o === -1 ? t.push(s) : t.splice(o, 1, s);
        },
        httpAuthSchemes() {
          return t;
        },
        setHttpAuthSchemeProvider(s) {
          r = s;
        },
        httpAuthSchemeProvider() {
          return r;
        },
        setCredentials(s) {
          n = s;
        },
        credentials() {
          return n;
        },
      };
    }),
      (CT = (e) => ({
        httpAuthSchemes: e.httpAuthSchemes(),
        httpAuthSchemeProvider: e.httpAuthSchemeProvider(),
        credentials: e.credentials(),
      })));
  });
var xc,
  vc,
  Tc,
  AT,
  RT = b(() => {
    ((xc = v(no())), (vc = v(me())), (Tc = v(Y())));
    IT();
    AT = (e, t) => {
      let r = Object.assign(
        (0, xc.getAwsRegionExtensionConfiguration)(e),
        (0, Tc.getDefaultExtensionConfiguration)(e),
        (0, vc.getHttpHandlerExtensionConfiguration)(e),
        TT(e),
      );
      return (
        t.forEach((n) => n.configure(r)),
        Object.assign(
          e,
          (0, xc.resolveAwsRegionExtensionConfiguration)(r),
          (0, Tc.resolveDefaultRuntimeConfig)(r),
          (0, vc.resolveHttpHandlerRuntimeConfig)(r),
          CT(r),
        )
      );
    };
  });
var Cc,
  NT,
  PT,
  Ic,
  OT,
  DT,
  MT,
  Ac,
  dm,
  Nt,
  Io = b(() => {
    ((Cc = v(cs())),
      (NT = v(ds())),
      (PT = v(ls())),
      (Ic = v(Ln())),
      (OT = v(It())));
    Je();
    ((DT = v(Bs())), (MT = v(vr())), (Ac = v(Gt())), (dm = v(Y())));
    im();
    Sc();
    vT();
    RT();
    Nt = class extends dm.Client {
      config;
      constructor(...[t]) {
        let r = xT(t || {});
        (super(r), (this.initConfig = r));
        let n = jv(r),
          s = (0, Ic.resolveUserAgentConfig)(n),
          o = (0, Ac.resolveRetryConfig)(s),
          i = (0, OT.resolveRegionConfig)(o),
          a = (0, Cc.resolveHostHeaderConfig)(i),
          d = (0, MT.resolveEndpointConfig)(a),
          l = zv(d),
          p = AT(l, t?.extensions || []);
        ((this.config = p),
          this.middlewareStack.use((0, Ic.getUserAgentPlugin)(this.config)),
          this.middlewareStack.use((0, Ac.getRetryPlugin)(this.config)),
          this.middlewareStack.use((0, DT.getContentLengthPlugin)(this.config)),
          this.middlewareStack.use((0, Cc.getHostHeaderPlugin)(this.config)),
          this.middlewareStack.use((0, NT.getLoggerPlugin)(this.config)),
          this.middlewareStack.use(
            (0, PT.getRecursionDetectionPlugin)(this.config),
          ),
          this.middlewareStack.use(
            fs(this.config, {
              httpAuthSchemeParametersProvider: Uv,
              identityProviderConfigProvider: async (m) =>
                new Kr({ "aws.auth#sigv4": m.credentials }),
            }),
          ),
          this.middlewareStack.use(ps(this.config)));
      }
      destroy() {
        super.destroy();
      }
    };
  });
var kT,
  Qe,
  Rc = b(() => {
    ((kT = v(Y())),
      (Qe = class e extends kT.ServiceException {
        constructor(t) {
          (super(t), Object.setPrototypeOf(this, e.prototype));
        }
      }));
  });
var lm,
  um,
  fm,
  Ao,
  Ro,
  No,
  Po,
  Oo,
  Do,
  pm,
  mm,
  Mo,
  ko = b(() => {
    lm = v(Y());
    Rc();
    ((um = (e) => ({
      ...e,
      ...(e.SecretAccessKey && { SecretAccessKey: lm.SENSITIVE_STRING }),
    })),
      (fm = (e) => ({
        ...e,
        ...(e.Credentials && { Credentials: um(e.Credentials) }),
      })),
      (Ao = class e extends Qe {
        name = "ExpiredTokenException";
        $fault = "client";
        constructor(t) {
          (super({ name: "ExpiredTokenException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (Ro = class e extends Qe {
        name = "MalformedPolicyDocumentException";
        $fault = "client";
        constructor(t) {
          (super({
            name: "MalformedPolicyDocumentException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (No = class e extends Qe {
        name = "PackedPolicyTooLargeException";
        $fault = "client";
        constructor(t) {
          (super({
            name: "PackedPolicyTooLargeException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (Po = class e extends Qe {
        name = "RegionDisabledException";
        $fault = "client";
        constructor(t) {
          (super({ name: "RegionDisabledException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (Oo = class e extends Qe {
        name = "IDPRejectedClaimException";
        $fault = "client";
        constructor(t) {
          (super({ name: "IDPRejectedClaimException", $fault: "client", ...t }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (Do = class e extends Qe {
        name = "InvalidIdentityTokenException";
        $fault = "client";
        constructor(t) {
          (super({
            name: "InvalidIdentityTokenException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }),
      (pm = (e) => ({
        ...e,
        ...(e.WebIdentityToken && { WebIdentityToken: lm.SENSITIVE_STRING }),
      })),
      (mm = (e) => ({
        ...e,
        ...(e.Credentials && { Credentials: um(e.Credentials) }),
      })),
      (Mo = class e extends Qe {
        name = "IDPCommunicationErrorException";
        $fault = "client";
        constructor(t) {
          (super({
            name: "IDPCommunicationErrorException",
            $fault: "client",
            ...t,
          }),
            Object.setPrototypeOf(this, e.prototype));
        }
      }));
  });
var FT,
  W,
  LT,
  $T,
  UT,
  HT,
  zT,
  fL,
  pL,
  mL,
  hL,
  gL,
  SL,
  yL,
  EL,
  _L,
  jT,
  wL,
  bL,
  xL,
  vL,
  TL,
  CL,
  BT,
  IL,
  AL,
  qT,
  RL,
  NL,
  PL,
  OL,
  DL,
  ML,
  kL,
  Xt,
  FL,
  VT,
  GT,
  WT,
  KT,
  hm,
  LL,
  gm,
  Xn,
  $L,
  Sm,
  ym,
  Qn,
  Em,
  Zn,
  _m,
  wm,
  bm,
  es,
  ts,
  xm,
  vm,
  Tm,
  rs,
  Cm,
  ns,
  ss,
  Im,
  Am,
  Yt,
  Rm,
  Nm,
  Pm,
  Om,
  Dm,
  JT,
  Mm,
  km,
  Fm,
  Ce,
  YT,
  UL,
  Lm = b(() => {
    Ne();
    ((FT = v(me())), (W = v(Y())));
    ko();
    Rc();
    ((LT = async (e, t) => {
      let r = GT,
        n;
      return (
        (n = YT({ ...EL(e, t), [KT]: LL, [JT]: WT })),
        VT(t, r, "/", void 0, n)
      );
    }),
      ($T = async (e, t) => {
        let r = GT,
          n;
        return (
          (n = YT({ ..._L(e, t), [KT]: $L, [JT]: WT })),
          VT(t, r, "/", void 0, n)
        );
      }),
      (UT = async (e, t) => {
        if (e.statusCode >= 300) return zT(e, t);
        let r = await Hs(e.body, t),
          n = {};
        return ((n = IL(r.AssumeRoleResult, t)), { $metadata: Xt(e), ...n });
      }),
      (HT = async (e, t) => {
        if (e.statusCode >= 300) return zT(e, t);
        let r = await Hs(e.body, t),
          n = {};
        return (
          (n = AL(r.AssumeRoleWithWebIdentityResult, t)),
          { $metadata: Xt(e), ...n }
        );
      }),
      (zT = async (e, t) => {
        let r = { ...e, body: await Zf(e.body, t) },
          n = UL(e, r.body);
        switch (n) {
          case "ExpiredTokenException":
          case "com.amazonaws.sts#ExpiredTokenException":
            throw await fL(r, t);
          case "MalformedPolicyDocument":
          case "com.amazonaws.sts#MalformedPolicyDocumentException":
            throw await gL(r, t);
          case "PackedPolicyTooLarge":
          case "com.amazonaws.sts#PackedPolicyTooLargeException":
            throw await SL(r, t);
          case "RegionDisabledException":
          case "com.amazonaws.sts#RegionDisabledException":
            throw await yL(r, t);
          case "IDPCommunicationError":
          case "com.amazonaws.sts#IDPCommunicationErrorException":
            throw await pL(r, t);
          case "IDPRejectedClaim":
          case "com.amazonaws.sts#IDPRejectedClaimException":
            throw await mL(r, t);
          case "InvalidIdentityToken":
          case "com.amazonaws.sts#InvalidIdentityTokenException":
            throw await hL(r, t);
          default:
            let s = r.body;
            return FL({ output: e, parsedBody: s.Error, errorCode: n });
        }
      }),
      (fL = async (e, t) => {
        let r = e.body,
          n = RL(r.Error, t),
          s = new Ao({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (pL = async (e, t) => {
        let r = e.body,
          n = NL(r.Error, t),
          s = new Mo({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (mL = async (e, t) => {
        let r = e.body,
          n = PL(r.Error, t),
          s = new Oo({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (hL = async (e, t) => {
        let r = e.body,
          n = OL(r.Error, t),
          s = new Do({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (gL = async (e, t) => {
        let r = e.body,
          n = DL(r.Error, t),
          s = new Ro({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (SL = async (e, t) => {
        let r = e.body,
          n = ML(r.Error, t),
          s = new No({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (yL = async (e, t) => {
        let r = e.body,
          n = kL(r.Error, t),
          s = new Po({ $metadata: Xt(e), ...n });
        return (0, W.decorateServiceException)(s, r);
      }),
      (EL = (e, t) => {
        let r = {};
        if (
          (e[ns] != null && (r[ns] = e[ns]),
          e[ss] != null && (r[ss] = e[ss]),
          e[ts] != null)
        ) {
          let n = jT(e[ts], t);
          (e[ts]?.length === 0 && (r.PolicyArns = []),
            Object.entries(n).forEach(([s, o]) => {
              let i = `PolicyArns.${s}`;
              r[i] = o;
            }));
        }
        if (
          (e[es] != null && (r[es] = e[es]),
          e[Zn] != null && (r[Zn] = e[Zn]),
          e[Pm] != null)
        ) {
          let n = CL(e[Pm], t);
          (e[Pm]?.length === 0 && (r.Tags = []),
            Object.entries(n).forEach(([s, o]) => {
              let i = `Tags.${s}`;
              r[i] = o;
            }));
        }
        if (e[Dm] != null) {
          let n = TL(e[Dm], t);
          (e[Dm]?.length === 0 && (r.TransitiveTagKeys = []),
            Object.entries(n).forEach(([s, o]) => {
              let i = `TransitiveTagKeys.${s}`;
              r[i] = o;
            }));
        }
        if (
          (e[wm] != null && (r[wm] = e[wm]),
          e[Rm] != null && (r[Rm] = e[Rm]),
          e[Om] != null && (r[Om] = e[Om]),
          e[Yt] != null && (r[Yt] = e[Yt]),
          e[vm] != null)
        ) {
          let n = xL(e[vm], t);
          (e[vm]?.length === 0 && (r.ProvidedContexts = []),
            Object.entries(n).forEach(([s, o]) => {
              let i = `ProvidedContexts.${s}`;
              r[i] = o;
            }));
        }
        return r;
      }),
      (_L = (e, t) => {
        let r = {};
        if (
          (e[ns] != null && (r[ns] = e[ns]),
          e[ss] != null && (r[ss] = e[ss]),
          e[km] != null && (r[km] = e[km]),
          e[Tm] != null && (r[Tm] = e[Tm]),
          e[ts] != null)
        ) {
          let n = jT(e[ts], t);
          (e[ts]?.length === 0 && (r.PolicyArns = []),
            Object.entries(n).forEach(([s, o]) => {
              let i = `PolicyArns.${s}`;
              r[i] = o;
            }));
        }
        return (
          e[es] != null && (r[es] = e[es]),
          e[Zn] != null && (r[Zn] = e[Zn]),
          r
        );
      }),
      (jT = (e, t) => {
        let r = {},
          n = 1;
        for (let s of e) {
          if (s === null) continue;
          let o = wL(s, t);
          (Object.entries(o).forEach(([i, a]) => {
            r[`member.${n}.${i}`] = a;
          }),
            n++);
        }
        return r;
      }),
      (wL = (e, t) => {
        let r = {};
        return (e[Fm] != null && (r[Fm] = e[Fm]), r);
      }),
      (bL = (e, t) => {
        let r = {};
        return (
          e[xm] != null && (r[xm] = e[xm]),
          e[Em] != null && (r[Em] = e[Em]),
          r
        );
      }),
      (xL = (e, t) => {
        let r = {},
          n = 1;
        for (let s of e) {
          if (s === null) continue;
          let o = bL(s, t);
          (Object.entries(o).forEach(([i, a]) => {
            r[`member.${n}.${i}`] = a;
          }),
            n++);
        }
        return r;
      }),
      (vL = (e, t) => {
        let r = {};
        return (
          e[bm] != null && (r[bm] = e[bm]),
          e[Mm] != null && (r[Mm] = e[Mm]),
          r
        );
      }),
      (TL = (e, t) => {
        let r = {},
          n = 1;
        for (let s of e) s !== null && ((r[`member.${n}`] = s), n++);
        return r;
      }),
      (CL = (e, t) => {
        let r = {},
          n = 1;
        for (let s of e) {
          if (s === null) continue;
          let o = vL(s, t);
          (Object.entries(o).forEach(([i, a]) => {
            r[`member.${n}.${i}`] = a;
          }),
            n++);
        }
        return r;
      }),
      (BT = (e, t) => {
        let r = {};
        return (
          e[gm] != null && (r[gm] = (0, W.expectString)(e[gm])),
          e[Sm] != null && (r[Sm] = (0, W.expectString)(e[Sm])),
          r
        );
      }),
      (IL = (e, t) => {
        let r = {};
        return (
          e[Qn] != null && (r[Qn] = qT(e[Qn], t)),
          e[Xn] != null && (r[Xn] = BT(e[Xn], t)),
          e[rs] != null && (r[rs] = (0, W.strictParseInt32)(e[rs])),
          e[Yt] != null && (r[Yt] = (0, W.expectString)(e[Yt])),
          r
        );
      }),
      (AL = (e, t) => {
        let r = {};
        return (
          e[Qn] != null && (r[Qn] = qT(e[Qn], t)),
          e[Am] != null && (r[Am] = (0, W.expectString)(e[Am])),
          e[Xn] != null && (r[Xn] = BT(e[Xn], t)),
          e[rs] != null && (r[rs] = (0, W.strictParseInt32)(e[rs])),
          e[Cm] != null && (r[Cm] = (0, W.expectString)(e[Cm])),
          e[ym] != null && (r[ym] = (0, W.expectString)(e[ym])),
          e[Yt] != null && (r[Yt] = (0, W.expectString)(e[Yt])),
          r
        );
      }),
      (qT = (e, t) => {
        let r = {};
        return (
          e[hm] != null && (r[hm] = (0, W.expectString)(e[hm])),
          e[Im] != null && (r[Im] = (0, W.expectString)(e[Im])),
          e[Nm] != null && (r[Nm] = (0, W.expectString)(e[Nm])),
          e[_m] != null &&
            (r[_m] = (0, W.expectNonNull)(
              (0, W.parseRfc3339DateTimeWithOffset)(e[_m]),
            )),
          r
        );
      }),
      (RL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (NL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (PL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (OL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (DL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (ML = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (kL = (e, t) => {
        let r = {};
        return (e[Ce] != null && (r[Ce] = (0, W.expectString)(e[Ce])), r);
      }),
      (Xt = (e) => ({
        httpStatusCode: e.statusCode,
        requestId:
          e.headers["x-amzn-requestid"] ??
          e.headers["x-amzn-request-id"] ??
          e.headers["x-amz-request-id"],
        extendedRequestId: e.headers["x-amz-id-2"],
        cfId: e.headers["x-amz-cf-id"],
      })),
      (FL = (0, W.withBaseException)(Qe)),
      (VT = async (e, t, r, n, s) => {
        let {
            hostname: o,
            protocol: i = "https",
            port: a,
            path: d,
          } = await e.endpoint(),
          l = {
            protocol: i,
            hostname: o,
            port: a,
            method: "POST",
            path: d.endsWith("/") ? d.slice(0, -1) + r : d + r,
            headers: t,
          };
        return (
          n !== void 0 && (l.hostname = n),
          s !== void 0 && (l.body = s),
          new FT.HttpRequest(l)
        );
      }),
      (GT = { "content-type": "application/x-www-form-urlencoded" }),
      (WT = "2011-06-15"),
      (KT = "Action"),
      (hm = "AccessKeyId"),
      (LL = "AssumeRole"),
      (gm = "AssumedRoleId"),
      (Xn = "AssumedRoleUser"),
      ($L = "AssumeRoleWithWebIdentity"),
      (Sm = "Arn"),
      (ym = "Audience"),
      (Qn = "Credentials"),
      (Em = "ContextAssertion"),
      (Zn = "DurationSeconds"),
      (_m = "Expiration"),
      (wm = "ExternalId"),
      (bm = "Key"),
      (es = "Policy"),
      (ts = "PolicyArns"),
      (xm = "ProviderArn"),
      (vm = "ProvidedContexts"),
      (Tm = "ProviderId"),
      (rs = "PackedPolicySize"),
      (Cm = "Provider"),
      (ns = "RoleArn"),
      (ss = "RoleSessionName"),
      (Im = "SecretAccessKey"),
      (Am = "SubjectFromWebIdentityToken"),
      (Yt = "SourceIdentity"),
      (Rm = "SerialNumber"),
      (Nm = "SessionToken"),
      (Pm = "Tags"),
      (Om = "TokenCode"),
      (Dm = "TransitiveTagKeys"),
      (JT = "Version"),
      (Mm = "Value"),
      (km = "WebIdentityToken"),
      (Fm = "arn"),
      (Ce = "message"),
      (YT = (e) =>
        Object.entries(e)
          .map(
            ([t, r]) =>
              (0, W.extendedEncodeURIComponent)(t) +
              "=" +
              (0, W.extendedEncodeURIComponent)(r),
          )
          .join("&")),
      (UL = (e, t) => {
        if (t.Error?.Code !== void 0) return t.Error.Code;
        if (e.statusCode == 404) return "NotFound";
      }));
  });
var XT,
  QT,
  ZT,
  ln,
  Nc = b(() => {
    ((XT = v(vr())), (QT = v(sr())), (ZT = v(Y())));
    Sc();
    ko();
    Lm();
    ln = class extends (
      ZT.Command.classBuilder()
        .ep(gc)
        .m(function (t, r, n, s) {
          return [
            (0, QT.getSerdePlugin)(n, this.serialize, this.deserialize),
            (0, XT.getEndpointPlugin)(n, t.getEndpointParameterInstructions()),
          ];
        })
        .s("AWSSecurityTokenServiceV20110615", "AssumeRole", {})
        .n("STSClient", "AssumeRoleCommand")
        .f(void 0, fm)
        .ser(LT)
        .de(UT)
        .build()
    ) {};
  });
var eC,
  tC,
  rC,
  un,
  Pc = b(() => {
    ((eC = v(vr())), (tC = v(sr())), (rC = v(Y())));
    Sc();
    ko();
    Lm();
    un = class extends (
      rC.Command.classBuilder()
        .ep(gc)
        .m(function (t, r, n, s) {
          return [
            (0, tC.getSerdePlugin)(n, this.serialize, this.deserialize),
            (0, eC.getEndpointPlugin)(n, t.getEndpointParameterInstructions()),
          ];
        })
        .s("AWSSecurityTokenServiceV20110615", "AssumeRoleWithWebIdentity", {})
        .n("STSClient", "AssumeRoleWithWebIdentityCommand")
        .f(pm, mm)
        .ser($T)
        .de(HT)
        .build()
    ) {};
  });
var nC,
  HL,
  Oc,
  sC = b(() => {
    nC = v(Y());
    Nc();
    Pc();
    Io();
    ((HL = { AssumeRoleCommand: ln, AssumeRoleWithWebIdentityCommand: un }),
      (Oc = class extends Nt {}));
    (0, nC.createAggregatedClient)(HL, Oc);
  });
var oC = b(() => {
  Nc();
  Pc();
});
var iC = b(() => {
  ko();
});
var aC,
  cC,
  dC,
  lC,
  uC,
  fC,
  pC = b(() => {
    gt();
    Nc();
    Pc();
    ((aC = "us-east-1"),
      (cC = (e) => {
        if (typeof e?.Arn == "string") {
          let t = e.Arn.split(":");
          if (t.length > 4 && t[4] !== "") return t[4];
        }
      }),
      (dC = async (e, t, r) => {
        let n = typeof e == "function" ? await e() : e,
          s = typeof t == "function" ? await t() : t;
        return (
          r?.debug?.(
            "@aws-sdk/client-sts::resolveRegion",
            "accepting first of:",
            `${n} (provider)`,
            `${s} (parent client)`,
            `${aC} (STS default)`,
          ),
          n ?? s ?? aC
        );
      }),
      (lC = (e, t) => {
        let r, n;
        return async (s, o) => {
          if (((n = s), !r)) {
            let {
                logger: p = e?.parentClientConfig?.logger,
                region: m,
                requestHandler: g = e?.parentClientConfig?.requestHandler,
                credentialProviderLogger: h,
              } = e,
              E = await dC(m, e?.parentClientConfig?.region, h),
              C = !fC(g);
            r = new t({
              profile: e?.parentClientConfig?.profile,
              credentialDefaultProvider: () => async () => n,
              region: E,
              requestHandler: C ? g : void 0,
              logger: p,
            });
          }
          let { Credentials: i, AssumedRoleUser: a } = await r.send(new ln(o));
          if (!i || !i.AccessKeyId || !i.SecretAccessKey)
            throw new Error(
              `Invalid response from STS.assumeRole call with role ${o.RoleArn}`,
            );
          let d = cC(a),
            l = {
              accessKeyId: i.AccessKeyId,
              secretAccessKey: i.SecretAccessKey,
              sessionToken: i.SessionToken,
              expiration: i.Expiration,
              ...(i.CredentialScope && { credentialScope: i.CredentialScope }),
              ...(d && { accountId: d }),
            };
          return (fr(l, "CREDENTIALS_STS_ASSUME_ROLE", "i"), l);
        };
      }),
      (uC = (e, t) => {
        let r;
        return async (n) => {
          if (!r) {
            let {
                logger: d = e?.parentClientConfig?.logger,
                region: l,
                requestHandler: p = e?.parentClientConfig?.requestHandler,
                credentialProviderLogger: m,
              } = e,
              g = await dC(l, e?.parentClientConfig?.region, m),
              h = !fC(p);
            r = new t({
              profile: e?.parentClientConfig?.profile,
              region: g,
              requestHandler: h ? p : void 0,
              logger: d,
            });
          }
          let { Credentials: s, AssumedRoleUser: o } = await r.send(new un(n));
          if (!s || !s.AccessKeyId || !s.SecretAccessKey)
            throw new Error(
              `Invalid response from STS.assumeRoleWithWebIdentity call with role ${n.RoleArn}`,
            );
          let i = cC(o),
            a = {
              accessKeyId: s.AccessKeyId,
              secretAccessKey: s.SecretAccessKey,
              sessionToken: s.SessionToken,
              expiration: s.Expiration,
              ...(s.CredentialScope && { credentialScope: s.CredentialScope }),
              ...(i && { accountId: i }),
            };
          return (
            i && fr(a, "RESOLVED_ACCOUNT_ID", "T"),
            fr(a, "CREDENTIALS_STS_ASSUME_ROLE_WEB_ID", "k"),
            a
          );
        };
      }),
      (fC = (e) => e?.metadata?.handlerProtocol === "h2"));
  });
var mC,
  hC,
  gC,
  zL,
  SC = b(() => {
    pC();
    Io();
    ((mC = (e, t) =>
      t
        ? class extends e {
            constructor(n) {
              super(n);
              for (let s of t) this.middlewareStack.use(s);
            }
          }
        : e),
      (hC = (e = {}, t) => lC(e, mC(Nt, t))),
      (gC = (e = {}, t) => uC(e, mC(Nt, t))),
      (zL = (e) => (t) =>
        e({ roleAssumer: hC(t), roleAssumerWithWebIdentity: gC(t), ...t })));
  });
var $m = {};
st($m, {
  AssumeRoleCommand: () => ln,
  AssumeRoleResponseFilterSensitiveLog: () => fm,
  AssumeRoleWithWebIdentityCommand: () => un,
  AssumeRoleWithWebIdentityRequestFilterSensitiveLog: () => pm,
  AssumeRoleWithWebIdentityResponseFilterSensitiveLog: () => mm,
  CredentialsFilterSensitiveLog: () => um,
  ExpiredTokenException: () => Ao,
  IDPCommunicationErrorException: () => Mo,
  IDPRejectedClaimException: () => Oo,
  InvalidIdentityTokenException: () => Do,
  MalformedPolicyDocumentException: () => Ro,
  PackedPolicyTooLargeException: () => No,
  RegionDisabledException: () => Po,
  STS: () => Oc,
  STSClient: () => Nt,
  STSServiceException: () => Qe,
  __Client: () => dm.Client,
  decorateDefaultCredentialProvider: () => zL,
  getDefaultRoleAssumer: () => hC,
  getDefaultRoleAssumerWithWebIdentity: () => gC,
});
var Um = b(() => {
  Io();
  sC();
  oC();
  iC();
  SC();
  Rc();
});
var jm = P((yC) => {
  "use strict";
  var zm = qt(),
    Hm = qe(),
    jL = require("child_process"),
    BL = require("util"),
    qL = (gt(), ce(pr)),
    VL = (e, t, r) => {
      if (t.Version !== 1)
        throw Error(
          `Profile ${e} credential_process did not return Version 1.`,
        );
      if (t.AccessKeyId === void 0 || t.SecretAccessKey === void 0)
        throw Error(
          `Profile ${e} credential_process returned invalid credentials.`,
        );
      if (t.Expiration) {
        let o = new Date();
        if (new Date(t.Expiration) < o)
          throw Error(
            `Profile ${e} credential_process returned expired credentials.`,
          );
      }
      let n = t.AccountId;
      !n && r?.[e]?.aws_account_id && (n = r[e].aws_account_id);
      let s = {
        accessKeyId: t.AccessKeyId,
        secretAccessKey: t.SecretAccessKey,
        ...(t.SessionToken && { sessionToken: t.SessionToken }),
        ...(t.Expiration && { expiration: new Date(t.Expiration) }),
        ...(t.CredentialScope && { credentialScope: t.CredentialScope }),
        ...(n && { accountId: n }),
      };
      return (qL.setCredentialFeature(s, "CREDENTIALS_PROCESS", "w"), s);
    },
    GL = async (e, t, r) => {
      let n = t[e];
      if (t[e]) {
        let s = n.credential_process;
        if (s !== void 0) {
          let o = BL.promisify(
            zm.externalDataInterceptor?.getTokenRecord?.().exec ?? jL.exec,
          );
          try {
            let { stdout: i } = await o(s),
              a;
            try {
              a = JSON.parse(i.trim());
            } catch {
              throw Error(
                `Profile ${e} credential_process returned invalid JSON.`,
              );
            }
            return VL(e, a, t);
          } catch (i) {
            throw new Hm.CredentialsProviderError(i.message, { logger: r });
          }
        } else
          throw new Hm.CredentialsProviderError(
            `Profile ${e} did not contain credential_process.`,
            { logger: r },
          );
      } else
        throw new Hm.CredentialsProviderError(
          `Profile ${e} could not be found in shared credentials file.`,
          { logger: r },
        );
    },
    WL =
      (e = {}) =>
      async ({ callerClientConfig: t } = {}) => {
        e.logger?.debug("@aws-sdk/credential-provider-process - fromProcess");
        let r = await zm.parseKnownFiles(e);
        return GL(
          zm.getProfileName({ profile: e.profile ?? t?.profile }),
          r,
          e.logger,
        );
      };
  yC.fromProcess = WL;
});
var Bm = P((Ot) => {
  "use strict";
  var KL =
      (Ot && Ot.__createBinding) ||
      (Object.create
        ? function (e, t, r, n) {
            n === void 0 && (n = r);
            var s = Object.getOwnPropertyDescriptor(t, r);
            ((!s ||
              ("get" in s ? !t.__esModule : s.writable || s.configurable)) &&
              (s = {
                enumerable: !0,
                get: function () {
                  return t[r];
                },
              }),
              Object.defineProperty(e, n, s));
          }
        : function (e, t, r, n) {
            (n === void 0 && (n = r), (e[n] = t[r]));
          }),
    JL =
      (Ot && Ot.__setModuleDefault) ||
      (Object.create
        ? function (e, t) {
            Object.defineProperty(e, "default", { enumerable: !0, value: t });
          }
        : function (e, t) {
            e.default = t;
          }),
    YL =
      (Ot && Ot.__importStar) ||
      (function () {
        var e = function (t) {
          return (
            (e =
              Object.getOwnPropertyNames ||
              function (r) {
                var n = [];
                for (var s in r)
                  Object.prototype.hasOwnProperty.call(r, s) &&
                    (n[n.length] = s);
                return n;
              }),
            e(t)
          );
        };
        return function (t) {
          if (t && t.__esModule) return t;
          var r = {};
          if (t != null)
            for (var n = e(t), s = 0; s < n.length; s++)
              n[s] !== "default" && KL(r, t, n[s]);
          return (JL(r, t), r);
        };
      })();
  Object.defineProperty(Ot, "__esModule", { value: !0 });
  Ot.fromWebToken = void 0;
  var XL = (e) => async (t) => {
    e.logger?.debug("@aws-sdk/credential-provider-web-identity - fromWebToken");
    let {
        roleArn: r,
        roleSessionName: n,
        webIdentityToken: s,
        providerId: o,
        policyArns: i,
        policy: a,
        durationSeconds: d,
      } = e,
      { roleAssumerWithWebIdentity: l } = e;
    if (!l) {
      let { getDefaultRoleAssumerWithWebIdentity: p } =
        await Promise.resolve().then(() => YL((Um(), ce($m))));
      l = p(
        {
          ...e.clientConfig,
          credentialProviderLogger: e.logger,
          parentClientConfig: {
            ...t?.callerClientConfig,
            ...e.parentClientConfig,
          },
        },
        e.clientPlugins,
      );
    }
    return l({
      RoleArn: r,
      RoleSessionName: n ?? `aws-sdk-js-session-${Date.now()}`,
      WebIdentityToken: s,
      ProviderId: o,
      PolicyArns: i,
      Policy: a,
      DurationSeconds: d,
    });
  };
  Ot.fromWebToken = XL;
});
var _C = P((Dc) => {
  "use strict";
  Object.defineProperty(Dc, "__esModule", { value: !0 });
  Dc.fromTokenFile = void 0;
  var QL = (gt(), ce(pr)),
    ZL = qe(),
    e$ = qt(),
    t$ = require("fs"),
    r$ = Bm(),
    EC = "AWS_WEB_IDENTITY_TOKEN_FILE",
    n$ = "AWS_ROLE_ARN",
    s$ = "AWS_ROLE_SESSION_NAME",
    o$ =
      (e = {}) =>
      async () => {
        e.logger?.debug(
          "@aws-sdk/credential-provider-web-identity - fromTokenFile",
        );
        let t = e?.webIdentityTokenFile ?? process.env[EC],
          r = e?.roleArn ?? process.env[n$],
          n = e?.roleSessionName ?? process.env[s$];
        if (!t || !r)
          throw new ZL.CredentialsProviderError(
            "Web identity configuration not specified",
            { logger: e.logger },
          );
        let s = await (0, r$.fromWebToken)({
          ...e,
          webIdentityToken:
            e$.externalDataInterceptor?.getTokenRecord?.()[t] ??
            (0, t$.readFileSync)(t, { encoding: "ascii" }),
          roleArn: r,
          roleSessionName: n,
        })();
        return (
          t === process.env[EC] &&
            (0, QL.setCredentialFeature)(
              s,
              "CREDENTIALS_ENV_VARS_STS_WEB_ID_TOKEN",
              "h",
            ),
          s
        );
      };
  Dc.fromTokenFile = o$;
});
var qm = P((Fo) => {
  "use strict";
  var wC = _C(),
    bC = Bm();
  Object.keys(wC).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Fo, e) &&
      Object.defineProperty(Fo, e, {
        enumerable: !0,
        get: function () {
          return wC[e];
        },
      });
  });
  Object.keys(bC).forEach(function (e) {
    e !== "default" &&
      !Object.prototype.hasOwnProperty.call(Fo, e) &&
      Object.defineProperty(Fo, e, {
        enumerable: !0,
        get: function () {
          return bC[e];
        },
      });
  });
});
var AC = P((IC) => {
  "use strict";
  var Gm = qt(),
    Lo = qe(),
    Lr = (gt(), ce(pr)),
    i$ = (e, t, r) => {
      let n = {
        EcsContainer: async (s) => {
          let { fromHttp: o } = await Promise.resolve().then(() => v(Mp())),
            { fromContainerMetadata: i } = await Promise.resolve().then(() =>
              v(Ys()),
            );
          return (
            r?.debug(
              "@aws-sdk/credential-provider-ini - credential_source is EcsContainer",
            ),
            async () => Lo.chain(o(s ?? {}), i(s))().then(Vm)
          );
        },
        Ec2InstanceMetadata: async (s) => {
          r?.debug(
            "@aws-sdk/credential-provider-ini - credential_source is Ec2InstanceMetadata",
          );
          let { fromInstanceMetadata: o } = await Promise.resolve().then(() =>
            v(Ys()),
          );
          return async () => o(s)().then(Vm);
        },
        Environment: async (s) => {
          r?.debug(
            "@aws-sdk/credential-provider-ini - credential_source is Environment",
          );
          let { fromEnv: o } = await Promise.resolve().then(() => v(Cp()));
          return async () => o(s)().then(Vm);
        },
      };
      if (e in n) return n[e];
      throw new Lo.CredentialsProviderError(
        `Unsupported credential source in profile ${t}. Got ${e}, expected EcsContainer or Ec2InstanceMetadata or Environment.`,
        { logger: r },
      );
    },
    Vm = (e) =>
      Lr.setCredentialFeature(e, "CREDENTIALS_PROFILE_NAMED_PROVIDER", "p"),
    a$ = (e, { profile: t = "default", logger: r } = {}) =>
      !!e &&
      typeof e == "object" &&
      typeof e.role_arn == "string" &&
      ["undefined", "string"].indexOf(typeof e.role_session_name) > -1 &&
      ["undefined", "string"].indexOf(typeof e.external_id) > -1 &&
      ["undefined", "string"].indexOf(typeof e.mfa_serial) > -1 &&
      (c$(e, { profile: t, logger: r }) || d$(e, { profile: t, logger: r })),
    c$ = (e, { profile: t, logger: r }) => {
      let n =
        typeof e.source_profile == "string" && typeof e.credential_source > "u";
      return (
        n &&
          r?.debug?.(
            `    ${t} isAssumeRoleWithSourceProfile source_profile=${e.source_profile}`,
          ),
        n
      );
    },
    d$ = (e, { profile: t, logger: r }) => {
      let n =
        typeof e.credential_source == "string" && typeof e.source_profile > "u";
      return (
        n &&
          r?.debug?.(
            `    ${t} isCredentialSourceProfile credential_source=${e.credential_source}`,
          ),
        n
      );
    },
    l$ = async (e, t, r, n = {}) => {
      r.logger?.debug(
        "@aws-sdk/credential-provider-ini - resolveAssumeRoleCredentials (STS)",
      );
      let s = t[e],
        { source_profile: o, region: i } = s;
      if (!r.roleAssumer) {
        let { getDefaultRoleAssumer: d } = await Promise.resolve().then(
          () => (Um(), $m),
        );
        r.roleAssumer = d(
          {
            ...r.clientConfig,
            credentialProviderLogger: r.logger,
            parentClientConfig: {
              ...r?.parentClientConfig,
              region: i ?? r?.parentClientConfig?.region,
            },
          },
          r.clientPlugins,
        );
      }
      if (o && o in n)
        throw new Lo.CredentialsProviderError(
          `Detected a cycle attempting to resolve credentials for profile ${Gm.getProfileName(r)}. Profiles visited: ` +
            Object.keys(n).join(", "),
          { logger: r.logger },
        );
      r.logger?.debug(
        `@aws-sdk/credential-provider-ini - finding credential resolver using ${o ? `source_profile=[${o}]` : `profile=[${e}]`}`,
      );
      let a = o
        ? CC(o, t, r, { ...n, [o]: !0 }, xC(t[o] ?? {}))
        : (await i$(s.credential_source, e, r.logger)(r))();
      if (xC(s))
        return a.then((d) =>
          Lr.setCredentialFeature(d, "CREDENTIALS_PROFILE_SOURCE_PROFILE", "o"),
        );
      {
        let d = {
            RoleArn: s.role_arn,
            RoleSessionName: s.role_session_name || `aws-sdk-js-${Date.now()}`,
            ExternalId: s.external_id,
            DurationSeconds: parseInt(s.duration_seconds || "3600", 10),
          },
          { mfa_serial: l } = s;
        if (l) {
          if (!r.mfaCodeProvider)
            throw new Lo.CredentialsProviderError(
              `Profile ${e} requires multi-factor authentication, but no MFA code callback was provided.`,
              { logger: r.logger, tryNextLink: !1 },
            );
          ((d.SerialNumber = l), (d.TokenCode = await r.mfaCodeProvider(l)));
        }
        let p = await a;
        return r
          .roleAssumer(p, d)
          .then((m) =>
            Lr.setCredentialFeature(
              m,
              "CREDENTIALS_PROFILE_SOURCE_PROFILE",
              "o",
            ),
          );
      }
    },
    xC = (e) => !e.role_arn && !!e.credential_source,
    u$ = (e) =>
      !!e && typeof e == "object" && typeof e.credential_process == "string",
    f$ = async (e, t) =>
      Promise.resolve()
        .then(() => v(jm()))
        .then(({ fromProcess: r }) =>
          r({ ...e, profile: t })().then((n) =>
            Lr.setCredentialFeature(n, "CREDENTIALS_PROFILE_PROCESS", "v"),
          ),
        ),
    p$ = async (e, t, r = {}) => {
      let { fromSSO: n } = await Promise.resolve().then(() => v(om()));
      return n({
        profile: e,
        logger: r.logger,
        parentClientConfig: r.parentClientConfig,
        clientConfig: r.clientConfig,
      })().then((s) =>
        t.sso_session
          ? Lr.setCredentialFeature(s, "CREDENTIALS_PROFILE_SSO", "r")
          : Lr.setCredentialFeature(s, "CREDENTIALS_PROFILE_SSO_LEGACY", "t"),
      );
    },
    m$ = (e) =>
      e &&
      (typeof e.sso_start_url == "string" ||
        typeof e.sso_account_id == "string" ||
        typeof e.sso_session == "string" ||
        typeof e.sso_region == "string" ||
        typeof e.sso_role_name == "string"),
    vC = (e) =>
      !!e &&
      typeof e == "object" &&
      typeof e.aws_access_key_id == "string" &&
      typeof e.aws_secret_access_key == "string" &&
      ["undefined", "string"].indexOf(typeof e.aws_session_token) > -1 &&
      ["undefined", "string"].indexOf(typeof e.aws_account_id) > -1,
    TC = async (e, t) => {
      t?.logger?.debug(
        "@aws-sdk/credential-provider-ini - resolveStaticCredentials",
      );
      let r = {
        accessKeyId: e.aws_access_key_id,
        secretAccessKey: e.aws_secret_access_key,
        sessionToken: e.aws_session_token,
        ...(e.aws_credential_scope && {
          credentialScope: e.aws_credential_scope,
        }),
        ...(e.aws_account_id && { accountId: e.aws_account_id }),
      };
      return Lr.setCredentialFeature(r, "CREDENTIALS_PROFILE", "n");
    },
    h$ = (e) =>
      !!e &&
      typeof e == "object" &&
      typeof e.web_identity_token_file == "string" &&
      typeof e.role_arn == "string" &&
      ["undefined", "string"].indexOf(typeof e.role_session_name) > -1,
    g$ = async (e, t) =>
      Promise.resolve()
        .then(() => v(qm()))
        .then(({ fromTokenFile: r }) =>
          r({
            webIdentityTokenFile: e.web_identity_token_file,
            roleArn: e.role_arn,
            roleSessionName: e.role_session_name,
            roleAssumerWithWebIdentity: t.roleAssumerWithWebIdentity,
            logger: t.logger,
            parentClientConfig: t.parentClientConfig,
          })().then((n) =>
            Lr.setCredentialFeature(
              n,
              "CREDENTIALS_PROFILE_STS_WEB_ID_TOKEN",
              "q",
            ),
          ),
        ),
    CC = async (e, t, r, n = {}, s = !1) => {
      let o = t[e];
      if (Object.keys(n).length > 0 && vC(o)) return TC(o, r);
      if (s || a$(o, { profile: e, logger: r.logger })) return l$(e, t, r, n);
      if (vC(o)) return TC(o, r);
      if (h$(o)) return g$(o, r);
      if (u$(o)) return f$(r, e);
      if (m$(o)) return await p$(e, o, r);
      throw new Lo.CredentialsProviderError(
        `Could not resolve credentials using profile: [${e}] in configuration/credentials file(s).`,
        { logger: r.logger },
      );
    },
    S$ =
      (e = {}) =>
      async ({ callerClientConfig: t } = {}) => {
        let r = { ...e, parentClientConfig: { ...t, ...e.parentClientConfig } };
        r.logger?.debug("@aws-sdk/credential-provider-ini - fromIni");
        let n = await Gm.parseKnownFiles(r);
        return CC(
          Gm.getProfileName({ profile: e.profile ?? t?.profile }),
          n,
          r,
        );
      };
  IC.fromIni = S$;
});
var DC = P((Mc) => {
  "use strict";
  var Wm = Cp(),
    fn = qe(),
    y$ = qt(),
    RC = "AWS_EC2_METADATA_DISABLED",
    E$ = async (e) => {
      let {
        ENV_CMDS_FULL_URI: t,
        ENV_CMDS_RELATIVE_URI: r,
        fromContainerMetadata: n,
        fromInstanceMetadata: s,
      } = await Promise.resolve().then(() => v(Ys()));
      if (process.env[r] || process.env[t]) {
        e.logger?.debug(
          "@aws-sdk/credential-provider-node - remoteProvider::fromHttp/fromContainerMetadata",
        );
        let { fromHttp: o } = await Promise.resolve().then(() => v(Mp()));
        return fn.chain(o(e), n(e));
      }
      return process.env[RC] && process.env[RC] !== "false"
        ? async () => {
            throw new fn.CredentialsProviderError(
              "EC2 Instance Metadata Service access disabled",
              { logger: e.logger },
            );
          }
        : (e.logger?.debug(
            "@aws-sdk/credential-provider-node - remoteProvider::fromInstanceMetadata",
          ),
          s(e));
    },
    NC = !1,
    _$ = (e = {}) =>
      fn.memoize(
        fn.chain(
          async () => {
            if (e.profile ?? process.env[y$.ENV_PROFILE])
              throw (
                process.env[Wm.ENV_KEY] &&
                  process.env[Wm.ENV_SECRET] &&
                  (NC ||
                    ((e.logger?.warn &&
                      e.logger?.constructor?.name !== "NoOpLogger"
                      ? e.logger.warn.bind(e.logger)
                      : console.warn)(`@aws-sdk/credential-provider-node - defaultProvider::fromEnv WARNING:
    Multiple credential sources detected: 
    Both AWS_PROFILE and the pair AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY static credentials are set.
    This SDK will proceed with the AWS_PROFILE value.
    
    However, a future version may change this behavior to prefer the ENV static credentials.
    Please ensure that your environment only sets either the AWS_PROFILE or the
    AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY pair.
`),
                    (NC = !0))),
                new fn.CredentialsProviderError(
                  "AWS_PROFILE is set, skipping fromEnv provider.",
                  { logger: e.logger, tryNextLink: !0 },
                )
              );
            return (
              e.logger?.debug(
                "@aws-sdk/credential-provider-node - defaultProvider::fromEnv",
              ),
              Wm.fromEnv(e)()
            );
          },
          async () => {
            e.logger?.debug(
              "@aws-sdk/credential-provider-node - defaultProvider::fromSSO",
            );
            let {
              ssoStartUrl: t,
              ssoAccountId: r,
              ssoRegion: n,
              ssoRoleName: s,
              ssoSession: o,
            } = e;
            if (!t && !r && !n && !s && !o)
              throw new fn.CredentialsProviderError(
                "Skipping SSO provider in default chain (inputs do not include SSO fields).",
                { logger: e.logger },
              );
            let { fromSSO: i } = await Promise.resolve().then(() => v(om()));
            return i(e)();
          },
          async () => {
            e.logger?.debug(
              "@aws-sdk/credential-provider-node - defaultProvider::fromIni",
            );
            let { fromIni: t } = await Promise.resolve().then(() => v(AC()));
            return t(e)();
          },
          async () => {
            e.logger?.debug(
              "@aws-sdk/credential-provider-node - defaultProvider::fromProcess",
            );
            let { fromProcess: t } = await Promise.resolve().then(() =>
              v(jm()),
            );
            return t(e)();
          },
          async () => {
            e.logger?.debug(
              "@aws-sdk/credential-provider-node - defaultProvider::fromTokenFile",
            );
            let { fromTokenFile: t } = await Promise.resolve().then(() =>
              v(qm()),
            );
            return t(e)();
          },
          async () => (
            e.logger?.debug(
              "@aws-sdk/credential-provider-node - defaultProvider::remoteProvider",
            ),
            (await E$(e))()
          ),
          async () => {
            throw new fn.CredentialsProviderError(
              "Could not load credentials from any providers",
              { tryNextLink: !1, logger: e.logger },
            );
          },
        ),
        OC,
        PC,
      ),
    PC = (e) => e?.expiration !== void 0,
    OC = (e) =>
      e?.expiration !== void 0 && e.expiration.getTime() - Date.now() < 3e5;
  Mc.credentialsTreatedAsExpired = OC;
  Mc.credentialsWillNeedRefresh = PC;
  Mc.defaultProvider = _$;
});
var KC = P((kc) => {
  "use strict";
  Object.defineProperty(kc, "__esModule", { value: !0 });
  kc.ruleSet = void 0;
  var qC = "required",
    yt = "fn",
    Et = "argv",
    as = "ref",
    MC = !0,
    kC = "isSet",
    $o = "booleanEquals",
    os = "error",
    is = "endpoint",
    Qt = "tree",
    Km = "PartitionResult",
    FC = { [qC]: !1, type: "String" },
    LC = { [qC]: !0, default: !1, type: "Boolean" },
    $C = { [as]: "Endpoint" },
    VC = { [yt]: $o, [Et]: [{ [as]: "UseFIPS" }, !0] },
    GC = { [yt]: $o, [Et]: [{ [as]: "UseDualStack" }, !0] },
    mt = {},
    WC = { [as]: "Region" },
    UC = { [yt]: "getAttr", [Et]: [{ [as]: Km }, "supportsFIPS"] },
    HC = {
      [yt]: $o,
      [Et]: [
        !0,
        { [yt]: "getAttr", [Et]: [{ [as]: Km }, "supportsDualStack"] },
      ],
    },
    zC = [VC],
    jC = [GC],
    BC = [WC],
    w$ = {
      version: "1.0",
      parameters: { Region: FC, UseDualStack: LC, UseFIPS: LC, Endpoint: FC },
      rules: [
        {
          conditions: [{ [yt]: kC, [Et]: [$C] }],
          rules: [
            {
              conditions: zC,
              error:
                "Invalid Configuration: FIPS and custom endpoint are not supported",
              type: os,
            },
            {
              conditions: jC,
              error:
                "Invalid Configuration: Dualstack and custom endpoint are not supported",
              type: os,
            },
            { endpoint: { url: $C, properties: mt, headers: mt }, type: is },
          ],
          type: Qt,
        },
        {
          conditions: [{ [yt]: kC, [Et]: BC }],
          rules: [
            {
              conditions: [{ [yt]: "aws.partition", [Et]: BC, assign: Km }],
              rules: [
                {
                  conditions: [VC, GC],
                  rules: [
                    {
                      conditions: [{ [yt]: $o, [Et]: [MC, UC] }, HC],
                      rules: [
                        {
                          endpoint: {
                            url: "https://states-fips.{Region}.{PartitionResult#dualStackDnsSuffix}",
                            properties: mt,
                            headers: mt,
                          },
                          type: is,
                        },
                      ],
                      type: Qt,
                    },
                    {
                      error:
                        "FIPS and DualStack are enabled, but this partition does not support one or both",
                      type: os,
                    },
                  ],
                  type: Qt,
                },
                {
                  conditions: zC,
                  rules: [
                    {
                      conditions: [{ [yt]: $o, [Et]: [UC, MC] }],
                      rules: [
                        {
                          conditions: [
                            {
                              [yt]: "stringEquals",
                              [Et]: [WC, "us-gov-west-1"],
                            },
                          ],
                          endpoint: {
                            url: "https://states.us-gov-west-1.amazonaws.com",
                            properties: mt,
                            headers: mt,
                          },
                          type: is,
                        },
                        {
                          endpoint: {
                            url: "https://states-fips.{Region}.{PartitionResult#dnsSuffix}",
                            properties: mt,
                            headers: mt,
                          },
                          type: is,
                        },
                      ],
                      type: Qt,
                    },
                    {
                      error:
                        "FIPS is enabled but this partition does not support FIPS",
                      type: os,
                    },
                  ],
                  type: Qt,
                },
                {
                  conditions: jC,
                  rules: [
                    {
                      conditions: [HC],
                      rules: [
                        {
                          endpoint: {
                            url: "https://states.{Region}.{PartitionResult#dualStackDnsSuffix}",
                            properties: mt,
                            headers: mt,
                          },
                          type: is,
                        },
                      ],
                      type: Qt,
                    },
                    {
                      error:
                        "DualStack is enabled but this partition does not support DualStack",
                      type: os,
                    },
                  ],
                  type: Qt,
                },
                {
                  endpoint: {
                    url: "https://states.{Region}.{PartitionResult#dnsSuffix}",
                    properties: mt,
                    headers: mt,
                  },
                  type: is,
                },
              ],
              type: Qt,
            },
          ],
          type: Qt,
        },
        { error: "Invalid Configuration: Missing Region", type: os },
      ],
    };
  kc.ruleSet = w$;
});
var JC = P((Fc) => {
  "use strict";
  Object.defineProperty(Fc, "__esModule", { value: !0 });
  Fc.defaultEndpointResolver = void 0;
  var b$ = Cn(),
    Jm = Tn(),
    x$ = KC(),
    v$ = new Jm.EndpointCache({
      size: 50,
      params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
    }),
    T$ = (e, t = {}) =>
      v$.get(e, () =>
        (0, Jm.resolveEndpoint)(x$.ruleSet, {
          endpointParams: e,
          logger: t.logger,
        }),
      );
  Fc.defaultEndpointResolver = T$;
  Jm.customEndpointFunctions.aws = b$.awsEndpointFunctions;
});
var QC = P((Lc) => {
  "use strict";
  Object.defineProperty(Lc, "__esModule", { value: !0 });
  Lc.getRuntimeConfig = void 0;
  var C$ = (Ne(), ce(Tt)),
    I$ = Y(),
    A$ = lr(),
    YC = De(),
    XC = Oe(),
    R$ = Tp(),
    N$ = JC(),
    P$ = (e) => ({
      apiVersion: "2016-11-23",
      base64Decoder: e?.base64Decoder ?? YC.fromBase64,
      base64Encoder: e?.base64Encoder ?? YC.toBase64,
      disableHostPrefix: e?.disableHostPrefix ?? !1,
      endpointProvider: e?.endpointProvider ?? N$.defaultEndpointResolver,
      extensions: e?.extensions ?? [],
      httpAuthSchemeProvider:
        e?.httpAuthSchemeProvider ?? R$.defaultSFNHttpAuthSchemeProvider,
      httpAuthSchemes: e?.httpAuthSchemes ?? [
        {
          schemeId: "aws.auth#sigv4",
          identityProvider: (t) => t.getIdentityProvider("aws.auth#sigv4"),
          signer: new C$.AwsSdkSigV4Signer(),
        },
      ],
      logger: e?.logger ?? new I$.NoOpLogger(),
      serviceId: e?.serviceId ?? "SFN",
      urlParser: e?.urlParser ?? A$.parseUrl,
      utf8Decoder: e?.utf8Decoder ?? XC.fromUtf8,
      utf8Encoder: e?.utf8Encoder ?? XC.toUtf8,
    });
  Lc.getRuntimeConfig = P$;
});
var nI = P((Uc) => {
  "use strict";
  Object.defineProperty(Uc, "__esModule", { value: !0 });
  Uc.getRuntimeConfig = void 0;
  var O$ = (vs(), ce(xs)),
    D$ = O$.__importDefault(Xw()),
    ZC = (Ne(), ce(Tt)),
    M$ = DC(),
    eI = Qs(),
    $c = It(),
    k$ = Zs(),
    tI = Gt(),
    pn = xr(),
    rI = zr(),
    F$ = eo(),
    L$ = Un(),
    $$ = QC(),
    U$ = Y(),
    H$ = ro(),
    z$ = Y(),
    j$ = (e) => {
      (0, z$.emitWarningIfUnsupportedVersion)(process.version);
      let t = (0, H$.resolveDefaultsModeConfig)(e),
        r = () => t().then(U$.loadConfigsForDefaultMode),
        n = (0, $$.getRuntimeConfig)(e);
      (0, ZC.emitWarningIfUnsupportedVersion)(process.version);
      let s = { profile: e?.profile, logger: n.logger };
      return {
        ...n,
        ...e,
        runtime: "node",
        defaultsMode: t,
        authSchemePreference:
          e?.authSchemePreference ??
          (0, pn.loadConfig)(ZC.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, s),
        bodyLengthChecker: e?.bodyLengthChecker ?? F$.calculateBodyLength,
        credentialDefaultProvider:
          e?.credentialDefaultProvider ?? M$.defaultProvider,
        defaultUserAgentProvider:
          e?.defaultUserAgentProvider ??
          (0, eI.createDefaultUserAgentProvider)({
            serviceId: n.serviceId,
            clientVersion: D$.default.version,
          }),
        maxAttempts:
          e?.maxAttempts ??
          (0, pn.loadConfig)(tI.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, e),
        region:
          e?.region ??
          (0, pn.loadConfig)($c.NODE_REGION_CONFIG_OPTIONS, {
            ...$c.NODE_REGION_CONFIG_FILE_OPTIONS,
            ...s,
          }),
        requestHandler: rI.NodeHttpHandler.create(e?.requestHandler ?? r),
        retryMode:
          e?.retryMode ??
          (0, pn.loadConfig)(
            {
              ...tI.NODE_RETRY_MODE_CONFIG_OPTIONS,
              default: async () =>
                (await r()).retryMode || L$.DEFAULT_RETRY_MODE,
            },
            e,
          ),
        sha256: e?.sha256 ?? k$.Hash.bind(null, "sha256"),
        streamCollector: e?.streamCollector ?? rI.streamCollector,
        useDualstackEndpoint:
          e?.useDualstackEndpoint ??
          (0, pn.loadConfig)($c.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, s),
        useFipsEndpoint:
          e?.useFipsEndpoint ??
          (0, pn.loadConfig)($c.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, s),
        userAgentAppId:
          e?.userAgentAppId ??
          (0, pn.loadConfig)(eI.NODE_APP_ID_CONFIG_OPTIONS, s),
      };
    };
  Uc.getRuntimeConfig = j$;
});
var oA = P((x) => {
  "use strict";
  var sI = cs(),
    B$ = ds(),
    q$ = ls(),
    oI = Ln(),
    V$ = It(),
    $r = (Je(), ce(vn)),
    G$ = Bs(),
    X = vr(),
    iI = Gt(),
    c = Y(),
    aI = Tp(),
    W$ = nI(),
    cI = no(),
    Uo = me(),
    Z = sr(),
    K = (Ne(), ce(Tt)),
    K$ = Ri(),
    J$ = (e) =>
      Object.assign(e, {
        useDualstackEndpoint: e.useDualstackEndpoint ?? !1,
        useFipsEndpoint: e.useFipsEndpoint ?? !1,
        defaultSigningName: "states",
      }),
    ee = {
      UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
      Endpoint: { type: "builtInParams", name: "endpoint" },
      Region: { type: "builtInParams", name: "region" },
      UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
    },
    Y$ = (e) => {
      let t = e.httpAuthSchemes,
        r = e.httpAuthSchemeProvider,
        n = e.credentials;
      return {
        setHttpAuthScheme(s) {
          let o = t.findIndex((i) => i.schemeId === s.schemeId);
          o === -1 ? t.push(s) : t.splice(o, 1, s);
        },
        httpAuthSchemes() {
          return t;
        },
        setHttpAuthSchemeProvider(s) {
          r = s;
        },
        httpAuthSchemeProvider() {
          return r;
        },
        setCredentials(s) {
          n = s;
        },
        credentials() {
          return n;
        },
      };
    },
    X$ = (e) => ({
      httpAuthSchemes: e.httpAuthSchemes(),
      httpAuthSchemeProvider: e.httpAuthSchemeProvider(),
      credentials: e.credentials(),
    }),
    Q$ = (e, t) => {
      let r = Object.assign(
        cI.getAwsRegionExtensionConfiguration(e),
        c.getDefaultExtensionConfiguration(e),
        Uo.getHttpHandlerExtensionConfiguration(e),
        Y$(e),
      );
      return (
        t.forEach((n) => n.configure(r)),
        Object.assign(
          e,
          cI.resolveAwsRegionExtensionConfiguration(r),
          c.resolveDefaultRuntimeConfig(r),
          Uo.resolveHttpHandlerRuntimeConfig(r),
          X$(r),
        )
      );
    },
    Zt = class extends c.Client {
      config;
      constructor(...[t]) {
        let r = W$.getRuntimeConfig(t || {});
        (super(r), (this.initConfig = r));
        let n = J$(r),
          s = oI.resolveUserAgentConfig(n),
          o = iI.resolveRetryConfig(s),
          i = V$.resolveRegionConfig(o),
          a = sI.resolveHostHeaderConfig(i),
          d = X.resolveEndpointConfig(a),
          l = aI.resolveHttpAuthSchemeConfig(d),
          p = Q$(l, t?.extensions || []);
        ((this.config = p),
          this.middlewareStack.use(oI.getUserAgentPlugin(this.config)),
          this.middlewareStack.use(iI.getRetryPlugin(this.config)),
          this.middlewareStack.use(G$.getContentLengthPlugin(this.config)),
          this.middlewareStack.use(sI.getHostHeaderPlugin(this.config)),
          this.middlewareStack.use(B$.getLoggerPlugin(this.config)),
          this.middlewareStack.use(q$.getRecursionDetectionPlugin(this.config)),
          this.middlewareStack.use(
            $r.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
              httpAuthSchemeParametersProvider:
                aI.defaultSFNHttpAuthSchemeParametersProvider,
              identityProviderConfigProvider: async (m) =>
                new $r.DefaultIdentityProviderConfig({
                  "aws.auth#sigv4": m.credentials,
                }),
            }),
          ),
          this.middlewareStack.use($r.getHttpSigningPlugin(this.config)));
      }
      destroy() {
        super.destroy();
      }
    },
    Q = class e extends c.ServiceException {
      constructor(t) {
        (super(t), Object.setPrototypeOf(this, e.prototype));
      }
    },
    Hc = class e extends Q {
      name = "ActivityAlreadyExists";
      $fault = "client";
      constructor(t) {
        (super({ name: "ActivityAlreadyExists", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    zc = class e extends Q {
      name = "ActivityDoesNotExist";
      $fault = "client";
      constructor(t) {
        (super({ name: "ActivityDoesNotExist", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    jc = class e extends Q {
      name = "ActivityLimitExceeded";
      $fault = "client";
      constructor(t) {
        (super({ name: "ActivityLimitExceeded", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Bc = class e extends Q {
      name = "ActivityWorkerLimitExceeded";
      $fault = "client";
      constructor(t) {
        (super({ name: "ActivityWorkerLimitExceeded", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Z$ = {
      AWS_OWNED_KEY: "AWS_OWNED_KEY",
      CUSTOMER_MANAGED_KMS_KEY: "CUSTOMER_MANAGED_KMS_KEY",
    },
    qc = class e extends Q {
      name = "InvalidEncryptionConfiguration";
      $fault = "client";
      constructor(t) {
        (super({
          name: "InvalidEncryptionConfiguration",
          $fault: "client",
          ...t,
        }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Vc = class e extends Q {
      name = "InvalidName";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidName", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Gc = class e extends Q {
      name = "KmsAccessDeniedException";
      $fault = "client";
      constructor(t) {
        (super({ name: "KmsAccessDeniedException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Wc = class e extends Q {
      name = "KmsThrottlingException";
      $fault = "client";
      constructor(t) {
        (super({ name: "KmsThrottlingException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Kc = class e extends Q {
      name = "TooManyTags";
      $fault = "client";
      resourceName;
      constructor(t) {
        (super({ name: "TooManyTags", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype),
          (this.resourceName = t.resourceName));
      }
    },
    Jc = class e extends Q {
      name = "ConflictException";
      $fault = "client";
      constructor(t) {
        (super({ name: "ConflictException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    eU = { ALL: "ALL", ERROR: "ERROR", FATAL: "FATAL", OFF: "OFF" },
    tU = { EXPRESS: "EXPRESS", STANDARD: "STANDARD" },
    Yc = class e extends Q {
      name = "InvalidArn";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidArn", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Xc = class e extends Q {
      name = "InvalidDefinition";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidDefinition", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Qc = class e extends Q {
      name = "InvalidLoggingConfiguration";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidLoggingConfiguration", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Zc = class e extends Q {
      name = "InvalidTracingConfiguration";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidTracingConfiguration", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    ed = class e extends Q {
      name = "StateMachineAlreadyExists";
      $fault = "client";
      constructor(t) {
        (super({ name: "StateMachineAlreadyExists", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    td = class e extends Q {
      name = "StateMachineDeleting";
      $fault = "client";
      constructor(t) {
        (super({ name: "StateMachineDeleting", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    rd = class e extends Q {
      name = "StateMachineLimitExceeded";
      $fault = "client";
      constructor(t) {
        (super({ name: "StateMachineLimitExceeded", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    nd = class e extends Q {
      name = "StateMachineTypeNotSupported";
      $fault = "client";
      constructor(t) {
        (super({
          name: "StateMachineTypeNotSupported",
          $fault: "client",
          ...t,
        }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    rU = {
      API_DOES_NOT_SUPPORT_LABELED_ARNS: "API_DOES_NOT_SUPPORT_LABELED_ARNS",
      CANNOT_UPDATE_COMPLETED_MAP_RUN: "CANNOT_UPDATE_COMPLETED_MAP_RUN",
      INVALID_ROUTING_CONFIGURATION: "INVALID_ROUTING_CONFIGURATION",
      MISSING_REQUIRED_PARAMETER: "MISSING_REQUIRED_PARAMETER",
    },
    sd = class e extends Q {
      name = "ValidationException";
      $fault = "client";
      reason;
      constructor(t) {
        (super({ name: "ValidationException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype),
          (this.reason = t.reason));
      }
    },
    od = class e extends Q {
      name = "ResourceNotFound";
      $fault = "client";
      resourceName;
      constructor(t) {
        (super({ name: "ResourceNotFound", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype),
          (this.resourceName = t.resourceName));
      }
    },
    id = class e extends Q {
      name = "ServiceQuotaExceededException";
      $fault = "client";
      constructor(t) {
        (super({
          name: "ServiceQuotaExceededException",
          $fault: "client",
          ...t,
        }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    nU = { ALL_DATA: "ALL_DATA", METADATA_ONLY: "METADATA_ONLY" },
    sU = {
      NOT_REDRIVABLE: "NOT_REDRIVABLE",
      REDRIVABLE: "REDRIVABLE",
      REDRIVABLE_BY_MAP_RUN: "REDRIVABLE_BY_MAP_RUN",
    },
    oU = {
      ABORTED: "ABORTED",
      FAILED: "FAILED",
      PENDING_REDRIVE: "PENDING_REDRIVE",
      RUNNING: "RUNNING",
      SUCCEEDED: "SUCCEEDED",
      TIMED_OUT: "TIMED_OUT",
    },
    ad = class e extends Q {
      name = "ExecutionDoesNotExist";
      $fault = "client";
      constructor(t) {
        (super({ name: "ExecutionDoesNotExist", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    iU = {
      CREATING: "CREATING",
      DISABLED: "DISABLED",
      PENDING_DELETION: "PENDING_DELETION",
      PENDING_IMPORT: "PENDING_IMPORT",
      UNAVAILABLE: "UNAVAILABLE",
    },
    cd = class e extends Q {
      name = "KmsInvalidStateException";
      $fault = "client";
      kmsKeyState;
      constructor(t) {
        (super({ name: "KmsInvalidStateException", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype),
          (this.kmsKeyState = t.kmsKeyState));
      }
    },
    aU = {
      ABORTED: "ABORTED",
      FAILED: "FAILED",
      RUNNING: "RUNNING",
      SUCCEEDED: "SUCCEEDED",
    },
    cU = { ACTIVE: "ACTIVE", DELETING: "DELETING" },
    dd = class e extends Q {
      name = "StateMachineDoesNotExist";
      $fault = "client";
      constructor(t) {
        (super({ name: "StateMachineDoesNotExist", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    dU = {
      ActivityFailed: "ActivityFailed",
      ActivityScheduleFailed: "ActivityScheduleFailed",
      ActivityScheduled: "ActivityScheduled",
      ActivityStarted: "ActivityStarted",
      ActivitySucceeded: "ActivitySucceeded",
      ActivityTimedOut: "ActivityTimedOut",
      ChoiceStateEntered: "ChoiceStateEntered",
      ChoiceStateExited: "ChoiceStateExited",
      EvaluationFailed: "EvaluationFailed",
      ExecutionAborted: "ExecutionAborted",
      ExecutionFailed: "ExecutionFailed",
      ExecutionRedriven: "ExecutionRedriven",
      ExecutionStarted: "ExecutionStarted",
      ExecutionSucceeded: "ExecutionSucceeded",
      ExecutionTimedOut: "ExecutionTimedOut",
      FailStateEntered: "FailStateEntered",
      LambdaFunctionFailed: "LambdaFunctionFailed",
      LambdaFunctionScheduleFailed: "LambdaFunctionScheduleFailed",
      LambdaFunctionScheduled: "LambdaFunctionScheduled",
      LambdaFunctionStartFailed: "LambdaFunctionStartFailed",
      LambdaFunctionStarted: "LambdaFunctionStarted",
      LambdaFunctionSucceeded: "LambdaFunctionSucceeded",
      LambdaFunctionTimedOut: "LambdaFunctionTimedOut",
      MapIterationAborted: "MapIterationAborted",
      MapIterationFailed: "MapIterationFailed",
      MapIterationStarted: "MapIterationStarted",
      MapIterationSucceeded: "MapIterationSucceeded",
      MapRunAborted: "MapRunAborted",
      MapRunFailed: "MapRunFailed",
      MapRunRedriven: "MapRunRedriven",
      MapRunStarted: "MapRunStarted",
      MapRunSucceeded: "MapRunSucceeded",
      MapStateAborted: "MapStateAborted",
      MapStateEntered: "MapStateEntered",
      MapStateExited: "MapStateExited",
      MapStateFailed: "MapStateFailed",
      MapStateStarted: "MapStateStarted",
      MapStateSucceeded: "MapStateSucceeded",
      ParallelStateAborted: "ParallelStateAborted",
      ParallelStateEntered: "ParallelStateEntered",
      ParallelStateExited: "ParallelStateExited",
      ParallelStateFailed: "ParallelStateFailed",
      ParallelStateStarted: "ParallelStateStarted",
      ParallelStateSucceeded: "ParallelStateSucceeded",
      PassStateEntered: "PassStateEntered",
      PassStateExited: "PassStateExited",
      SucceedStateEntered: "SucceedStateEntered",
      SucceedStateExited: "SucceedStateExited",
      TaskFailed: "TaskFailed",
      TaskScheduled: "TaskScheduled",
      TaskStartFailed: "TaskStartFailed",
      TaskStarted: "TaskStarted",
      TaskStateAborted: "TaskStateAborted",
      TaskStateEntered: "TaskStateEntered",
      TaskStateExited: "TaskStateExited",
      TaskSubmitFailed: "TaskSubmitFailed",
      TaskSubmitted: "TaskSubmitted",
      TaskSucceeded: "TaskSucceeded",
      TaskTimedOut: "TaskTimedOut",
      WaitStateAborted: "WaitStateAborted",
      WaitStateEntered: "WaitStateEntered",
      WaitStateExited: "WaitStateExited",
    },
    ld = class e extends Q {
      name = "InvalidToken";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidToken", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    lU = { NOT_REDRIVEN: "NOT_REDRIVEN", REDRIVEN: "REDRIVEN" },
    ud = class e extends Q {
      name = "ExecutionLimitExceeded";
      $fault = "client";
      constructor(t) {
        (super({ name: "ExecutionLimitExceeded", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    fd = class e extends Q {
      name = "ExecutionNotRedrivable";
      $fault = "client";
      constructor(t) {
        (super({ name: "ExecutionNotRedrivable", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    pd = class e extends Q {
      name = "TaskDoesNotExist";
      $fault = "client";
      constructor(t) {
        (super({ name: "TaskDoesNotExist", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    md = class e extends Q {
      name = "TaskTimedOut";
      $fault = "client";
      constructor(t) {
        (super({ name: "TaskTimedOut", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    hd = class e extends Q {
      name = "InvalidOutput";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidOutput", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    gd = class e extends Q {
      name = "ExecutionAlreadyExists";
      $fault = "client";
      constructor(t) {
        (super({ name: "ExecutionAlreadyExists", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    Sd = class e extends Q {
      name = "InvalidExecutionInput";
      $fault = "client";
      constructor(t) {
        (super({ name: "InvalidExecutionInput", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    uU = { FAILED: "FAILED", SUCCEEDED: "SUCCEEDED", TIMED_OUT: "TIMED_OUT" },
    fU = { DEBUG: "DEBUG", INFO: "INFO", TRACE: "TRACE" },
    pU = {
      CAUGHT_ERROR: "CAUGHT_ERROR",
      FAILED: "FAILED",
      RETRIABLE: "RETRIABLE",
      SUCCEEDED: "SUCCEEDED",
    },
    yd = class e extends Q {
      name = "MissingRequiredParameter";
      $fault = "client";
      constructor(t) {
        (super({ name: "MissingRequiredParameter", $fault: "client", ...t }),
          Object.setPrototypeOf(this, e.prototype));
      }
    },
    mU = { ERROR: "ERROR", WARNING: "WARNING" },
    hU = { FAIL: "FAIL", OK: "OK" },
    dI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    lI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    uI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    fI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    pI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    mI = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
      ...(e.versionDescription && { versionDescription: c.SENSITIVE_STRING }),
    }),
    hI = (e) => ({
      ...e,
      ...(e.description && { description: c.SENSITIVE_STRING }),
    }),
    gI = (e) => ({
      ...e,
      ...(e.input && { input: c.SENSITIVE_STRING }),
      ...(e.output && { output: c.SENSITIVE_STRING }),
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
      ...(e.redriveStatusReason && { redriveStatusReason: c.SENSITIVE_STRING }),
    }),
    SI = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
      ...(e.description && { description: c.SENSITIVE_STRING }),
      ...(e.variableReferences && { variableReferences: c.SENSITIVE_STRING }),
    }),
    yI = (e) => ({
      ...e,
      ...(e.description && { description: c.SENSITIVE_STRING }),
    }),
    EI = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
      ...(e.variableReferences && { variableReferences: c.SENSITIVE_STRING }),
    }),
    _I = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    wI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
      ...(e.location && { location: c.SENSITIVE_STRING }),
    }),
    bI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    xI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    vI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    TI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    CI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    II = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    AI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    RI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    NI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    PI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    OI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    DI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    MI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    kI = (e) => ({
      ...e,
      ...(e.output && { output: c.SENSITIVE_STRING }),
      ...(e.assignedVariables && { assignedVariables: c.SENSITIVE_STRING }),
    }),
    FI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    LI = (e) => ({
      ...e,
      ...(e.parameters && { parameters: c.SENSITIVE_STRING }),
    }),
    $I = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    UI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    HI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    zI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    jI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    BI = (e) => ({
      ...e,
      ...(e.activityFailedEventDetails && {
        activityFailedEventDetails: dI(e.activityFailedEventDetails),
      }),
      ...(e.activityScheduleFailedEventDetails && {
        activityScheduleFailedEventDetails: uI(
          e.activityScheduleFailedEventDetails,
        ),
      }),
      ...(e.activityScheduledEventDetails && {
        activityScheduledEventDetails: lI(e.activityScheduledEventDetails),
      }),
      ...(e.activitySucceededEventDetails && {
        activitySucceededEventDetails: fI(e.activitySucceededEventDetails),
      }),
      ...(e.activityTimedOutEventDetails && {
        activityTimedOutEventDetails: pI(e.activityTimedOutEventDetails),
      }),
      ...(e.taskFailedEventDetails && {
        taskFailedEventDetails: FI(e.taskFailedEventDetails),
      }),
      ...(e.taskScheduledEventDetails && {
        taskScheduledEventDetails: LI(e.taskScheduledEventDetails),
      }),
      ...(e.taskStartFailedEventDetails && {
        taskStartFailedEventDetails: $I(e.taskStartFailedEventDetails),
      }),
      ...(e.taskSubmitFailedEventDetails && {
        taskSubmitFailedEventDetails: UI(e.taskSubmitFailedEventDetails),
      }),
      ...(e.taskSubmittedEventDetails && {
        taskSubmittedEventDetails: HI(e.taskSubmittedEventDetails),
      }),
      ...(e.taskSucceededEventDetails && {
        taskSucceededEventDetails: zI(e.taskSucceededEventDetails),
      }),
      ...(e.taskTimedOutEventDetails && {
        taskTimedOutEventDetails: jI(e.taskTimedOutEventDetails),
      }),
      ...(e.executionFailedEventDetails && {
        executionFailedEventDetails: xI(e.executionFailedEventDetails),
      }),
      ...(e.executionStartedEventDetails && {
        executionStartedEventDetails: vI(e.executionStartedEventDetails),
      }),
      ...(e.executionSucceededEventDetails && {
        executionSucceededEventDetails: TI(e.executionSucceededEventDetails),
      }),
      ...(e.executionAbortedEventDetails && {
        executionAbortedEventDetails: bI(e.executionAbortedEventDetails),
      }),
      ...(e.executionTimedOutEventDetails && {
        executionTimedOutEventDetails: CI(e.executionTimedOutEventDetails),
      }),
      ...(e.lambdaFunctionFailedEventDetails && {
        lambdaFunctionFailedEventDetails: II(
          e.lambdaFunctionFailedEventDetails,
        ),
      }),
      ...(e.lambdaFunctionScheduleFailedEventDetails && {
        lambdaFunctionScheduleFailedEventDetails: RI(
          e.lambdaFunctionScheduleFailedEventDetails,
        ),
      }),
      ...(e.lambdaFunctionScheduledEventDetails && {
        lambdaFunctionScheduledEventDetails: AI(
          e.lambdaFunctionScheduledEventDetails,
        ),
      }),
      ...(e.lambdaFunctionStartFailedEventDetails && {
        lambdaFunctionStartFailedEventDetails: NI(
          e.lambdaFunctionStartFailedEventDetails,
        ),
      }),
      ...(e.lambdaFunctionSucceededEventDetails && {
        lambdaFunctionSucceededEventDetails: PI(
          e.lambdaFunctionSucceededEventDetails,
        ),
      }),
      ...(e.lambdaFunctionTimedOutEventDetails && {
        lambdaFunctionTimedOutEventDetails: OI(
          e.lambdaFunctionTimedOutEventDetails,
        ),
      }),
      ...(e.stateEnteredEventDetails && {
        stateEnteredEventDetails: MI(e.stateEnteredEventDetails),
      }),
      ...(e.stateExitedEventDetails && {
        stateExitedEventDetails: kI(e.stateExitedEventDetails),
      }),
      ...(e.mapRunFailedEventDetails && {
        mapRunFailedEventDetails: DI(e.mapRunFailedEventDetails),
      }),
      ...(e.evaluationFailedEventDetails && {
        evaluationFailedEventDetails: wI(e.evaluationFailedEventDetails),
      }),
    }),
    qI = (e) => ({
      ...e,
      ...(e.events && { events: e.events.map((t) => BI(t)) }),
    }),
    VI = (e) => ({
      ...e,
      ...(e.description && { description: c.SENSITIVE_STRING }),
    }),
    GI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    WI = (e) => ({ ...e, ...(e.output && { output: c.SENSITIVE_STRING }) }),
    KI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    JI = (e) => ({ ...e, ...(e.input && { input: c.SENSITIVE_STRING }) }),
    YI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
      ...(e.input && { input: c.SENSITIVE_STRING }),
      ...(e.output && { output: c.SENSITIVE_STRING }),
    }),
    XI = (e) => ({
      ...e,
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
    }),
    QI = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
      ...(e.input && { input: c.SENSITIVE_STRING }),
      ...(e.variables && { variables: c.SENSITIVE_STRING }),
    }),
    gU = (e) => ({
      ...e,
      ...(e.input && { input: c.SENSITIVE_STRING }),
      ...(e.afterArguments && { afterArguments: c.SENSITIVE_STRING }),
      ...(e.afterInputPath && { afterInputPath: c.SENSITIVE_STRING }),
      ...(e.afterParameters && { afterParameters: c.SENSITIVE_STRING }),
      ...(e.result && { result: c.SENSITIVE_STRING }),
      ...(e.afterResultSelector && { afterResultSelector: c.SENSITIVE_STRING }),
      ...(e.afterResultPath && { afterResultPath: c.SENSITIVE_STRING }),
      ...(e.variables && { variables: c.SENSITIVE_STRING }),
    }),
    ZI = (e) => ({
      ...e,
      ...(e.output && { output: c.SENSITIVE_STRING }),
      ...(e.error && { error: c.SENSITIVE_STRING }),
      ...(e.cause && { cause: c.SENSITIVE_STRING }),
      ...(e.inspectionData && { inspectionData: c.SENSITIVE_STRING }),
    }),
    eA = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
      ...(e.versionDescription && { versionDescription: c.SENSITIVE_STRING }),
    }),
    tA = (e) => ({
      ...e,
      ...(e.description && { description: c.SENSITIVE_STRING }),
    }),
    rA = (e) => ({
      ...e,
      ...(e.definition && { definition: c.SENSITIVE_STRING }),
    }),
    nA = (e) => ({
      ...e,
      ...(e.code && { code: c.SENSITIVE_STRING }),
      ...(e.message && { message: c.SENSITIVE_STRING }),
      ...(e.location && { location: c.SENSITIVE_STRING }),
    }),
    sA = (e) => ({
      ...e,
      ...(e.diagnostics && { diagnostics: e.diagnostics.map((t) => nA(t)) }),
    }),
    SU = async (e, t) => {
      let r = ne("CreateActivity"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    yU = async (e, t) => {
      let r = ne("CreateStateMachine"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    EU = async (e, t) => {
      let r = ne("CreateStateMachineAlias"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    _U = async (e, t) => {
      let r = ne("DeleteActivity"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    wU = async (e, t) => {
      let r = ne("DeleteStateMachine"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    bU = async (e, t) => {
      let r = ne("DeleteStateMachineAlias"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    xU = async (e, t) => {
      let r = ne("DeleteStateMachineVersion"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    vU = async (e, t) => {
      let r = ne("DescribeActivity"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    TU = async (e, t) => {
      let r = ne("DescribeExecution"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    CU = async (e, t) => {
      let r = ne("DescribeMapRun"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    IU = async (e, t) => {
      let r = ne("DescribeStateMachine"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    AU = async (e, t) => {
      let r = ne("DescribeStateMachineAlias"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    RU = async (e, t) => {
      let r = ne("DescribeStateMachineForExecution"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    NU = async (e, t) => {
      let r = ne("GetActivityTask"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    PU = async (e, t) => {
      let r = ne("GetExecutionHistory"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    OU = async (e, t) => {
      let r = ne("ListActivities"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    DU = async (e, t) => {
      let r = ne("ListExecutions"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    MU = async (e, t) => {
      let r = ne("ListMapRuns"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    kU = async (e, t) => {
      let r = ne("ListStateMachineAliases"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    FU = async (e, t) => {
      let r = ne("ListStateMachines"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    LU = async (e, t) => {
      let r = ne("ListStateMachineVersions"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    $U = async (e, t) => {
      let r = ne("ListTagsForResource"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    UU = async (e, t) => {
      let r = ne("PublishStateMachineVersion"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    HU = async (e, t) => {
      let r = ne("RedriveExecution"),
        n;
      return ((n = JSON.stringify(gz(e))), re(t, r, "/", void 0, n));
    },
    zU = async (e, t) => {
      let r = ne("SendTaskFailure"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    jU = async (e, t) => {
      let r = ne("SendTaskHeartbeat"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    BU = async (e, t) => {
      let r = ne("SendTaskSuccess"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    qU = async (e, t) => {
      let r = ne("StartExecution"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    VU = async (e, t) => {
      let r = ne("StartSyncExecution"),
        n;
      n = JSON.stringify(c._json(e));
      let { hostname: s } = await t.endpoint();
      if (
        t.disableHostPrefix !== !0 &&
        ((s = "sync-" + s), !Uo.isValidHostname(s))
      )
        throw new Error(
          "ValidationError: prefixed hostname must be hostname compatible.",
        );
      return re(t, r, "/", s, n);
    },
    GU = async (e, t) => {
      let r = ne("StopExecution"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    WU = async (e, t) => {
      let r = ne("TagResource"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    KU = async (e, t) => {
      let r = ne("TestState"),
        n;
      n = JSON.stringify(c._json(e));
      let { hostname: s } = await t.endpoint();
      if (
        t.disableHostPrefix !== !0 &&
        ((s = "sync-" + s), !Uo.isValidHostname(s))
      )
        throw new Error(
          "ValidationError: prefixed hostname must be hostname compatible.",
        );
      return re(t, r, "/", s, n);
    },
    JU = async (e, t) => {
      let r = ne("UntagResource"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    YU = async (e, t) => {
      let r = ne("UpdateMapRun"),
        n;
      return ((n = JSON.stringify(Sz(e))), re(t, r, "/", void 0, n));
    },
    XU = async (e, t) => {
      let r = ne("UpdateStateMachine"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    QU = async (e, t) => {
      let r = ne("UpdateStateMachineAlias"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    ZU = async (e, t) => {
      let r = ne("ValidateStateMachineDefinition"),
        n;
      return ((n = JSON.stringify(c._json(e))), re(t, r, "/", void 0, n));
    },
    eH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = _z(r)), { $metadata: k(e), ...n });
    },
    tH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = bz(r)), { $metadata: k(e), ...n });
    },
    rH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = wz(r)), { $metadata: k(e), ...n });
    },
    nH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    sH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    oH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    iH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    aH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = xz(r)), { $metadata: k(e), ...n });
    },
    cH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = vz(r)), { $metadata: k(e), ...n });
    },
    dH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Tz(r)), { $metadata: k(e), ...n });
    },
    lH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Az(r)), { $metadata: k(e), ...n });
    },
    uH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Cz(r)), { $metadata: k(e), ...n });
    },
    fH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Iz(r)), { $metadata: k(e), ...n });
    },
    pH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    mH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Pz(r)), { $metadata: k(e), ...n });
    },
    hH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Mz(r)), { $metadata: k(e), ...n });
    },
    gH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = kz(r)), { $metadata: k(e), ...n });
    },
    SH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Fz(r)), { $metadata: k(e), ...n });
    },
    yH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Lz(r)), { $metadata: k(e), ...n });
    },
    EH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = $z(r)), { $metadata: k(e), ...n });
    },
    _H = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Uz(r)), { $metadata: k(e), ...n });
    },
    wH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    bH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = jz(r)), { $metadata: k(e), ...n });
    },
    xH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Bz(r)), { $metadata: k(e), ...n });
    },
    vH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    TH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    CH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    IH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = qz(r)), { $metadata: k(e), ...n });
    },
    AH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Vz(r)), { $metadata: k(e), ...n });
    },
    RH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Qz(r)), { $metadata: k(e), ...n });
    },
    NH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    PH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    OH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    DH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    MH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = ej(r)), { $metadata: k(e), ...n });
    },
    kH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = Zz(r)), { $metadata: k(e), ...n });
    },
    FH = async (e, t) => {
      if (e.statusCode >= 300) return te(e, t);
      let r = await K.parseJsonBody(e.body, t),
        n = {};
      return ((n = c._json(r)), { $metadata: k(e), ...n });
    },
    te = async (e, t) => {
      let r = { ...e, body: await K.parseJsonErrorBody(e.body, t) },
        n = K.loadRestJsonErrorCode(e, r.body);
      switch (n) {
        case "ActivityAlreadyExists":
        case "com.amazonaws.sfn#ActivityAlreadyExists":
          throw await LH(r);
        case "ActivityLimitExceeded":
        case "com.amazonaws.sfn#ActivityLimitExceeded":
          throw await UH(r);
        case "InvalidEncryptionConfiguration":
        case "com.amazonaws.sfn#InvalidEncryptionConfiguration":
          throw await KH(r);
        case "InvalidName":
        case "com.amazonaws.sfn#InvalidName":
          throw await XH(r);
        case "KmsAccessDeniedException":
        case "com.amazonaws.sfn#KmsAccessDeniedException":
          throw await tz(r);
        case "KmsThrottlingException":
        case "com.amazonaws.sfn#KmsThrottlingException":
          throw await nz(r);
        case "TooManyTags":
        case "com.amazonaws.sfn#TooManyTags":
          throw await mz(r);
        case "ConflictException":
        case "com.amazonaws.sfn#ConflictException":
          throw await zH(r);
        case "InvalidArn":
        case "com.amazonaws.sfn#InvalidArn":
          throw await GH(r);
        case "InvalidDefinition":
        case "com.amazonaws.sfn#InvalidDefinition":
          throw await WH(r);
        case "InvalidLoggingConfiguration":
        case "com.amazonaws.sfn#InvalidLoggingConfiguration":
          throw await YH(r);
        case "InvalidTracingConfiguration":
        case "com.amazonaws.sfn#InvalidTracingConfiguration":
          throw await ez(r);
        case "StateMachineAlreadyExists":
        case "com.amazonaws.sfn#StateMachineAlreadyExists":
          throw await az(r);
        case "StateMachineDeleting":
        case "com.amazonaws.sfn#StateMachineDeleting":
          throw await cz(r);
        case "StateMachineLimitExceeded":
        case "com.amazonaws.sfn#StateMachineLimitExceeded":
          throw await lz(r);
        case "StateMachineTypeNotSupported":
        case "com.amazonaws.sfn#StateMachineTypeNotSupported":
          throw await uz(r);
        case "ValidationException":
        case "com.amazonaws.sfn#ValidationException":
          throw await hz(r);
        case "ResourceNotFound":
        case "com.amazonaws.sfn#ResourceNotFound":
          throw await oz(r);
        case "ServiceQuotaExceededException":
        case "com.amazonaws.sfn#ServiceQuotaExceededException":
          throw await iz(r);
        case "ActivityDoesNotExist":
        case "com.amazonaws.sfn#ActivityDoesNotExist":
          throw await $H(r);
        case "ExecutionDoesNotExist":
        case "com.amazonaws.sfn#ExecutionDoesNotExist":
          throw await BH(r);
        case "KmsInvalidStateException":
        case "com.amazonaws.sfn#KmsInvalidStateException":
          throw await rz(r);
        case "StateMachineDoesNotExist":
        case "com.amazonaws.sfn#StateMachineDoesNotExist":
          throw await dz(r);
        case "ActivityWorkerLimitExceeded":
        case "com.amazonaws.sfn#ActivityWorkerLimitExceeded":
          throw await HH(r);
        case "InvalidToken":
        case "com.amazonaws.sfn#InvalidToken":
          throw await ZH(r);
        case "ExecutionLimitExceeded":
        case "com.amazonaws.sfn#ExecutionLimitExceeded":
          throw await qH(r);
        case "ExecutionNotRedrivable":
        case "com.amazonaws.sfn#ExecutionNotRedrivable":
          throw await VH(r);
        case "TaskDoesNotExist":
        case "com.amazonaws.sfn#TaskDoesNotExist":
          throw await fz(r);
        case "TaskTimedOut":
        case "com.amazonaws.sfn#TaskTimedOut":
          throw await pz(r);
        case "InvalidOutput":
        case "com.amazonaws.sfn#InvalidOutput":
          throw await QH(r);
        case "ExecutionAlreadyExists":
        case "com.amazonaws.sfn#ExecutionAlreadyExists":
          throw await jH(r);
        case "InvalidExecutionInput":
        case "com.amazonaws.sfn#InvalidExecutionInput":
          throw await JH(r);
        case "MissingRequiredParameter":
        case "com.amazonaws.sfn#MissingRequiredParameter":
          throw await sz(r);
        default:
          let s = r.body;
          return tj({ output: e, parsedBody: s, errorCode: n });
      }
    },
    LH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Hc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    $H = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new zc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    UH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new jc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    HH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Bc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    zH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Jc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    jH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new gd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    BH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new ad({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    qH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new ud({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    VH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new fd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    GH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Yc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    WH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Xc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    KH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new qc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    JH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Sd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    YH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Qc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    XH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Vc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    QH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new hd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    ZH = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new ld({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    ez = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Zc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    tz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Gc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    rz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new cd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    nz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Wc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    sz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new yd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    oz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new od({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    iz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new id({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    az = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new ed({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    cz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new td({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    dz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new dd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    lz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new rd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    uz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new nd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    fz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new pd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    pz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new md({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    mz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new Kc({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    hz = async (e, t) => {
      let r = e.body,
        n = c._json(r),
        s = new sd({ $metadata: k(e), ...n });
      return c.decorateServiceException(s, r);
    },
    gz = (e, t) =>
      c.take(e, { clientToken: [!0, (r) => r ?? K$.v4()], executionArn: [] }),
    Sz = (e, t) =>
      c.take(e, {
        mapRunArn: [],
        maxConcurrency: [],
        toleratedFailureCount: [],
        toleratedFailurePercentage: c.serializeFloat,
      }),
    yz = (e, t) => (e || []).filter((n) => n != null).map((n) => Ez(n)),
    Ez = (e, t) =>
      c.take(e, {
        activityArn: c.expectString,
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        name: c.expectString,
      }),
    _z = (e, t) =>
      c.take(e, {
        activityArn: c.expectString,
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    wz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineAliasArn: c.expectString,
      }),
    bz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineArn: c.expectString,
        stateMachineVersionArn: c.expectString,
      }),
    xz = (e, t) =>
      c.take(e, {
        activityArn: c.expectString,
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        encryptionConfiguration: c._json,
        name: c.expectString,
      }),
    vz = (e, t) =>
      c.take(e, {
        cause: c.expectString,
        error: c.expectString,
        executionArn: c.expectString,
        input: c.expectString,
        inputDetails: c._json,
        mapRunArn: c.expectString,
        name: c.expectString,
        output: c.expectString,
        outputDetails: c._json,
        redriveCount: c.expectInt32,
        redriveDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        redriveStatus: c.expectString,
        redriveStatusReason: c.expectString,
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineAliasArn: c.expectString,
        stateMachineArn: c.expectString,
        stateMachineVersionArn: c.expectString,
        status: c.expectString,
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        traceHeader: c.expectString,
      }),
    Tz = (e, t) =>
      c.take(e, {
        executionArn: c.expectString,
        executionCounts: c._json,
        itemCounts: c._json,
        mapRunArn: c.expectString,
        maxConcurrency: c.expectInt32,
        redriveCount: c.expectInt32,
        redriveDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        status: c.expectString,
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        toleratedFailureCount: c.expectLong,
        toleratedFailurePercentage: c.limitedParseFloat32,
      }),
    Cz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        description: c.expectString,
        name: c.expectString,
        routingConfiguration: c._json,
        stateMachineAliasArn: c.expectString,
        updateDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    Iz = (e, t) =>
      c.take(e, {
        definition: c.expectString,
        encryptionConfiguration: c._json,
        label: c.expectString,
        loggingConfiguration: c._json,
        mapRunArn: c.expectString,
        name: c.expectString,
        revisionId: c.expectString,
        roleArn: c.expectString,
        stateMachineArn: c.expectString,
        tracingConfiguration: c._json,
        updateDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        variableReferences: c._json,
      }),
    Az = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        definition: c.expectString,
        description: c.expectString,
        encryptionConfiguration: c._json,
        label: c.expectString,
        loggingConfiguration: c._json,
        name: c.expectString,
        revisionId: c.expectString,
        roleArn: c.expectString,
        stateMachineArn: c.expectString,
        status: c.expectString,
        tracingConfiguration: c._json,
        type: c.expectString,
        variableReferences: c._json,
      }),
    Rz = (e, t) => (e || []).filter((n) => n != null).map((n) => Nz(n)),
    Nz = (e, t) =>
      c.take(e, {
        executionArn: c.expectString,
        itemCount: c.expectInt32,
        mapRunArn: c.expectString,
        name: c.expectString,
        redriveCount: c.expectInt32,
        redriveDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineAliasArn: c.expectString,
        stateMachineArn: c.expectString,
        stateMachineVersionArn: c.expectString,
        status: c.expectString,
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    Pz = (e, t) =>
      c.take(e, { events: (r) => Dz(r), nextToken: c.expectString }),
    Oz = (e, t) =>
      c.take(e, {
        activityFailedEventDetails: c._json,
        activityScheduleFailedEventDetails: c._json,
        activityScheduledEventDetails: c._json,
        activityStartedEventDetails: c._json,
        activitySucceededEventDetails: c._json,
        activityTimedOutEventDetails: c._json,
        evaluationFailedEventDetails: c._json,
        executionAbortedEventDetails: c._json,
        executionFailedEventDetails: c._json,
        executionRedrivenEventDetails: c._json,
        executionStartedEventDetails: c._json,
        executionSucceededEventDetails: c._json,
        executionTimedOutEventDetails: c._json,
        id: c.expectLong,
        lambdaFunctionFailedEventDetails: c._json,
        lambdaFunctionScheduleFailedEventDetails: c._json,
        lambdaFunctionScheduledEventDetails: c._json,
        lambdaFunctionStartFailedEventDetails: c._json,
        lambdaFunctionSucceededEventDetails: c._json,
        lambdaFunctionTimedOutEventDetails: c._json,
        mapIterationAbortedEventDetails: c._json,
        mapIterationFailedEventDetails: c._json,
        mapIterationStartedEventDetails: c._json,
        mapIterationSucceededEventDetails: c._json,
        mapRunFailedEventDetails: c._json,
        mapRunRedrivenEventDetails: c._json,
        mapRunStartedEventDetails: c._json,
        mapStateStartedEventDetails: c._json,
        previousEventId: c.expectLong,
        stateEnteredEventDetails: c._json,
        stateExitedEventDetails: c._json,
        taskFailedEventDetails: c._json,
        taskScheduledEventDetails: c._json,
        taskStartFailedEventDetails: c._json,
        taskStartedEventDetails: c._json,
        taskSubmitFailedEventDetails: c._json,
        taskSubmittedEventDetails: c._json,
        taskSucceededEventDetails: c._json,
        taskTimedOutEventDetails: c._json,
        timestamp: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        type: c.expectString,
      }),
    Dz = (e, t) => (e || []).filter((n) => n != null).map((n) => Oz(n)),
    Mz = (e, t) =>
      c.take(e, { activities: (r) => yz(r), nextToken: c.expectString }),
    kz = (e, t) =>
      c.take(e, { executions: (r) => Rz(r), nextToken: c.expectString }),
    Fz = (e, t) =>
      c.take(e, { mapRuns: (r) => Hz(r), nextToken: c.expectString }),
    Lz = (e, t) =>
      c.take(e, {
        nextToken: c.expectString,
        stateMachineAliases: (r) => Gz(r),
      }),
    $z = (e, t) =>
      c.take(e, { nextToken: c.expectString, stateMachines: (r) => Kz(r) }),
    Uz = (e, t) =>
      c.take(e, {
        nextToken: c.expectString,
        stateMachineVersions: (r) => Yz(r),
      }),
    Hz = (e, t) => (e || []).filter((n) => n != null).map((n) => zz(n)),
    zz = (e, t) =>
      c.take(e, {
        executionArn: c.expectString,
        mapRunArn: c.expectString,
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineArn: c.expectString,
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    jz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineVersionArn: c.expectString,
      }),
    Bz = (e, t) =>
      c.take(e, {
        redriveDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    qz = (e, t) =>
      c.take(e, {
        executionArn: c.expectString,
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    Vz = (e, t) =>
      c.take(e, {
        billingDetails: c._json,
        cause: c.expectString,
        error: c.expectString,
        executionArn: c.expectString,
        input: c.expectString,
        inputDetails: c._json,
        name: c.expectString,
        output: c.expectString,
        outputDetails: c._json,
        startDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineArn: c.expectString,
        status: c.expectString,
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        traceHeader: c.expectString,
      }),
    Gz = (e, t) => (e || []).filter((n) => n != null).map((n) => Wz(n)),
    Wz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineAliasArn: c.expectString,
      }),
    Kz = (e, t) => (e || []).filter((n) => n != null).map((n) => Jz(n)),
    Jz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        name: c.expectString,
        stateMachineArn: c.expectString,
        type: c.expectString,
      }),
    Yz = (e, t) => (e || []).filter((n) => n != null).map((n) => Xz(n)),
    Xz = (e, t) =>
      c.take(e, {
        creationDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
        stateMachineVersionArn: c.expectString,
      }),
    Qz = (e, t) =>
      c.take(e, {
        stopDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    Zz = (e, t) =>
      c.take(e, {
        updateDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    ej = (e, t) =>
      c.take(e, {
        revisionId: c.expectString,
        stateMachineVersionArn: c.expectString,
        updateDate: (r) =>
          c.expectNonNull(c.parseEpochTimestamp(c.expectNumber(r))),
      }),
    k = (e) => ({
      httpStatusCode: e.statusCode,
      requestId:
        e.headers["x-amzn-requestid"] ??
        e.headers["x-amzn-request-id"] ??
        e.headers["x-amz-request-id"],
      extendedRequestId: e.headers["x-amz-id-2"],
      cfId: e.headers["x-amz-cf-id"],
    }),
    tj = c.withBaseException(Q),
    re = async (e, t, r, n, s) => {
      let {
          hostname: o,
          protocol: i = "https",
          port: a,
          path: d,
        } = await e.endpoint(),
        l = {
          protocol: i,
          hostname: o,
          port: a,
          method: "POST",
          path: d.endsWith("/") ? d.slice(0, -1) + r : d + r,
          headers: t,
        };
      return (
        n !== void 0 && (l.hostname = n),
        s !== void 0 && (l.body = s),
        new Uo.HttpRequest(l)
      );
    };
  function ne(e) {
    return {
      "content-type": "application/x-amz-json-1.0",
      "x-amz-target": `AWSStepFunctions.${e}`,
    };
  }
  var Ed = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "CreateActivity", {})
      .n("SFNClient", "CreateActivityCommand")
      .f(void 0, void 0)
      .ser(SU)
      .de(eH)
      .build() {},
    _d = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "CreateStateMachineAlias", {})
      .n("SFNClient", "CreateStateMachineAliasCommand")
      .f(hI, void 0)
      .ser(EU)
      .de(rH)
      .build() {},
    wd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "CreateStateMachine", {})
      .n("SFNClient", "CreateStateMachineCommand")
      .f(mI, void 0)
      .ser(yU)
      .de(tH)
      .build() {},
    bd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DeleteActivity", {})
      .n("SFNClient", "DeleteActivityCommand")
      .f(void 0, void 0)
      .ser(_U)
      .de(nH)
      .build() {},
    xd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DeleteStateMachineAlias", {})
      .n("SFNClient", "DeleteStateMachineAliasCommand")
      .f(void 0, void 0)
      .ser(bU)
      .de(oH)
      .build() {},
    vd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DeleteStateMachine", {})
      .n("SFNClient", "DeleteStateMachineCommand")
      .f(void 0, void 0)
      .ser(wU)
      .de(sH)
      .build() {},
    Td = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DeleteStateMachineVersion", {})
      .n("SFNClient", "DeleteStateMachineVersionCommand")
      .f(void 0, void 0)
      .ser(xU)
      .de(iH)
      .build() {},
    Cd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeActivity", {})
      .n("SFNClient", "DescribeActivityCommand")
      .f(void 0, void 0)
      .ser(vU)
      .de(aH)
      .build() {},
    Id = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeExecution", {})
      .n("SFNClient", "DescribeExecutionCommand")
      .f(void 0, gI)
      .ser(TU)
      .de(cH)
      .build() {},
    Ad = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeMapRun", {})
      .n("SFNClient", "DescribeMapRunCommand")
      .f(void 0, void 0)
      .ser(CU)
      .de(dH)
      .build() {},
    Rd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeStateMachineAlias", {})
      .n("SFNClient", "DescribeStateMachineAliasCommand")
      .f(void 0, yI)
      .ser(AU)
      .de(uH)
      .build() {},
    Nd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeStateMachine", {})
      .n("SFNClient", "DescribeStateMachineCommand")
      .f(void 0, SI)
      .ser(IU)
      .de(lH)
      .build() {},
    Pd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "DescribeStateMachineForExecution", {})
      .n("SFNClient", "DescribeStateMachineForExecutionCommand")
      .f(void 0, EI)
      .ser(RU)
      .de(fH)
      .build() {},
    Od = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "GetActivityTask", {})
      .n("SFNClient", "GetActivityTaskCommand")
      .f(void 0, _I)
      .ser(NU)
      .de(pH)
      .build() {},
    Ho = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "GetExecutionHistory", {})
      .n("SFNClient", "GetExecutionHistoryCommand")
      .f(void 0, qI)
      .ser(PU)
      .de(mH)
      .build() {},
    zo = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListActivities", {})
      .n("SFNClient", "ListActivitiesCommand")
      .f(void 0, void 0)
      .ser(OU)
      .de(hH)
      .build() {},
    jo = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListExecutions", {})
      .n("SFNClient", "ListExecutionsCommand")
      .f(void 0, void 0)
      .ser(DU)
      .de(gH)
      .build() {},
    Bo = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListMapRuns", {})
      .n("SFNClient", "ListMapRunsCommand")
      .f(void 0, void 0)
      .ser(MU)
      .de(SH)
      .build() {},
    Dd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListStateMachineAliases", {})
      .n("SFNClient", "ListStateMachineAliasesCommand")
      .f(void 0, void 0)
      .ser(kU)
      .de(yH)
      .build() {},
    qo = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListStateMachines", {})
      .n("SFNClient", "ListStateMachinesCommand")
      .f(void 0, void 0)
      .ser(FU)
      .de(EH)
      .build() {},
    Md = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListStateMachineVersions", {})
      .n("SFNClient", "ListStateMachineVersionsCommand")
      .f(void 0, void 0)
      .ser(LU)
      .de(_H)
      .build() {},
    kd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ListTagsForResource", {})
      .n("SFNClient", "ListTagsForResourceCommand")
      .f(void 0, void 0)
      .ser($U)
      .de(wH)
      .build() {},
    Fd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "PublishStateMachineVersion", {})
      .n("SFNClient", "PublishStateMachineVersionCommand")
      .f(VI, void 0)
      .ser(UU)
      .de(bH)
      .build() {},
    Ld = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "RedriveExecution", {})
      .n("SFNClient", "RedriveExecutionCommand")
      .f(void 0, void 0)
      .ser(HU)
      .de(xH)
      .build() {},
    $d = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "SendTaskFailure", {})
      .n("SFNClient", "SendTaskFailureCommand")
      .f(GI, void 0)
      .ser(zU)
      .de(vH)
      .build() {},
    Ud = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "SendTaskHeartbeat", {})
      .n("SFNClient", "SendTaskHeartbeatCommand")
      .f(void 0, void 0)
      .ser(jU)
      .de(TH)
      .build() {},
    Hd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "SendTaskSuccess", {})
      .n("SFNClient", "SendTaskSuccessCommand")
      .f(WI, void 0)
      .ser(BU)
      .de(CH)
      .build() {},
    zd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "StartExecution", {})
      .n("SFNClient", "StartExecutionCommand")
      .f(KI, void 0)
      .ser(qU)
      .de(IH)
      .build() {},
    jd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "StartSyncExecution", {})
      .n("SFNClient", "StartSyncExecutionCommand")
      .f(JI, YI)
      .ser(VU)
      .de(AH)
      .build() {},
    Bd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "StopExecution", {})
      .n("SFNClient", "StopExecutionCommand")
      .f(XI, void 0)
      .ser(GU)
      .de(RH)
      .build() {},
    qd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "TagResource", {})
      .n("SFNClient", "TagResourceCommand")
      .f(void 0, void 0)
      .ser(WU)
      .de(NH)
      .build() {},
    Vd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "TestState", {})
      .n("SFNClient", "TestStateCommand")
      .f(QI, ZI)
      .ser(KU)
      .de(PH)
      .build() {},
    Gd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "UntagResource", {})
      .n("SFNClient", "UntagResourceCommand")
      .f(void 0, void 0)
      .ser(JU)
      .de(OH)
      .build() {},
    Wd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "UpdateMapRun", {})
      .n("SFNClient", "UpdateMapRunCommand")
      .f(void 0, void 0)
      .ser(YU)
      .de(DH)
      .build() {},
    Kd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "UpdateStateMachineAlias", {})
      .n("SFNClient", "UpdateStateMachineAliasCommand")
      .f(tA, void 0)
      .ser(QU)
      .de(kH)
      .build() {},
    Jd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "UpdateStateMachine", {})
      .n("SFNClient", "UpdateStateMachineCommand")
      .f(eA, void 0)
      .ser(XU)
      .de(MH)
      .build() {},
    Yd = class extends c.Command.classBuilder()
      .ep(ee)
      .m(function (t, r, n, s) {
        return [
          Z.getSerdePlugin(n, this.serialize, this.deserialize),
          X.getEndpointPlugin(n, t.getEndpointParameterInstructions()),
        ];
      })
      .s("AWSStepFunctions", "ValidateStateMachineDefinition", {})
      .n("SFNClient", "ValidateStateMachineDefinitionCommand")
      .f(rA, sA)
      .ser(ZU)
      .de(FH)
      .build() {},
    rj = {
      CreateActivityCommand: Ed,
      CreateStateMachineCommand: wd,
      CreateStateMachineAliasCommand: _d,
      DeleteActivityCommand: bd,
      DeleteStateMachineCommand: vd,
      DeleteStateMachineAliasCommand: xd,
      DeleteStateMachineVersionCommand: Td,
      DescribeActivityCommand: Cd,
      DescribeExecutionCommand: Id,
      DescribeMapRunCommand: Ad,
      DescribeStateMachineCommand: Nd,
      DescribeStateMachineAliasCommand: Rd,
      DescribeStateMachineForExecutionCommand: Pd,
      GetActivityTaskCommand: Od,
      GetExecutionHistoryCommand: Ho,
      ListActivitiesCommand: zo,
      ListExecutionsCommand: jo,
      ListMapRunsCommand: Bo,
      ListStateMachineAliasesCommand: Dd,
      ListStateMachinesCommand: qo,
      ListStateMachineVersionsCommand: Md,
      ListTagsForResourceCommand: kd,
      PublishStateMachineVersionCommand: Fd,
      RedriveExecutionCommand: Ld,
      SendTaskFailureCommand: $d,
      SendTaskHeartbeatCommand: Ud,
      SendTaskSuccessCommand: Hd,
      StartExecutionCommand: zd,
      StartSyncExecutionCommand: jd,
      StopExecutionCommand: Bd,
      TagResourceCommand: qd,
      TestStateCommand: Vd,
      UntagResourceCommand: Gd,
      UpdateMapRunCommand: Wd,
      UpdateStateMachineCommand: Jd,
      UpdateStateMachineAliasCommand: Kd,
      ValidateStateMachineDefinitionCommand: Yd,
    },
    Xd = class extends Zt {};
  c.createAggregatedClient(rj, Xd);
  var nj = $r.createPaginator(Zt, Ho, "nextToken", "nextToken", "maxResults"),
    sj = $r.createPaginator(Zt, zo, "nextToken", "nextToken", "maxResults"),
    oj = $r.createPaginator(Zt, jo, "nextToken", "nextToken", "maxResults"),
    ij = $r.createPaginator(Zt, Bo, "nextToken", "nextToken", "maxResults"),
    aj = $r.createPaginator(Zt, qo, "nextToken", "nextToken", "maxResults");
  Object.defineProperty(x, "$Command", {
    enumerable: !0,
    get: function () {
      return c.Command;
    },
  });
  Object.defineProperty(x, "__Client", {
    enumerable: !0,
    get: function () {
      return c.Client;
    },
  });
  x.ActivityAlreadyExists = Hc;
  x.ActivityDoesNotExist = zc;
  x.ActivityFailedEventDetailsFilterSensitiveLog = dI;
  x.ActivityLimitExceeded = jc;
  x.ActivityScheduleFailedEventDetailsFilterSensitiveLog = uI;
  x.ActivityScheduledEventDetailsFilterSensitiveLog = lI;
  x.ActivitySucceededEventDetailsFilterSensitiveLog = fI;
  x.ActivityTimedOutEventDetailsFilterSensitiveLog = pI;
  x.ActivityWorkerLimitExceeded = Bc;
  x.ConflictException = Jc;
  x.CreateActivityCommand = Ed;
  x.CreateStateMachineAliasCommand = _d;
  x.CreateStateMachineAliasInputFilterSensitiveLog = hI;
  x.CreateStateMachineCommand = wd;
  x.CreateStateMachineInputFilterSensitiveLog = mI;
  x.DeleteActivityCommand = bd;
  x.DeleteStateMachineAliasCommand = xd;
  x.DeleteStateMachineCommand = vd;
  x.DeleteStateMachineVersionCommand = Td;
  x.DescribeActivityCommand = Cd;
  x.DescribeExecutionCommand = Id;
  x.DescribeExecutionOutputFilterSensitiveLog = gI;
  x.DescribeMapRunCommand = Ad;
  x.DescribeStateMachineAliasCommand = Rd;
  x.DescribeStateMachineAliasOutputFilterSensitiveLog = yI;
  x.DescribeStateMachineCommand = Nd;
  x.DescribeStateMachineForExecutionCommand = Pd;
  x.DescribeStateMachineForExecutionOutputFilterSensitiveLog = EI;
  x.DescribeStateMachineOutputFilterSensitiveLog = SI;
  x.EncryptionType = Z$;
  x.EvaluationFailedEventDetailsFilterSensitiveLog = wI;
  x.ExecutionAbortedEventDetailsFilterSensitiveLog = bI;
  x.ExecutionAlreadyExists = gd;
  x.ExecutionDoesNotExist = ad;
  x.ExecutionFailedEventDetailsFilterSensitiveLog = xI;
  x.ExecutionLimitExceeded = ud;
  x.ExecutionNotRedrivable = fd;
  x.ExecutionRedriveFilter = lU;
  x.ExecutionRedriveStatus = sU;
  x.ExecutionStartedEventDetailsFilterSensitiveLog = vI;
  x.ExecutionStatus = oU;
  x.ExecutionSucceededEventDetailsFilterSensitiveLog = TI;
  x.ExecutionTimedOutEventDetailsFilterSensitiveLog = CI;
  x.GetActivityTaskCommand = Od;
  x.GetActivityTaskOutputFilterSensitiveLog = _I;
  x.GetExecutionHistoryCommand = Ho;
  x.GetExecutionHistoryOutputFilterSensitiveLog = qI;
  x.HistoryEventFilterSensitiveLog = BI;
  x.HistoryEventType = dU;
  x.IncludedData = nU;
  x.InspectionDataFilterSensitiveLog = gU;
  x.InspectionLevel = fU;
  x.InvalidArn = Yc;
  x.InvalidDefinition = Xc;
  x.InvalidEncryptionConfiguration = qc;
  x.InvalidExecutionInput = Sd;
  x.InvalidLoggingConfiguration = Qc;
  x.InvalidName = Vc;
  x.InvalidOutput = hd;
  x.InvalidToken = ld;
  x.InvalidTracingConfiguration = Zc;
  x.KmsAccessDeniedException = Gc;
  x.KmsInvalidStateException = cd;
  x.KmsKeyState = iU;
  x.KmsThrottlingException = Wc;
  x.LambdaFunctionFailedEventDetailsFilterSensitiveLog = II;
  x.LambdaFunctionScheduleFailedEventDetailsFilterSensitiveLog = RI;
  x.LambdaFunctionScheduledEventDetailsFilterSensitiveLog = AI;
  x.LambdaFunctionStartFailedEventDetailsFilterSensitiveLog = NI;
  x.LambdaFunctionSucceededEventDetailsFilterSensitiveLog = PI;
  x.LambdaFunctionTimedOutEventDetailsFilterSensitiveLog = OI;
  x.ListActivitiesCommand = zo;
  x.ListExecutionsCommand = jo;
  x.ListMapRunsCommand = Bo;
  x.ListStateMachineAliasesCommand = Dd;
  x.ListStateMachineVersionsCommand = Md;
  x.ListStateMachinesCommand = qo;
  x.ListTagsForResourceCommand = kd;
  x.LogLevel = eU;
  x.MapRunFailedEventDetailsFilterSensitiveLog = DI;
  x.MapRunStatus = aU;
  x.MissingRequiredParameter = yd;
  x.PublishStateMachineVersionCommand = Fd;
  x.PublishStateMachineVersionInputFilterSensitiveLog = VI;
  x.RedriveExecutionCommand = Ld;
  x.ResourceNotFound = od;
  x.SFN = Xd;
  x.SFNClient = Zt;
  x.SFNServiceException = Q;
  x.SendTaskFailureCommand = $d;
  x.SendTaskFailureInputFilterSensitiveLog = GI;
  x.SendTaskHeartbeatCommand = Ud;
  x.SendTaskSuccessCommand = Hd;
  x.SendTaskSuccessInputFilterSensitiveLog = WI;
  x.ServiceQuotaExceededException = id;
  x.StartExecutionCommand = zd;
  x.StartExecutionInputFilterSensitiveLog = KI;
  x.StartSyncExecutionCommand = jd;
  x.StartSyncExecutionInputFilterSensitiveLog = JI;
  x.StartSyncExecutionOutputFilterSensitiveLog = YI;
  x.StateEnteredEventDetailsFilterSensitiveLog = MI;
  x.StateExitedEventDetailsFilterSensitiveLog = kI;
  x.StateMachineAlreadyExists = ed;
  x.StateMachineDeleting = td;
  x.StateMachineDoesNotExist = dd;
  x.StateMachineLimitExceeded = rd;
  x.StateMachineStatus = cU;
  x.StateMachineType = tU;
  x.StateMachineTypeNotSupported = nd;
  x.StopExecutionCommand = Bd;
  x.StopExecutionInputFilterSensitiveLog = XI;
  x.SyncExecutionStatus = uU;
  x.TagResourceCommand = qd;
  x.TaskDoesNotExist = pd;
  x.TaskFailedEventDetailsFilterSensitiveLog = FI;
  x.TaskScheduledEventDetailsFilterSensitiveLog = LI;
  x.TaskStartFailedEventDetailsFilterSensitiveLog = $I;
  x.TaskSubmitFailedEventDetailsFilterSensitiveLog = UI;
  x.TaskSubmittedEventDetailsFilterSensitiveLog = HI;
  x.TaskSucceededEventDetailsFilterSensitiveLog = zI;
  x.TaskTimedOut = md;
  x.TaskTimedOutEventDetailsFilterSensitiveLog = jI;
  x.TestExecutionStatus = pU;
  x.TestStateCommand = Vd;
  x.TestStateInputFilterSensitiveLog = QI;
  x.TestStateOutputFilterSensitiveLog = ZI;
  x.TooManyTags = Kc;
  x.UntagResourceCommand = Gd;
  x.UpdateMapRunCommand = Wd;
  x.UpdateStateMachineAliasCommand = Kd;
  x.UpdateStateMachineAliasInputFilterSensitiveLog = tA;
  x.UpdateStateMachineCommand = Jd;
  x.UpdateStateMachineInputFilterSensitiveLog = eA;
  x.ValidateStateMachineDefinitionCommand = Yd;
  x.ValidateStateMachineDefinitionDiagnosticFilterSensitiveLog = nA;
  x.ValidateStateMachineDefinitionInputFilterSensitiveLog = rA;
  x.ValidateStateMachineDefinitionOutputFilterSensitiveLog = sA;
  x.ValidateStateMachineDefinitionResultCode = hU;
  x.ValidateStateMachineDefinitionSeverity = mU;
  x.ValidationException = sd;
  x.ValidationExceptionReason = rU;
  x.paginateGetExecutionHistory = nj;
  x.paginateListActivities = sj;
  x.paginateListExecutions = oj;
  x.paginateListMapRuns = ij;
  x.paginateListStateMachines = aj;
});
var lj = {};
st(lj, { handler: () => dj });
module.exports = ce(lj);
var Qd = v(oA()),
  cj = new Qd.SFNClient({}),
  dj = async (e) => {
    console.log("Ingress received event:", JSON.stringify(e));
    let t = process.env.STATE_MACHINE_ARN;
    if (!t)
      return (
        console.error("STATE_MACHINE_ARN not set"),
        { statusCode: 500, body: "Misconfigured lambda" }
      );
    let r = `exec-${Date.now()}`,
      n = JSON.stringify({ from: "ingress", payload: e });
    return (
      await cj.send(
        new Qd.StartExecutionCommand({ stateMachineArn: t, name: r, input: n }),
      ),
      { statusCode: 202, body: JSON.stringify({ ok: !0, started: r }) }
    );
  };
0 && (module.exports = { handler });
//# sourceMappingURL=index.js.map
